/*
 * support for running in hypervisors, emulators, simulators, containers, etc.
 */
#include "u.h"
#include "../port/lib.h"
#include "mem.h"
#include "dat.h"
#include "fns.h"
#include "io.h"

typedef struct Hyper {
	char	*name;
	char	*id;		/* Hypercpuid id string, if any */
	ushort	vid;		/* pci vendor id */
	ulong	bit;		/* for sys->vm */
} Hyper;
static Hyper hypers[] = {
	"vmware",	"VMwareVMware",	Vvmware,	Vmwarehyp,
	"virtualbox",	"VboxVboxVbox",	Voracle,	Virtualbox,
	"parallels",	"prl hyperv",	Vparallels,	Parallels,
	"qemu",		"",		Vqemu,		Qemuhyp,
	"qemu",		"",		Vqumranet,	Qemuhyp,
	0, 0, 0, 0,
};
static char *hypename = "an unknown hypervisor";

/* complain, unless it's a known bug in this hypervisor */
void
vmbotch(ulong vmbit, char *cause)
{
	if (sys->vm & vmbit)		/* in known vm */
		return;
	print("* Broken hardware or BIOS settings! ");
	if (sys->vm & Othervm)
		print("Am I running in %s, or is %s?\n", hypername(), cause);
	else
		print("%s\n", cause);
}

char *
hypername(void)
{
	return hypename;
}

static void
sethyper(Hyper *hype)
{
	sys->vm = hype->bit;
	hypename = hype->name;
	print("\tin a %s virtual machine\n", hypename);
}

/* are we running on imaginary hardware? */
void
checkhype(void)
{
	int hypecpuid;
	ulong regs[4];
	char hypid[Cpuidlen+1];
	Hyper *hype;
	static ulong zregs[4];

	if (m->machno != 0)
		return;
	sys->vm = conf.cpuidcx & Hypervisor? Othervm: 0;
	if (!sys->vm)
		return;
	hypecpuid = 1;
	memset(regs, 0, sizeof regs);
	cpuid(Hypercpuid, regs);

	/* if cpuid knew Hypercpuid, it zeroed regs to reject it on hw */
	if (memcmp(regs, zregs, sizeof regs) == 0)
		hypecpuid = 0;
	/* if cpuid didn't know Hypercpuid at all, it did nothing */
	zregs[0] = Hypercpuid;
	if (memcmp(regs, zregs, sizeof regs) == 0)
		hypecpuid = 0;
	zregs[0] = 0;
	if (hypecpuid) {
		/* NB: not the same order as normal cpuidid */
		memmove(hypid, &regs[1], Cpuidlen);	/* bx-dx */
		hypid[Cpuidlen] = '\0';
		for (hype = hypers; hype->id; hype++)
			if (strcmp(hypid, hype->id) == 0)
				break;
		if (hype->id)
			sethyper(hype);
	}
	/* else catch it by pci id in latecheckhype() */
}

/* if we don't know the hypervisor's maker, check pci ids */
void
latecheckhype(void)
{
	Hyper *hype;

	if (m->machno == 0 && sys->vm == Othervm) {
		for (hype = hypers; hype->id; hype++)
			if (pcimatch(0, hype->vid, 0) != nil)
				break;
		if (hype->id)
			sethyper(hype);
		else
			print("\t%s\n", hypename);
		if (hypename == nil)
			iprint("unknown hypervisor\n");
	}
}
