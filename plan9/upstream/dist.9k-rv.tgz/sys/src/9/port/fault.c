/*
 * page faults, including demand paging
 */
#include	"u.h"
#include	"../port/lib.h"
#include	"mem.h"
#include	"dat.h"
#include	"fns.h"
#include	"../port/error.h"

enum {
	Maxloops = 0,		/* if > 0, max. loops in fault() */
};

/*
 * we are supposed to get page faults only when in user mode
 * or processing system calls in kernel mode.
 * in kernel mode, we must not be holding Locks at the time.
 */
int
fault(uintptr addr, int read)
{
	int rv, loops;
	Segment *s;
	char *sps;

	if(up == nil)
		panic("fault: nil up");
	if(up->nlocks)
		print("fault: addr %#p: nlocks %ld\n", addr, up->nlocks);

	sps = up->psstate;
	up->psstate = "Fault";
	spllo();

	m->pfault++;
	rv = -1;
	loops = 0;
	for(;;) {
		s = seg(up, addr, 1);	/* leaves s->lk qlocked iff s != nil */
		if(s == nil)
			break;

		if(!read && (s->type&SG_RONLY)) { /* writing read-only page? */
			qunlock(&s->lk);
			break;
		}

		if(fixfault(s, addr, read, 1) == 0) {	/* qunlocks s->lk */
			/* all better; fixfault qunlocked s->lk */
			rv = 0;
			break;
		}
		/*
		 * See the comment in newpage that describes
		 * how to get here.
		 */
		if (Maxloops && ++loops > Maxloops)
			panic("fault: va %#p not fixed after %d iterations",
				addr, Maxloops);
	}
	USED(loops);

	up->psstate = sps;
	return rv;
}

static void
faulterror(char *s, Chan *c, int freemem)
{
	char buf[ERRMAX];

	if(c && c->path){
		snprint(buf, sizeof buf, "sys: %s accessing %s: %s",
			s, c->path->s, up->errstr);
		s = buf;
	}
	if(up->nerrlab) {
		postnote(up, 1, s, NDebug);
		error(s);
	}
	pexit(s, freemem);
}

void	(*checkaddr)(uintptr, Segment *, Page *);
uintptr	addr2check;

/* called with s->lk held */
int
fixfault(Segment *s, uintptr addr, int read, int doputmmu)
{
	int type, ref;
	Pte **p, *etp;
	uintptr mmuphys, soff;
	Page **pg, *lkp, *new;
	Page *(*fn)(Segment*, uintptr);

	addr &= ~(BY2PG-1ULL);
	soff = addr-s->base;
	p = &s->map[soff/PTEMAPMEM];
	if(*p == 0)
		*p = ptealloc();

	mmuphys = 0;
	etp = *p;
	pg = &etp->pages[(soff&(PTEMAPMEM-1))/BY2PG];
	type = s->type&SG_TYPE;

	if(pg < etp->first)
		etp->first = pg;
	if(pg > etp->last)
		etp->last = pg;

	switch(type) {
	default:
		panic("fault: bad segment type %d", type);
		break;

	case SG_TEXT: 			/* Demand load */
		if(pagedout(*pg))
			pio(s, addr, soff, pg);

		mmuphys = PPN((*pg)->pa) | PTERONLY|PTEVALID;
		(*pg)->modref = PG_REF;
		break;

	case SG_STACK:
	case SG_BSS:
	case SG_SHARED:			/* Zero fill on demand */
		if(*pg == 0) {
			new = newpage(1, &s, addr);
			if(s == 0)
				return -1;

			*pg = new;
		}
		goto common;

	case SG_DATA:
	common:			/* Demand load/pagein/copy on write */
		if(pagedout(*pg))
			pio(s, addr, soff, pg);

		/*
		 *  It's only possible to copy on write if
		 *  we're the only user of the segment.
		 */
		if(read && sys->copymode == 0 && s->ref == 1) {
			/* read-only unshared page loaded, not copy-on-reference */
			mmuphys = PPN((*pg)->pa)|PTERONLY|PTEVALID;
			(*pg)->modref |= PG_REF;
			break;
		}

		/* write access or copy on reference or shared segment */
		lkp = *pg;
		lock(lkp);

		if(lkp->image == &swapimage)
			ref = lkp->ref + swapcount(lkp->daddr);
		else
			ref = lkp->ref;
		if(ref <= 0)
			panic("fault: page->ref %d <= 0", ref);

		/* if unshared page, duplicate it */
		if(ref == 1 && lkp->image != nil){
			/* save a copy of the original for the image cache */
			duppage(lkp);
			ref = lkp->ref;
		}
		unlock(lkp);

		/* if page is now shared, allocate & populate a copy */
		if(ref > 1){
			new = newpage(0, &s, addr);
			if(s == 0)
				return -1;
			*pg = new;
			copypage(lkp, *pg);
			putpage(lkp);
		}
		mmuphys = PPN((*pg)->pa) | PTEWRITE | PTEVALID;
		(*pg)->modref = PG_MOD|PG_REF;
		break;

	case SG_PHYSICAL:
		if(*pg == 0) {
			fn = s->pseg->pgalloc;
			if(fn)			/* never used yet */
				*pg = (*fn)(s, addr);
			else {
				new = smalloc(sizeof(Page));
				new->va = addr;
				new->pa = s->pseg->pa+(addr-s->base);
				new->ref = 1;
				*pg = new;
			}
		}

		if (checkaddr && addr == addr2check)
			(*checkaddr)(addr, s, *pg);
		mmuphys = PPN((*pg)->pa) |PTEWRITE|PTEUNCACHED|PTEVALID;
		(*pg)->modref = PG_MOD|PG_REF;
		break;
	}
	qunlock(&s->lk);

	if(doputmmu)
		putmmu(addr, mmuphys, *pg);

	return 0;
}

/* called with s->lk held */
void
pio(Segment *s, uintptr addr, uintptr soff, Page **p)
{
	Page *new;
	KMap *k;
	Chan *c;
	int n, ask;
	char *kaddr;
	ulong daddr;
	Page *loadrec;

retry:
	loadrec = *p;
	if(loadrec == nil) {	/* from a text/data image */
		daddr = s->fstart+soff;
		new = lookpage(s->image, daddr);
		if(new != nil) {
			*p = new;
			return;
		}

		c = s->image->c;
		ask = s->flen-soff;
		if(ask > BY2PG)
			ask = BY2PG;
	}
	else {			/* from a swap image */
		daddr = swapaddr(loadrec);
		new = lookpage(&swapimage, daddr);
		if(new != nil) {
			putswap(loadrec);
			*p = new;
			return;
		}

		c = swapimage.c;
		ask = BY2PG;
	}
	qunlock(&s->lk);

	new = newpage(0, 0, addr);
//	if(new == nil)
//		panic("pio");	/* can't happen, s wasn't locked */

	k = kmap(new);
	kaddr = (char*)VA(k);

	while(waserror()) {
		if(strcmp(up->errstr, Eintr) == 0)
			continue;
		kunmap(k);
		putpage(new);
		faulterror(Eioload, c, 0);
	}

	/*
	 * we assume that this reads all `ask' bytes, which depends on the
	 * underlying file server.
	 */
	n = CHANDEV(c)->read(c, kaddr, ask, daddr);
	if(n != ask)
		faulterror(Eioload, c, 0);
	if(ask < BY2PG)
		memset(kaddr+ask, 0, BY2PG-ask);

	poperror();
	kunmap(k);
	qlock(&s->lk);
	if(loadrec == nil) {	/* This is demand load */
		/*
		 *  race, another proc may have gotten here first while
		 *  s->lk was unlocked
		 */
		if(*p == 0) { 
			new->daddr = daddr;
			cachepage(new, s->image);
			*p = new;
		}
		else
			putpage(new);
	}
	else {			/* This is paged out */
		/*
		 *  race, another proc may have gotten here first
		 *  (and the pager may have run on that page) while
		 *  s->lk was unlocked
		 */
		if(*p != loadrec){
			if(!pagedout(*p)){
				/* another process did it for me */
				putpage(new);
				goto done;
			} else {
				/* another process and the pager got in */
				putpage(new);
				goto retry;
			}
		}

		new->daddr = daddr;
		cachepage(new, &swapimage);
		*p = new;
		putswap(loadrec);
	}

done:
	if(s->flushme)
		memset((*p)->cachectl, PG_TXTFLUSH, sizeof((*p)->cachectl));
}

/*
 * Called only in a system call (or FP emulation)
 */
int
okaddr(uintptr addr, ulong len, int write)
{
	Segment *s;

	/* second test is paranoia only needed on 64-bit systems */
	if((long)len >= 0 && addr+len >= addr)
		while ((s = seg(up, addr, 0)) != nil &&
		    (!write || !(s->type&SG_RONLY))) {
			if((uvlong)addr+len <= s->top)
				return 1;
			len -= s->top - addr;
			addr = s->top;
		}
	pprint("suicide: invalid address %#p/%lud in sys call pc=%#p\n",
		addr, len, userpc(nil));
	return 0;
}

void
validaddr(uintptr addr, ulong len, int write)
{
	if(!okaddr(addr, len, write)){
		postnote(up, 1, "sys: bad address in syscall", NDebug);
		error(Ebadarg);
	}
}

/*
 * &s[0] is known to be a valid address.
 */
void*
vmemchr(void *s, int c, int n)
{
	int r;
	uintptr a;
	void *t;

	a = (uintptr)s;
	while(PGROUND(a) != PGROUND(a+n-1)){
		/* spans pages; handle this page */
		r = BY2PG - (a & (BY2PG-1));
		t = memchr((void*)a, c, r);
		if(t)
			return t;
		a += r;
		n -= r;
		if(a < KZERO)
			validaddr(a, 1, 0);
	}

	/* fits in one page */
	return memchr((void*)a, c, n);
}

/* if dolock and we return non-nil n, &n->lk will be qlocked. */
Segment*
seg(Proc *p, uintptr addr, int dolock)
{
	Segment **s, **et, *n;

	et = &p->seg[NSEG];
	for(s = p->seg; s < et; s++) {
		n = *s;
		if(n == 0)
			continue;
		if(addr >= n->base && addr < n->top) {
			if(dolock == 0)
				return n;

			qlock(&n->lk);
			if(addr >= n->base && addr < n->top)
				return n;
			qunlock(&n->lk);
		}
	}

	return 0;
}

extern void checkmmu(ulong, ulong);
void
checkpages(void)
{
#ifdef PAGE_DEBUG
	int checked;
	ulong addr, off;
	Pte *p;
	Page *pg;
	Segment **sp, **ep, *s;
	
	if(up == nil)
		return;

	checked = 0;
	for(sp=up->seg, ep=&up->seg[NSEG]; sp<ep; sp++){
		s = *sp;
		if(s == nil)
			continue;
		qlock(&s->lk);
		for(addr=s->base; addr<s->top; addr+=BY2PG){
			off = addr - s->base;
			p = s->map[off/PTEMAPMEM];
			if(p == 0)
				continue;
			pg = p->pages[(off&(PTEMAPMEM-1))/BY2PG];
			if(pg == 0 || pagedout(pg))
				continue;
			checkmmu(addr, pg->pa);
			checked++;
		}
		qunlock(&s->lk);
	}
	print("%ld %s: checked %d page table entries\n", up->pid, up->text, checked);
#endif
}
