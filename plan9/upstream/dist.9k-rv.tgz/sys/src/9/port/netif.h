typedef struct Netaddr	Netaddr;
typedef struct Netfile	Netfile;
typedef struct Netif	Netif;

enum
{
	Nmaxaddr=	64,
	Nmhash=		31,		/* must be <= 8*sizeof Netfile->maddr */

	Ncloneqid=	1,
	Naddrqid,
	N2ndqid,
	N3rdqid,
	Ndataqid,
	Nctlqid,
	Nstatqid,
	Ntypeqid,
	Nifstatqid,
};

/*
 *  Macros to manage Qid's used for multiplexed devices
 */
#define NETTYPE(x)	((ulong)(x) & MASK(5))
#define NETID(x)	((ulong)(x) >> 5)
#define NETQID(i,t)	(((ulong)(i) << 5) | (t))

/*
 *  one per multiplexed connection
 */
struct Netfile
{
	QLock;

	int	inuse;
	ulong	mode;
	char	owner[KNAMELEN];

	int	type;			/* multiplexor type */
	int	prom;			/* promiscuous mode */
	int	scan;			/* base station scanning interval */
	int	bridge;			/* bridge mode */
	int	headersonly;		/* headers only - no data */
	uchar	maddr[8];		/* bitmask of multicast addresses requested */
	int	nmaddr;			/* number of multicast addresses */

	Queue*	iq;			/* input buffer (was "in") */
};

/*
 *  a network address
 */
struct Netaddr
{
	Netaddr	*next;			/* allocation chain */
	Netaddr	*hnext;
	uchar	addr[Nmaxaddr];
	int	ref;
};

/*
 *  a network interface
 *
 *  Netif is embedded in Ether.
 */
struct Netif
{
	QLock;

	/* multiplexing */
	int	nfile;			/* max number of Netfiles */
	Netfile	**f;			/* each Netfile has an input queue */
	char	name[KNAMELEN];		/* for top level directory */

	/* about net */
	uint	limit;			/* flow control */
	int	alen;			/* address length */
	int	mbps;			/* megabits per sec */
	int	link;			/* link status */
	Queue*	oq;			/* output */
	uchar	addr[Nmaxaddr];
	uchar	bcast[Nmaxaddr];
	Netaddr	*maddr;			/* known multicast addresses */
	int	nmaddr;			/* number of known multicast addresses */
	Netaddr *mhash[Nmhash];	/* hash table of multicast addresses */
	int	prom;		/* number of promiscuous opens */
	int	all;		/* number of -1 multiplexors */
	int	scan;		/* # of wireless base station scanners */

	/* statistics */
	int	misses;
	uvlong	inpackets;
	uvlong	outpackets;
	int	crcs;			/* input crc errors */
	int	oerrs;			/* output errors */
	int	frames;			/* framing errors */
	int	overflows;		/* packet overflows */
	int	buffs;			/* buffering errors */
	int	soverflows;		/* software overflow */

	/* routines for touching the hardware */
	void	*arg;
	void	(*promiscuous)(void*, int);
	void	(*multicast)(void*, uchar*, int);
	void	(*scanbs)(void*, uint);	/* scan for wireless base stations */
};

void	netifinit(Netif*, char*, int, ulong);
Walkqid*	netifwalk(Netif*, Chan*, Chan*, char **, int);
Chan*	netifopen(Netif*, Chan*, int);
void	netifclose(Netif*, Chan*);
long	netifread(Netif*, Chan*, void*, long, Brwlen);
Block*	netifbread(Netif*, Chan*, long, Brwlen);
long	netifwrite(Netif*, Chan*, void*, long);
Sysstatlen netifwstat(Netif*, Chan*, uchar*, Sysstatlen);
Sysstatlen netifstat(Netif*, Chan*, uchar*, Sysstatlen);
int	activemulti(Netif*, uchar*, int);
