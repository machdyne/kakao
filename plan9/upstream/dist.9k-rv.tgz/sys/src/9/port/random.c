#include	"u.h"
#include	"../port/lib.h"
#include	"mem.h"
#include	"dat.h"
#include	"fns.h"

#include	"../port/error.h"
#include	<libsec.h>

struct Rb
{
	QLock;
	Rendez	producer;
	Rendez	consumer;
	ulong	randomcount;
	uchar	buf[1024];
	uchar	*ep;
	uchar	*rp;
	uchar	*wp;
	uchar	next;
	uchar	wakeme;
	ushort	bits;
	ulong	randn;
} rb;

static int
rbnotfull(void*)
{
	intptr i;

	if (active.exiting)
		return 1;		/* don't sleep */
	i = rb.rp - rb.wp;
	return i != 1 && i != (1 - (vlong)sizeof(rb.buf));
}

static int
rbnotempty(void*)
{
	if (active.exiting)
		return 1;		/* don't sleep */
	return rb.wp != rb.rp;
}

/* called spllo from linkproc */
static void
randomproc(void*)
{
	spllo();
	up->basepri = 2;		/* don't hog the cpu at start-up */
	up->priority = up->basepri;

	while (!active.exiting){
		while (++rb.randomcount <= 100000)
			;
		if (active.exiting)
			break;
		if(anyhigher())
			sched();	/* don't hog the cpu */
		if(!rbnotfull(0))
			sleep(&rb.producer, rbnotfull, 0);
	}
	pexit("", 1);
}

/*
 *  produce random bits in a circular buffer
 */
static void
randomclock(void)
{
	if(rb.randomcount == 0 || !rbnotfull(0))
		return;

	rb.bits = (rb.bits<<2) ^ rb.randomcount;
	rb.randomcount = 0;

	rb.next++;
	if(rb.next != 8/2)
		return;
	rb.next = 0;

	*rb.wp ^= rb.bits;
	if(rb.wp+1 == rb.ep)
		rb.wp = rb.buf;
	else
		rb.wp = rb.wp+1;

	if(rb.wakeme)
		wakeup(&rb.consumer);
}

void
randominit(void)
{
	/* Frequency close but not equal to HZ */
	addclock0link(randomclock, 13);
	rb.ep = rb.buf + sizeof(rb.buf);
	rb.rp = rb.wp = rb.buf;
	kproc("genrandom", randomproc, 0);
}

/*
 *  consume random bytes from a circular buffer
 */
static void
seedfromrb(void *xp, int n)
{
	uchar *e, *p;
	ulong x;

	p = xp;
	if(waserror()){
		qunlock(&rb);
		nexterror();
	}

	qlock(&rb);
	for(e = p + n; p < e; ){
		if(rb.wp == rb.rp){
			rb.wakeme = 1;
			wakeup(&rb.producer);
			sleep(&rb.consumer, rbnotempty, 0);
			rb.wakeme = 0;
			continue;
		}

		/*
		 *  beating clocks will be predictable if
		 *  they are synchronized.  Use a cheap pseudo-
		 *  random number generator to obscure any cycles.
		 */
		x = rb.randn*1103515245 ^ *rb.rp;
		*p++ = rb.randn = x;

		if(rb.rp+1 == rb.ep)
			rb.rp = rb.buf;
		else
			rb.rp = rb.rp+1;
	}
	qunlock(&rb);
	poperror();

	wakeup(&rb.producer);
}

ulong
randomread(void *p, ulong n)
{
	Chachastate chast;
	static int seeded;
	static QLock lk;
	static Chachastate initst;

	if(n == 0)
		return 0;

	qlock(&lk);
	if(waserror()){
		qunlock(&lk);
		nexterror();
	}
	if(!seeded){
		uchar seed[32+12];

		seedfromrb(seed, sizeof seed);
		setupChachastate(&initst, seed, 32, seed+32, /* 12, */ 20);
		memset(seed, 0, sizeof seed);
		seeded = 1;
	}

	chast = initst;
	/*
	 * for next read, rekey by encrypting the key in initial state, using
	 * current key, and in place.  this read will use current key and other
	 * state.
	 */
	chacha_encrypt((uchar*)initst.key, sizeof initst.key, &chast);
	if(++initst.iv[0] == 0)		/* wrapped? carry to next byte */
		if(++initst.iv[1] == 0)
			++initst.iv[2];
	poperror();
	qunlock(&lk);

	/* encrypt whatever garbage is in p.  can page fault. */
	chacha_encrypt((uchar*)p, n, &chast);
	memset(&chast, 0, sizeof chast);	/* prevent state leakage */
	return n;
}
