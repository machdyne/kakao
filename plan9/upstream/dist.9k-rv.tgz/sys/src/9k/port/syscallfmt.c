/*
 * Print functions for system call tracing.
 */
#include "u.h"
#include "../port/lib.h"
#include "mem.h"
#include "dat.h"
#include "fns.h"

#include "/sys/src/libc/9syscall/sys.h"

static void
fmtrwdata(Fmt* f, char* a, int n, char* suffix)
{
	int i, c;
	char *t;

	if(a == nil){
		fmtprint(f, "0x0%s", suffix);
		return;
	}
	a = validaddr(a, n, 0);
	t = smalloc(n+1);
	for(i = 0; i < n; i++){
		c = a[i];
		t[i] = c > ' ' && c <= '~'? c: '.';
	}
	t[n] = 0;
	fmtprint(f, " %#p/\"%s\"%s", a, t, suffix);
	free(t);
}

static void
fmtuserstring(Fmt* f, char* a, char* suffix)
{
	int n;
	char *t;

	if(a == nil){
		fmtprint(f, "0/\"\"%s", suffix);
		return;
	}
	a = validaddr(a, 1, 0);
	n = (char*)vmemchr(a, 0, 0x7fffffff) - a + 1;
	t = smalloc(n);
	memmove(t, a, n);
	t[n-1] = 0;
	fmtprint(f, "%#p/\"%s\"%s", a, t, suffix);
	free(t);
}

void
syscallfmt(uint syscallno, va_list list)
{
	int i;
	long l;
	vlong vl;
	char *a, *snm, **argv;
	void *v;
	Fmt fmt;

	fmtstrinit(&fmt);
	fmtprint(&fmt, "%d %s ", (int)up->pid, up->text);

	if(syscallno >= nsyscall)
		fmtprint(&fmt, " %d ", syscallno);
	else {
		snm = systab[syscallno].n;
		fmtprint(&fmt, "%s ", snm? snm: "huh?");
	}

	if(up->syscalltrace != nil) {
		free(up->syscalltrace);
		up->syscalltrace = nil;
	}

	switch(syscallno){
	case SYSR1:
		fmtprint(&fmt, "%#p", va_arg(list, uintptr));
		break;
	case _ERRSTR:					/* deprecated */
	case CHDIR:
	case EXITS:
	case REMOVE:
		fmtuserstring(&fmt, va_arg(list, char*), "");
		break;
	case BIND:
		fmtuserstring(&fmt, va_arg(list, char*), " ");
		fmtuserstring(&fmt, va_arg(list, char*), " ");
		fmtprint(&fmt, "%#ux", va_arg(list, int));
		break;
	case CLOSE:
	case NOTED:
		fmtprint(&fmt, "%d", va_arg(list, int));
		break;
	case DUP:
		i = va_arg(list, int);
		fmtprint(&fmt, "%d %d", i, va_arg(list, int));
		break;
	case ALARM:
		fmtprint(&fmt, "%#lud ", va_arg(list, ulong));
		break;
	case EXEC:
		fmtuserstring(&fmt, va_arg(list, char*), "");
		argv = va_arg(list, char**);
		evenaddr((uintptr)argv);
		for(;;){
			a = *(char**)validaddr(argv, sizeof(char**), 0);
			if(a == nil)
				break;
			fmtprint(&fmt, " ");
			fmtuserstring(&fmt, a, "");
			argv++;
		}
		break;
	case _FSESSION:					/* deprecated */
	case _FSTAT:					/* deprecated */
	case _FWSTAT:					/* obsolete */
		i = va_arg(list, int);
		fmtprint(&fmt, "%d %#p", i, va_arg(list, char*));
		break;
	case FAUTH:
		fmtprint(&fmt, "%d", va_arg(list, int));
		fmtuserstring(&fmt, va_arg(list, char*), "");
		break;
	case SEGBRK:
	case RENDEZVOUS:
		fmtprint(&fmt, "%#p ", va_arg(list, void*));
		fmtprint(&fmt, "%#p", va_arg(list, void*));
		break;
	case _MOUNT:					/* deprecated */
		fmtprint(&fmt, "%d ", va_arg(list, int));
		fmtuserstring(&fmt, va_arg(list, char*), " ");
		fmtprint(&fmt, "%#ux ", va_arg(list, int));
		fmtuserstring(&fmt, va_arg(list, char*), "");
		break;
	case OPEN:
		fmtuserstring(&fmt, va_arg(list, char*), " ");
		fmtprint(&fmt, "%#ux", va_arg(list, int));
		break;
	case OSEEK:					/* deprecated */
		i = va_arg(list, int);
		l = va_arg(list, long);
		fmtprint(&fmt, "%d %ld %d", i, l, va_arg(list, int));
		break;
	case SLEEP:
		fmtprint(&fmt, "%ld", va_arg(list, long));
		break;
	case _STAT:					/* obsolete */
	case _WSTAT:					/* obsolete */
		fmtuserstring(&fmt, va_arg(list, char*), " ");
		fmtprint(&fmt, "%#p", va_arg(list, char*));
		break;
	case RFORK:
		fmtprint(&fmt, "%#ux", va_arg(list, int));
		break;
	case PIPE:
	case BRK_:
		fmtprint(&fmt, "%#p", va_arg(list, int*));
		break;
	case CREATE:
		fmtuserstring(&fmt, va_arg(list, char*), " ");
		i = va_arg(list, int);
		fmtprint(&fmt, "%#ux %#ux", i, va_arg(list, int));
		break;
	case FD2PATH:
	case FSTAT:
	case FWSTAT:
		i = va_arg(list, int);
		a = va_arg(list, char*);
		fmtprint(&fmt, "%d %#p %lud", i, a, va_arg(list, ulong));
		break;
	case NOTIFY:
	case SEGDETACH:
	case _WAIT:					/* deprecated */
		fmtprint(&fmt, "%#p", va_arg(list, void*));
		break;
	case SEGATTACH:
		fmtprint(&fmt, "%d ", va_arg(list, int));
		fmtuserstring(&fmt, va_arg(list, char*), " ");
		/* fall through */
	case SEGFREE:
	case SEGFLUSH:
		v = va_arg(list, void*);
		fmtprint(&fmt, "%#p %lud", v, va_arg(list, ulong));
		break;
	case UNMOUNT:
		fmtuserstring(&fmt, va_arg(list, char*), " ");
		fmtuserstring(&fmt, va_arg(list, char*), "");
		break;
	case SEMACQUIRE:
	case SEMRELEASE:
		v = va_arg(list, int*);
		fmtprint(&fmt, "%#p %d", v, va_arg(list, int));
		break;
	case TSEMACQUIRE:
		v = va_arg(list, long*);
		fmtprint(&fmt, "%#p %ld", v, va_arg(list, ulong));
		break;
	case SEEK:
		v = va_arg(list, vlong*);
		i = va_arg(list, int);
		vl = va_arg(list, vlong);
		fmtprint(&fmt, "%#p %d %#llux %d", v, i, vl, va_arg(list, int));
		break;
	case FVERSION:
		i = va_arg(list, int);
		fmtprint(&fmt, "%d %d ", i, va_arg(list, int));
		fmtuserstring(&fmt, va_arg(list, char*), " ");
		fmtprint(&fmt, "%lud", va_arg(list, ulong));
		break;
	case WSTAT:
	case STAT:
		fmtuserstring(&fmt, va_arg(list, char*), " ");
		/* fall through */
	case ERRSTR:
	case AWAIT:
		a = va_arg(list, char*);
		fmtprint(&fmt, "%#p %lud", a, va_arg(list, ulong));
		break;
	case MOUNT:
		i = va_arg(list, int);
		fmtprint(&fmt, "%d %d ", i, va_arg(list, int));
		fmtuserstring(&fmt, va_arg(list, char*), " ");
		fmtprint(&fmt, "%#ux ", va_arg(list, int));
		fmtuserstring(&fmt, va_arg(list, char*), "");
		break;
	case _READ:					/* deprecated */
	case PREAD:
		i = va_arg(list, int);
		v = va_arg(list, void*);
		fmtprint(&fmt, "%d %#p %ld", i, v, va_arg(list, long));
		if(syscallno == PREAD)
			fmtprint(&fmt, " %lld", va_arg(list, vlong));
		break;
	case _WRITE:					/* deprecated */
	case PWRITE:
		fmtprint(&fmt, "%d ", va_arg(list, int));
		v = va_arg(list, void*);
		l = va_arg(list, long);
		fmtrwdata(&fmt, v, MIN(l, 64), " ");
		fmtprint(&fmt, "%ld", l);
		if(syscallno == PWRITE)
			fmtprint(&fmt, " %lld", va_arg(list, vlong));
		break;
	case NSEC:
		/* compilers on 32-bit systems insert &ret as only argument */
		if (sizeof(void *) < sizeof(vlong))
			fmtprint(&fmt, "%#p", va_arg(list, vlong*));
		break;
	}
	va_end(list);
	up->syscalltrace = fmtstrflush(&fmt);
}

void
sysretfmt(int syscallno, va_list list, Ar0* ar0, uvlong start, uvlong stop)
{
	int i;
	long l;
	char *a, *errstr;
	void* v;
	Fmt fmt;

	fmtstrinit(&fmt);

	if(up->syscalltrace) {
		free(up->syscalltrace);
		up->syscalltrace = nil;
	}

	errstr = "\"\"";
	switch(syscallno){
	default:
		if(ar0->i == -1)
			errstr = up->errstr;
		fmtprint(&fmt, " = %d", (int)ar0->i);
		break;
	case ALARM:
	case _WRITE:
	case PWRITE:
		if(ar0->l == -1)
			errstr = up->errstr;
		fmtprint(&fmt, " = %ld", (long)ar0->l);
		break;
	case NSEC:
		fmtprint(&fmt, " = %lld", ar0->vl);
		break;
	case EXEC:
	case SEGBRK:
	case SEGATTACH:
	case RENDEZVOUS:
		if(ar0->v == (void*)-1)
			errstr = up->errstr;
		fmtprint(&fmt, " = %#p", ar0->v);
		break;
	case AWAIT:
		a = va_arg(list, char*);
		l = va_arg(list, ulong);
		if(ar0->i > 0){
			fmtuserstring(&fmt, a, " ");
			fmtprint(&fmt, "%lud = %d", l, (int)ar0->i);
		} else {
			fmtprint(&fmt, "%#p/\"\" %lud = %d", a, l, (int)ar0->i);
			errstr = up->errstr;
		}
		break;
	case _ERRSTR:
	case ERRSTR:
		a = va_arg(list, char*);
		if(syscallno == _ERRSTR)
			l = 64;
		else
			l = va_arg(list, ulong);
		if(ar0->i > 0){
			fmtuserstring(&fmt, a, " ");
			fmtprint(&fmt, "%lud = %d", l, (int)ar0->i);
		} else {
			fmtprint(&fmt, "\"\" %lud = %d", l, (int)ar0->i);
			errstr = up->errstr;
		}
		break;
	case FD2PATH:
		i = va_arg(list, int);
		USED(i);
		a = va_arg(list, char*);
		l = va_arg(list, ulong);
		if(ar0->i > 0){
			fmtuserstring(&fmt, a, " ");
			fmtprint(&fmt, "%lud = %d", l, (int)ar0->i);
		} else {
			fmtprint(&fmt, "\"\" %lud = %d", l, (int)ar0->i);
			errstr = up->errstr;
		}
		break;
	case _READ:
	case PREAD:
		i = va_arg(list, int);		/* fd */
		USED(i);
		v = va_arg(list, void*);
		if(ar0->l > 0)
			fmtrwdata(&fmt, v, MIN(ar0->l, 64), "");
		else {
			fmtprint(&fmt, "/\"\"");
			errstr = up->errstr;
		}
		fmtprint(&fmt, " %ld", va_arg(list, long));
		if(syscallno == PREAD)
			fmtprint(&fmt, " %lld", va_arg(list, vlong));
		fmtprint(&fmt, " = %d", (int)ar0->i);
		break;
	}
	va_end(list);
	fmtprint(&fmt, " %s %#llud %#llud\n", errstr, start, stop);

	up->syscalltrace = fmtstrflush(&fmt);
}
