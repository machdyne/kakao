.HTML "The Various Ports
.TL
The Various Ports
.PP
This document collects comments about the various
architectures supported by Plan 9.
The system tries to hide most of the differences between machines,
so the machines as seen by a Plan 9
user look different from how they are perceived through commercial software.
Also, because we are a small group, we couldn't do everything:
exploit every optimization, support every model,
drive every device.
This document records what we
.I have
done.
The first section discusses the compiler/assembler/loader suite for each machine.
The second talks about
the operating system implemented on each of the various
machines.
.
.SH
The MIPS compiler
.PP
This compiler generates code for the R2000, R3000, and R4000 machines configured
to be big-endians.  The compiler generates no R4000-specific instructions
although the assembler and loader support the new user-mode instructions.
There are options to generate code for little-endian machines.
Considering its speed, the Plan 9 compiler generates good code,
but the commercial
MIPS compiler with all the stops pulled out consistently beats it
by 20% or so, sometimes more.  Since ours compiles about 10 times
faster and we spend most of our time compiling anyway,
we are content with the tradeoff.
.PP
The compiler is solid: we've used it for several big projects and, of course,
all our applications run under it.
The behavior of floating-point programs is much like on the 68040:
the operating system emulates where necessary to get past non-trapping
underflow and overflow, but does not handle gradual underflow or
denormalized numbers or not-a-numbers.
.ig
.SH
The SPARC compiler
.PP
The SPARC compiler is also solid and fast, although we haven't
used it for a few years, due to a lack of current hardware.  We have seen it do
much better than GCC with all the optimizations, but on average
it is probably about the same.
.PP
We used to run some old SPARC machines with no multiply or divide instructions,
so the compiler
does not produce them by default.
Instead it calls internal subroutines.
A loader flag,
.CW -M ,
causes the instructions to be emitted.  The operating system has
trap code to emulate them if necessary, but the traps are slower than
emulating them in user mode.
In any modern lab, in which SPARCS have the instructions, it would be worth enabling the
.CW -M
flag by default.
.PP
The floating point story is the same as on the MIPS.
..
.SH
The Intel i386 compiler
.PP
This is really an
.I x 86
compiler, for
.I x >2.
It works only
if the machine is in 32-bit protected mode.
It is solid and generates tolerable code; it was our main compiler for years.
.PP
Floating point is well-behaved, but the compiler assumes i387-compatible
hardware to execute
the instructions.  With 387 hardware,
the system does the full IEEE 754 job, just like
the MC68881.  By default, the libraries don't use the 387 built-ins for
transcendentals.
If you want them,
build the code in
.CW /sys/src/libc/386/387 .
.
.SH
The AMD64 compiler
.PP
The AMD64 compiler has been used to build 64-bit variants of Plan 9.
It seems to be reasonably solid and is heavily used.
.
.SH
The PowerPC compiler
.PP
The PowerPC compiler supports the 32-bit PowerPC architecture only;
it does not support either the 64-bit extensions or the POWER compatibility instructions.
It has been used for production operating system work on the
603, 603e, 604e, 821, 823, and 860,
and experimental work on the 405, 440 and 450.
On the 8xx floating-point instructions must be emulated.
Instruction scheduling is not implemented; otherwise the code generated
is similar to that for the other load-store architectures.
The compiler makes little or no use of unusual PowerPC features such as the
counter register, several condition code registers, and multiply-accumulate
instructions, but they are sometimes
used by assembly language routines in the libraries.
.
.SH
The PowerPC64 compiler
.PP
The PowerPC64 compiler supports the 64-bit PowerPC architecture only.
It has been lightly used on IBM's Blue Gene supercomputers.
.
.SH
The ARM compiler
.PP
The ARM compiler is fairly solid; it has been used for some production
operating system work including Inferno and the Plan 9 kernel
for the iPAQ, which uses a StrongArm SA1, and the Sheevaplug,
Guruplug, Dreamplug, Gumstix Overo, Compulab Trimslice, Raspberry Pi and others.
The compiler supports the ARMv4 and later 32-bit architectures;
it does not support the Thumb instruction sets.
It has been used on ARM7500FE, ARM926 and Cortex-A8 and -A9 processors
and the Strongarm SA1 core machines.
The compiler generates instructions for
ARM 7500 FPA floating-point coprocessor 1 by default,
but
.CW 5l
.CW -f
instead generates VFP instructions for coprocessors 10 and 11.
VFP instructions will use only the first 16 floating-point registers.
.
.SH
The ARM64 compiler
.PP
The ARM64 compiler supports the ARMv8 and later 64-bit architectures.
However, there aren't many suitable systems available as porting targets
(Apple's are locked down, Raspberry Pi is poorly documented).
.
.SH
The RISC-V compilers
.PP
There are compiler suites for RV32GC
.I ic , (
etc.)
and RV64GC
.I jc , (
etc.),
built from common source.
They now routinely compile the entire system successfully.
Unusually,
the RV64 architecture requires natural alignment for scalars,
up to and including pointers and
.I vlong s.
The loaders by default produce compressed instructions where possible.
.
.SH
The IBM PC operating system
.PP
The PC version of Plan 9 can boot via PXE
or directly from a disk created by the
.CW format
command; see
.I prep (8).
Plan 9 runs in 32-bit mode\(emwhich requires a 386 or later model x86 processor\(emand
has an interrupt-driven I/O system, so it does not
use the BIOS
(except for a small portion of the boot program and floppy boot block,
and a bit of kernel memory map and VGA initialisation).
This helps performance but limits the set of I/O devices that it can support without
special code.
It currently expects a pre-(U)EFI BIOS, or at least one with CSM enabled.
.PP
Some older code for machines that are no longer available has been dropped.
In practice, you'll need a Pentium or newer (not much of a restriction)
and PCI or PCI-Express built-in controllers or add-in cards.
We intend that machines built after 2000 should work; earlier ones may not.
.PP
Plan 9 supports the ISA, PCI, and PCI-Express buses.
There is some support for USB devices, but they are inherently speed-limited.
It is infeasible to list all the supported machines, because
the PC-clone marketplace is too volatile and there is
no guarantee that the machine you buy today will contain the
same components as the one you bought yesterday.
IDE/ATA, SATA, and NVMe disks (magnetic or solid-state) are supported.
Optical disc (CD, DVD, BD) readers and writers are supported
on the USB bus, or as (S)ATA(PI) devices.
SCSI support has been dropped, but is still the canonical I/O method
internally.
.PP
Supported Ethernet cards include the
AMD79C790,
NE2000,
WD8013,
Realtek 8139,
and a variety of controllers based on the
Intel i8255[789]
chips at 10 or 100 Mb/s.
These slower interfaces are supported primarily to aid running
Plan 9 in a virtual machine.
We support Gigabit Ethernet via
Realtek 8110S/8169S,
and
Intel 8254[013467], 8256[367], 8257[1-79], and i21[0178] controllers.
We support 10-Gigabit Ethernet via Intel's 8259[89] and x5[45]0 controllers.
THe x540 runs hotter than the x550.
.PP
There must be an explicit Plan 9 driver for peripherals;
it cannot use DOS or Windows drivers.
Plan 9 cannot exploit special hardware-related features that fall outside of the
IBM PC model,
such as power management,
unless architecture-dependent code is added to the kernel.
For more details see
.I plan9.ini (8).
.PP
Over the years,
Plan 9 has run on a number of VGA cards.
Changes circa 2000 to the graphics system have not been
tested on most of the older cards;
some effort may be needed to get them working again.
In our lab, most of our machines use the ATI or Nvidia chips,
so such devices are probably the most reliable.
The system requires a hardware cursor.
Vesa mode should work on any card,
though the higher resolutions have not been tested.
For more details see
.I vgadb (6)
and
.I vga (8).
.PP
For audio, Plan 9 has
user-level support for USB audio devices; see 
.I usb (4).
.PP
Finally, it's important to have a three-button mouse with Plan 9.
The system currently works only with mice on the PS/2 port or USB.
.PP
Once you have Plan 9 installed,
use PXE or a boot disk to load the system.  See
.I booting (8),
.I 9boot (8),
and
.I prep (8)
for more information.
.
.SH
The AMD64 operating system
.PP
A variant 64-bit kernel,
.I 9k ,
includes a port to the AMD64 processors from the K10 forward,
and compatible modern Intel64 processors.
These CPUID features are required by the AMD64 base-line specification
and some are assumed by this port:
FPU, CX8, CMOV, MMX, FXSR, SSE, SSE2, OSFXSR, SCE, and LM.
It started out as the PC port and shares some (mostly PCI-E)
device drivers with it, but there are also divergences.
It includes CPU and terminal kernels which
.I 9boot
can load.
It has been quite solid and used to run largish file and CPU servers.
.
.ig
.SH
The Routerboard 450G operating system
.PP
This is a CPU kernel that runs on the Mikrotik Routerboard RB450G,
which contains a MIPS 24K CPU
(the Atheros 7161), which implements the MIPS32R2 architecture.
It has 256MB of RAM and a serial port.
The CPU lacks the 64-bit instructions of previous MIPS systems (e.g.,
SGI Challenge and Carrera).
There is no hardware floating-point, so we emulate the instructions.
Only the first of the five Gigabit Ethernet ports is currently supported;
the other four are connected via an internal switch.
To avoid a bug in the CPU (erratum 48), we run the caches write-through,
rather than write-back, and compiled
.CW /mips
with a
.I vl
modified to emit enough NOPs to avoid three consecutive store instructions
(see
.CW /sys/src/cmd/vl/noop.c
to enable this).
..
.
.SH
The PowerPC operating system
.PP
We have a version of the system that runs on the PowerPC
on a home-grown machine called Viaduct.
The Viaduct minibrick is a small (12x9x3 cm) low-cost embedded
computer consisting of a 50Mhz MPC850, 16MB sdram, 2MB flash,
and two 10Mb Ethernet ports.  It is designed for home/SOHO
networking applications such as VPN, firewalls, NAT, etc.
.PP
The kernel has also been ported to the Motorola MTX embedded motherboard;
that port is included in the distribution.
The port only works with a 604e processor (the 603e is substantially different)
and at present only a single CPU is permitted.
.PP
We have ports to the Xilinx Virtex 4 ML410 and Virtex 5 ML510 FPGAs
which have PowerPC 405 and 440 processors, respectively.
.
.ig
.SH
The Marvell Kirkwood operating system
.PP
This is an ARM kernel for the ARM926EJ-S processor
and it emulates ARM 7500 floating-point and
CAS (compare-and-swap) instructions.
It is known to run on the Sheevaplug, Guruplug, Dreamplug
and Openrd-client boards.
It is derived from a port of native Inferno to the Sheevaplug
by Salva Peir\f(Jpó\fP and Mechiel Lukkien.
There are many features of the Kirkwood system-on-a-chip
that it does not exploit.
There are currently drivers for up to two
Gigabit Ethernet interfaces,
USB and the console serial port;
we hope to add crypto acceleration, and a video driver for the Openrd-client.
.SH
The Marvell PXA168 operating system
.PP
This is an ARM kernel for the ARM-v5-architecture processor in the
Marvell PXA168 system-on-a-chip
and it emulates ARM 7500 floating-point and
CAS (compare-and-swap) instructions.
It is known to run on the Guruplug Display.
There are many features of the system-on-a-chip
that it does not exploit.
There are currently drivers for
a Fast Ethernet interface,
and the console serial port;
we hope to add crypto acceleration, and a video driver.
.SH
The TI OMAP35 operating system
.PP
This is an ARM kernel for the Cortex-A8 processor
and it emulates ARM 7500 floating-point and
CAS (compare-and-swap) instructions.
It is known to run on the IGEPv2 board and the Gumstix Overo,
and might eventually run on the Beagleboard, once USB is working.
There are many features of the OMAP system-on-a-chip that it does not exploit.
Initially, there are drivers for the SMSC 9221 100Mb/s Ethernet
interface in the IGEPv2 and Overo,
and the console serial port;
we hope to add USB, flash memory and video drivers.
.SH
The Nvidia Tegra2 operating system
.PP
This is an ARM kernel for the dual Cortex-A9 processors
in the Nvidia Tegra2 system-on-a-chip.
It emulates ARM 7500 FPA
.I and
VFP floating-point, but
the hardware includes VFP3 floating-point.
It runs on the Compulab Trimslice.
There are many features of the system-on-a-chip that it does not exploit.
Initially, there are drivers for the Ethernet interface
and the console serial port;
one could add USB, flash memory and video drivers.
..
.
.SH
The Broadcom 2835 operating system
.PP
This consists of terminal and CPU kernels for the ARM1176 processor
in the Broadcom 2835 system-on-a-chip
and its successors.
The hardware includes VFP2 floating-point.
It runs on the 32-bit Raspberry Pis Models A and B,
2, 3 and 4.
.
.SH
The RISC-V operating systems
.PP
These are
.I 9k
64-bit CPU kernels for RV64GC RISC-V systems.
They can be configured to run on bare hardware in `machine' mode or
with HSS, SBI and U-boot in `supervisor' mode.
Floating-point hardware is assumed.
Machine-mode kernels can be run in a modified
.I tinyemu
emulator which adds a UART,
emulating bare hardware with a single `hart' (core, processor, CPU).
.PP
The RV64 kernel can be run in supervisor mode
on the Polarfire Icicle board,
which contains one management core
(an E51 with no floating-point and no supervisor mode)
and four full 600MHz RISC-V RV64GC cores (U54).
There are four UARTS, which appear as 16550s to the RISC-V cores
but present a single physical micro-USB interface carrying all four UARTS
as USB serial ports.
The second Ethernet interface is known to work;
the first is present but untested.
Ethernet speed is fixed at a gigabit/second.
There are as-yet unsupported devices, including
an FPGA,
a USB interface,
and
an open PCI-E slot.
.PP
The RV64 kernel also runs on
the Starfive Visionfive 2,
the (now discontinued) pre-release Beagle V,
HiFive Unmatched U74,
HiFive Premier P550,
and Milk-V Jupiter boards.
It does not run on the RVB-ICE with Xuantie C910 CPU
but it's so buggy that that is no great loss.
