/*
 * #P/cputype, shutdown and timing.
 */
#include "u.h"
#include "../port/lib.h"
#include "mem.h"
#include "dat.h"
#include "fns.h"
#include "../port/error.h"
#include "riscv64.h"

#include <ctype.h>

enum {
	Qdir = 0,
	Qbase,

	Qmax = 16,
};

typedef long Rdwrfn(Chan*, void*, long, vlong);

static Rdwrfn *readfn[Qmax];
static Rdwrfn *writefn[Qmax];

static Dirtab archdir[Qmax] = {
	".",		{ Qdir, 0, QTDIR },	0,	0555,
};
Lock archwlock;	/* the lock is only for changing archdir */
int narchdir = Qbase;

extern Dev archdevtab;

/*
 * Add a file to the #P listing.  Once added, you can't delete it.
 * You can't add a file with the same name as one already there,
 * and you get a pointer to the Dirtab entry so you can do things
 * like change the Qid version.  Changing the Qid path is disallowed.
 */
Dirtab*
addarchfile(char *name, int perm, Rdwrfn *rdfn, Rdwrfn *wrfn)
{
	int i;
	Dirtab d;
	Dirtab *dp;

	memset(&d, 0, sizeof d);
	strcpy(d.name, name);
	d.perm = perm;

	lock(&archwlock);
	if(narchdir >= Qmax){
		unlock(&archwlock);
		return nil;
	}

	for(i=0; i<narchdir; i++)
		if(strcmp(archdir[i].name, name) == 0){
			unlock(&archwlock);
			return nil;
		}

	d.qid.path = narchdir;
	archdir[narchdir] = d;
	readfn[narchdir] = rdfn;
	writefn[narchdir] = wrfn;
	dp = &archdir[narchdir++];
	unlock(&archwlock);
	return dp;
}

static Chan*
archattach(char* spec)
{
	return devattach(archdevtab.dc, spec);
}

Walkqid*
archwalk(Chan* c, Chan *nc, char** name, int nname)
{
	return devwalk(c, nc, name, nname, archdir, narchdir, devgen);
}

static long
archstat(Chan* c, uchar* dp, long n)
{
	return devstat(c, dp, n, archdir, narchdir, devgen);
}

static Chan*
archopen(Chan* c, int omode)
{
	return devopen(c, omode, archdir, narchdir, devgen);
}

static void
archclose(Chan*)
{
}

enum
{
	Linelen= 31,
};

static long
archread(Chan *c, void *a, long n, vlong offset)
{
	Rdwrfn *fn;

	switch((ulong)c->qid.path){

	case Qdir:
		return devdirread(c, a, n, archdir, narchdir, devgen);
	default:
		if(c->qid.path < narchdir && (fn = readfn[c->qid.path]))
			return fn(c, a, n, offset);
		error(Eperm);
		notreached();
	}
}

static long
archwrite(Chan *c, void *a, long n, vlong offset)
{
	Rdwrfn *fn;

	switch((ulong)c->qid.path){
	default:
		if(c->qid.path < narchdir && (fn = writefn[c->qid.path]))
			return fn(c, a, n, offset);
		error(Eperm);
		notreached();
	}
}

Dev archdevtab = {
	'P',
	"arch",

	devreset,
	devinit,
	devshutdown,
	archattach,
	archwalk,
	archstat,
	archopen,
	devcreate,
	archclose,
	archread,
	devbread,
	archwrite,
	devbwrite,
	devremove,
	devwstat,
};

vlong
vlabs(vlong vl)				/* unused */
{
	return vl >= 0? vl: -vl;
}

int (*archclz)(Clzuint);

static long
cputyperead(Chan*, void *a, long n, vlong off)
{
	char str[100];

	snprint(str, sizeof str, "%s %ud\next %s\n"
		"idle %s %ssending IPIs over %ld ns (%lld clints)\n",
		cputype, m->cpumhz, (archclz == clzzbb? "clz": ""), "wfi",
		soc.idlewakens? "": "not ", soc.idlewakens, sys->clthresh);
	return readstr(off, a, n, str);
}

static ulong exts[] = {
	0, 1, 2, 3, 4, 5, 6, 7, 8, 0x10,
	HSM,
	's'<<16|'P'<<8|'I',		/* sPI */
	'R'<<24|'F'<<16|'N'<<8|'C',	/* RFNC */
	SRST,
};

static void
sbiext(ulong ext)
{
	char c;

	if (sbiprobeext(ext) == 0)
		return;
	if (ext < 256)
		print(" %#lux", ext);
	else {
		print(" ");
		for (; ext > 0; ext <<= 8) {
			c = ext >> 24;
			if (c && isprint(c))
				print("%c", c);
		}
	}
}

static void
sbiinit(void)
{
	int i;

	if (!bootmachmode && !nosbi) {
		soc.havesbihsm  = sbiprobeext(HSM) != 0;
		soc.havesbisrst = sbiprobeext(SRST) != 0;
		if (!soc.newmach)
			return;
		print("sbi extensions present:");
		for (i = 0; i < nelem(exts); i++)
			sbiext(exts[i]);
		print("\n");
	}
}

void
archinit(void)
{
	addarchfile("cputype", 0444, cputyperead, nil);
	sbiinit();
}

/*
 * attempt to reset the whole system.
 * failing that, just hang.
 */
void
archreset(void)
{
	iprint("archreset...");
	cacheflush();
	spllo();
	delay(20);
	if (m->machno == 0 && prstackmax)
		prstackmax();
	delay(20);

	if (rvreset)
		rvreset();
	if (!nosbi && m->machno == 0) {
		if (soc.havesbisrst) {
			iprint("sbi cold reboot...");
			delay(20);
			sbireset(SRSTCOLD, 0);
			/* shouldn't get here */
		}
		iprint("trying sbi shutdown.\n");
		delay(20);
		sbishutdown();			/* shuts down all cpus */
	}

	iprint("failed to reset; going into wfi as a last resort.\n");
	delay(20);
	for (;;)
		halt();
}

/* we've had a nested panic or the like; we must give up and reboot */
void
emergereset(void)
{
	splhi();
	active.exiting = 1;
	coherence();
	delay(1000);	/* hope that active.exiting shuts down other cpus */

	/* we hope that we can now use the uniprocessor reset */
	archreset();
	notreached();
}

static void
haltsys(void)
{
	int i;

	iprint("mpshutdown: cpu%d: %d active cpus\n", m->machno, sys->nonline);
	delay(5);
	devtabshutdown();
	splhi();

	/* paranoia: wait for other cpus */
	for (i = 100; i > 0 && sys->nonline > 1; i--) {
		iprint(" %d", sys->nonline);
		delay(100);
	}

	/* we can now use the uniprocessor reset */
	archreset();
	notreached();
}

/*
 * secondary cpus should all idle (here or in shutdown, called from reboot).
 * for a true shutdown, reset and boot, cpu 0 should then reset itself or the
 * system as a whole.  if plan 9 is rebooting (loading a new kernel and
 * starting it), cpu 0 needs to keep running to do that work, so we return
 * in that case only.
 *
 * we assume shutdown has previously been called on this cpu.
 */
void
mpshutdown(void)
{
	void (*tramp)(Reboot *);

	if(m->machno == 0) {
		static QLock mpshutdownlock;

		qlock(&mpshutdownlock);
		/* we are the first proc on cpu0 to begin shutdown */
		if(!active.rebooting) {
			haltsys();
			notreached();
		}
	} else {
		/*
		 * we're secondary, we should go into sys->reboottramp to enter
		 * wfi.  if idling, sys->Reboot won't be set and that's okay.
		 */
		cacheflush();
		mmulowidmap();			/* disables user mapping too */
		usephysdevaddrs();

		/* await populated sys->Reboot */
		/* secstall is cleared by schedcpus, settrampargs from reboot */
		while (sys->secstall == RBFLAGSET)
			coherence();
		tramp = (void (*)(Reboot *))PADDR(sys->reboottramp);
		(*tramp)(&sys->Reboot);
		notreached();
	}
}

/*
 *  return value and frequency of timer (via hz)
 *
 * there are two main timers: the system-wide clint clock (mtime or rdtime)
 * and the per-core cpu clock (rdtsc).  the clint clock is typically
 * something like 1 or 10 MHz and the cpu clock 600 - 1800 MHz.
 * we use the clint clock as our source of fastticks.
 */
uvlong
fastticks(uvlong* hz)
{
	if(hz != nil)
		*hz = timebase;
	coherence();
	return rdcltime() - sys->epoch;	/* clticks since boot, for uptime */
}

ulong
µs(void)
{
	return fastticks2us(fastticks(nil));
}
