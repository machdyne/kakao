#include	"u.h"
#include	"../port/lib.h"
#include	"mem.h"
#include	"dat.h"
#include	"fns.h"
#include	"../port/error.h"

#include	<authsrv.h>
#include	<ctype.h>

#define CTRL(let)	(int)((let) & MASK(5))

enum
{
	Canqiwrite	= 0,		/* flag: use qiwrite in iprint? */

	Nconsdevs	= 64,		/* max number of consoles */

	/* consdev indices */
	Conskmesg	= 0,
	Conskprint,
	Consserial,
	NConsinit,

	/* Consdev flags */
	Ciprint		= 2,		/* call this fn from iprint */
	Cntorn		= 4,		/* change \n to \r\n */
};

typedef struct Consdev Consdev;

struct Consdev
{
	Chan*	c;			/* external file */
	Queue*	q;			/* i/o queue, if any */
	void	(*fn)(char*, int);	/* i/o function when no queue */
	int	flags;
};

int	bootkernel;			/* from config file */
int	printmmuput;
void	(*prstackmax)(void);

void	(*consdebug)(void) = nil;
void	(*consputs)(char*, int) = nil;

static void kmesgputs(char *, int);
static void kprintputs(char*, int);

static	Lock	consdevslock;
static	int	nconsdevs = NConsinit;
/*
 * keep this order of the first 3; it's known in delconsdevs and uses of
 * addconsdevs in devuart at least.
 */
static	Consdev	consdevs[Nconsdevs] =
{
	{nil, nil,	kmesgputs,	Ciprint},		/* kmesg */
	{nil, nil,	kprintputs,	Ciprint},		/* kprint */
	{nil, nil,	uartputs,	Ciprint|Cntorn},	/* serial */
};

static	int	nkbdqs;
static	int	nkbdprocs;
static	Queue*	kbdqs[Nconsdevs];
static	int	kbdprocs[Nconsdevs];
static	Queue*	kbdq;		/* unprocessed console input */
static	Queue*	lineq;		/* processed console input */
static	Queue*	serialoq;	/* serial console output */
static	Queue*	kprintoq;	/* console output, for /dev/kprint */
static	int	kprintinuse;	/* test and set whether /dev/kprint is open */

int	panicking;

static struct
{
	QLock;

	int	raw;		/* true if we shouldn't process input */
	Ref	ctl;		/* number of opens to the control file */
	int	x;		/* index into line */
	char	line[1024];	/* current input line */

	int	count;
	int	ctlpoff;

	/*
	 * A place to save up characters at interrupt time
	 * before dumping them in the queue
	 */
	Lock	lockputc;
	char	istage[1024];
	char	*iw;
	char	*ir;
	char	*ie;
} kbd = {
	.iw	= kbd.istage,
	.ir	= kbd.istage,
	.ie	= kbd.istage + sizeof(kbd.istage),
};

char	*sysname;
vlong	fasthz;

Dev consdevtab;

static void	seedrand(void);
static int	readtime(ulong, char*, int);
static int	readbintime(char*, int);
static int	writetime(char*, int);
static int	writebintime(char*, int);

enum
{
	CMhalt,
	CMreboot,
	CMpanic,
};

Cmdtab rebootmsg[] =
{
	CMhalt,		"halt",		1,
	CMreboot,	"reboot",	0,
	CMpanic,	"panic",	0,
};

/* To keep the rest of the kernel unware of new consdevs for now */
static void
kprintputs(char *s, int n)
{
	if(consputs != nil)
		consputs(s, n);
}

int
addconsdev(Queue *q, void (*fn)(char*,int), int i, int flags)
{
	Consdev *c;

	ilock(&consdevslock);
	if(i < 0)
		i = nconsdevs;
	else
		flags |= consdevs[i].flags;
	if(nconsdevs == Nconsdevs)
		panic("Nconsdevs too small");
	c = &consdevs[i];
	c->flags = flags;
	c->q = q;
	c->fn = fn;
	if(i == nconsdevs)
		nconsdevs++;
	iunlock(&consdevslock);
	return i;
}

void
delconsdevs(void)
{
	nconsdevs = Consserial;	/* throw away serial consoles & kprint */
	consdevs[Conskprint].q = nil;
}

static void
conskbdqproc(void *a)
{
	char buf[64];
	Queue *q;
	int nr;

	q = a;
	while((nr = qread(q, buf, sizeof(buf))) > 0)
		qwrite(kbdq, buf, nr);
	pexit("hangup", 1);
}

static void
kickkbdq(void)
{
	int i;

	if(up != nil && nkbdqs > 1 && nkbdprocs != nkbdqs){
		lock(&consdevslock);
		if(nkbdprocs == nkbdqs){
			unlock(&consdevslock);
			return;
		}
		for(i = 0; i < nkbdqs; i++)
			if(kbdprocs[i] == 0){
				kbdprocs[i] = 1;
				kproc("conskbdq", conskbdqproc, kbdqs[i]);
			}
		unlock(&consdevslock);
	}
}

int
addkbdq(Queue *q, int i)
{
	int n;

	ilock(&consdevslock);
	if(i < 0)
		i = nkbdqs++;
	if(nkbdqs == Nconsdevs)
		panic("Nconsdevs too small");
	kbdqs[i] = q;
	n = nkbdqs;
	iunlock(&consdevslock);
	switch(n){
	case 1:
		/* if there's just one, pull directly from it. */
		kbdq = q;
		break;
	case 2:
		/* later we'll merge bytes from all kbdqs into a single kbdq */
		kbdq = qopen(4*1024, 0, 0, 0);
		if(kbdq == nil)
			panic("no kbdq");
		/* fall */
	default:
		kickkbdq();
	}
	return i;
}

void
printinit(void)
{
	lineq = qopen(2*1024, 0, nil, nil);
	if(lineq == nil)
		panic("printinit");
	qnoblock(lineq, 1);
}

int
consactive(void)
{
	int i;
	Queue *q;

	for(i = 0; i < nconsdevs; i++)
		if((q = consdevs[i].q) != nil && qlen(q) > 0)
			return 1;
	return 0;
}

void
prflush(void)
{
	ulong now;

	if (!islo()) {
		delay(1000);
		return;
	}
	for (now = sys->ticks; consactive() && sys->ticks - now < 10*HZ; )
		pause();
}

/*
 * Log console output so it can be retrieved via /dev/kmesg.
 * This is good for catching boot-time messages after the fact.
 * We have moved it to the top of available memory in the hope
 * that it may persist across at least some reboots.
 */

enum { Kmesgmagic = 0xf001dea1, };

#define kmesg sys->kmsg

void
kmesginit(void)
{
	ulong omag;

	/* has this buffer persisted across a reboot? */
	omag = kmesg.magic;
	if (omag != Kmesgmagic) {
		/* no, so reset it */
		kmesg.size = sizeof kmesg.buf;
		kmesg.n = 0;
	}
	if (kmesg.n >= kmesg.size)		/* outside old buffer size? */
		kmesg.n = 0;
	kmesg.size = sizeof kmesg.buf;		/* in case size changed */
	if (kmesg.n >= kmesg.size)		/* outside new buffer size? */
		kmesg.n = 0;
	if (omag != Kmesgmagic)
		kmesg.magic = Kmesgmagic;	/* enable writing new kmesg */
	/* else resuming previous kmesg buffer */
}

static void
kmesgputs(char *str, int n)
{
	uint nn, d;

	if (n <= 0 || kmesg.magic != Kmesgmagic)
		return;

	ilock(&sys->kmsglock);
	/* take the tail of huge writes */
	if(n > sizeof kmesg.buf){
		d = n - sizeof kmesg.buf;
		str += d;
		n -= d;
	}

	/* slide the buffer down to make room */
	nn = kmesg.n;
	if(nn + n >= sizeof kmesg.buf){
		d = nn + n - sizeof kmesg.buf;
		if(d)
			memmove(kmesg.buf, kmesg.buf+d, sizeof kmesg.buf-d);
		nn -= d;
	}

	/* copy the data in */
	memmove(kmesg.buf+nn, str, n);
	nn += n;
	kmesg.n = nn;
	iunlock(&sys->kmsglock);
}

static void
consdevputs(Consdev *c, char *s, int n, int usewrite)
{
	Chan *cc;
	Queue *q;

	assert(c);
	if (n <= 0)
		return;
	if((cc = c->c) != nil && usewrite)
		CHANDEV(cc)->write(cc, s, n, 0);
	else if((q = c->q) != nil && !qisclosed(q))
		if(usewrite)
			qwrite(q, s, n);
		else
			qiwrite(q, s, n);
	else if(c->fn != nil)
		c->fn(s, n);
}

/*
 *   Print a string on the console.  Convert \n to \r\n for serial
 *   line consoles.  Locking of the queues is left up to the screen
 *   or uart code.  Multi-line messages to serial consoles may get
 *   interspersed with other messages.
 */
void
putstrn0(char *str, int n, int usewrite)
{
	Consdev *c;
	char *s, *t;
	int i, len, lens;

	if(!islo())
		usewrite = 0;

	for(i = 0; i < nconsdevs; i++){
		c = &consdevs[i];
		len = n;
		s = str;
		while(len > 0){
			t = nil;
			if((c->flags&Cntorn) && !kbd.raw)
				t = memchr(s, '\n', len);
			if(t != nil && !kbd.raw){
				lens = t-s;
				if (lens > 0)
					consdevputs(c, s, lens, usewrite);
				if (lens <= 0 || t[-1] != '\r')
					consdevputs(c, "\r", 1, usewrite);
				consdevputs(c, "\n", 1, usewrite);
				len -= lens+1;
				s = t+1;
			}else{
				consdevputs(c, s, len, usewrite);
				break;
			}
		}
	}
}

void
putstrn(char *str, int n)
{
	putstrn0(str, n, 0);
}

/* being able to print at any time is very helpful. */
int
print(char *fmt, ...)
{
	int n;
	va_list arg;
	char buf[PRINTSIZE];

	va_start(arg, fmt);
	if (m == nil || !m->printok) { /* don't call vseprint from low memory */
		n = vprf(fmt, arg);
		va_end(arg);
		return n;
	}
	n = vseprint(buf, buf+sizeof(buf), fmt, arg) - buf;
	va_end(arg);
	if (!mallocok && polledprint)
		prn(buf, n);
	else if(panicking <= 0 || up == nil || up->pid == panicking)
		putstrn(buf, n);
	delay(prmsdelay);		/* mainly beagle debugging */
	return n;
}

/*
 * Want to interlock iprints to avoid interlaced output on
 * multiprocessor, but don't want to deadlock if one processor
 * dies during print and another has something important to say.
 * Make a good faith effort.
 */
static Lock iprintlock;

static int
iprintcanlock(Lock *l)
{
	int i;

	for(i=0; i<1000; i++){
		if(canlock(l))
			return 1;
		if(l->m == m)
			return 0;
		microdelay(100);
	}
	return 0;
}

/*
 * print that can be used in interrupt service routines
 * or just at high PL.
 */
int
iprint(char *fmt, ...)
{
	Mreg s;
	int i, n, locked, trips;
	va_list arg;
	char buf[PRINTSIZE];
	Consdev *cons;

	s = splhi();
	va_start(arg, fmt);
	if (m == nil || !m->printok) { /* don't call vseprint from low memory */
		n = vprf(fmt, arg);
		va_end(arg);
		splx(s);
		return n;
	}
	n = vseprint(buf, buf+sizeof(buf), fmt, arg) - buf;
	va_end(arg);
	if(panicking > 0 && up != nil && up->pid != panicking) {
		splx(s);
		return n;
	}

	/* being able to print at any time is very helpful. */
	if (!mallocok && polledprint) {
		prn(buf, n);
		splx(s);
		return n;
	}

	/*
	 * don't stall forever, but try to not intermingle output 
	 * with other cpus'.
	 */
	locked = iprintcanlock(&iprintlock);
	trips = 0;
	while (trips++ < 1000 && !locked) {
		delay(1);
		locked = iprintcanlock(&iprintlock);
	}

	/* does not insert \r before \n */
	for(i = 0; i < nconsdevs; i++) {
		cons = &consdevs[i];
		if((cons->flags&Ciprint) != 0)
			if(Canqiwrite && cons->q != nil)
				/* allocates memory */
				qiwrite(cons->q, buf, n);
			else
				cons->fn(buf, n);
	}
	if(locked)
		unlock(&iprintlock);
	splx(s);
	delay(prmsdelay);		/* mainly risc-v debugging */
	return n;
}

void
watchdogoff(void)
{
	if (watchdogon && watchdog) {
		watchdog->disable();
		watchdogon = 0;
	}
}

void
chknested(void)
{
	if(panicking) {
		if (up && panicking == up->pid)
			iprint("nested or recursive panic\n");
		delay(10000);
		emergereset();
		notreached();
	}

	panicking = -1;
	if(up)
		panicking = up->pid;
}

#pragma profile 0
void
_panic(char *fmt, ...)
{
	int n;
	uintptr pc;
	Mreg s;
	va_list arg;
	char buf[PRINTSIZE];

	pc = getcallerpc(&fmt);
	consdevs[Conskprint].q = nil;	/* don't try to write to /dev/kprint */
	watchdogoff();		/* simplify life by shutting off any watchdog */

	s = splhi();
	strcpy(buf, "panic: ");
	va_start(arg, fmt);
	n = vseprint(buf+strlen(buf), buf+sizeof(buf)-2, fmt, arg) - buf;
	va_end(arg);
	/* fmt might already have trailing newline, but it shouldn't. */
	if (strchr(buf, '\n') == nil)
		strcat(buf, "\n");

	iprint("%s at %#p\n", buf, pc);		/* force panic msg out */
	delay(100);
	chknested();
	if(consdebug)
		(*consdebug)();
	if (prstackmax)
		prstackmax();

	dumpstack();
	putstrn(buf, n+1);	/* print msg again; may have scrolled off */
	splx(s);
	prflush();

	delay(10);
	exit(1);
}

#pragma profile 1
/* libmp at least contains a few calls to sysfatal; simulate with panic */
void
sysfatal(char *fmt, ...)
{
	char err[PRINTSIZE];
	va_list arg;

	va_start(arg, fmt);
	vseprint(err, err + sizeof err, fmt, arg);
	va_end(arg);
	panic("sysfatal: %s", err);
}

void
abort(void)
{
	panic("abort");
}

void
exits(char *sts)
{
	panic("exits called: %s", sts);
}

void
_assert(char *fmt)
{
	panic("assert failed at %#p: %s", getcallerpc(&fmt), fmt);
}

int
pprint(char *fmt, ...)
{
	int n;
	Chan *c;
	va_list arg;
	char buf[2*PRINTSIZE];

	if(up == nil || up->fgrp == nil)
		return 0;

	c = up->fgrp->fd[2];
	if(c==0 || (c->mode!=OWRITE && c->mode!=ORDWR))
		return 0;
	n = snprint(buf, sizeof buf, "%s %d: ", up->text, up->pid);
	va_start(arg, fmt);
	n = vseprint(buf+n, buf+sizeof(buf), fmt, arg) - buf;
	va_end(arg);

	if(waserror())
		return 0;
	CHANDEV(c)->write(c, buf, n, c->offset);
	poperror();

	lock(c);
	c->offset += n;
	unlock(c);

	return n;
}

static void
echo(char *buf, int n)
{
	Mreg s;
	static int ctrlt, pid;
	char *e, *p;

	if(n == 0)
		return;

	e = buf+n;
	for(p = buf; p < e; p++){
		switch(*p){
		case CTRL('p'):
			if(cpuserver && !kbd.ctlpoff){
				/* simplify life by shutting off any watchdog */
				watchdogoff();
				active.exiting = 1;
				return;
			}
			break;
		case CTRL('t'):
			ctrlt++;
			if(ctrlt > 2)
				ctrlt = 2;
			continue;
		case CTRL('u'):
			print("^u\r\n");
			break;
		}
		if(ctrlt != 2)
			continue;

		/* ^T escapes */
		ctrlt = 0;
		switch(*p){
		case 'S':
			s = splhi();
			dumpstack();
			procdump();
			splx(s);
			return;
		case 's':
			dumpstack();
			return;
		case 'x':
			ixsummary();
			mallocsummary();
//			memorysummary();
			return;
		case 'd':
			if(consdebug == nil)
				consdebug = rdb;
			else
				consdebug = nil;
			print("consdebug now %#p\n", consdebug);
			return;
		case 'D':
			if(consdebug == nil)
				consdebug = rdb;
			consdebug();
			return;
		case 'P':
			printmmuput ^= 1;
			return;
		case 'p':
			s = spllo();
			procdump();
			splx(s);
			return;
		case 'q':
			scheddump();
			return;
		case 'k':
			killbig("^t ^t k");
			return;
		case 'r':
			exit(0);
			return;
		case 'u':
			if (prfaults)
				prfaults();
			if (prstackmax)
				prstackmax();
			return;
		}
	}

	if(kbdq != nil)
		qproduce(kbdq, buf, n);
	if(kbd.raw == 0)
		putstrn(buf, n);
}

/*
 *  Called by a uart interrupt for console input.
 *
 *  turn '\r' into '\n' before putting it into the queue.
 */
int
kbdcr2nl(Queue*, int ch)
{
	char *next;

	ilock(&kbd.lockputc);		/* just a mutex */
	if(ch == '\r' && !kbd.raw)
		ch = '\n';
	next = kbd.iw+1;
	if(next >= kbd.ie)
		next = kbd.istage;
	if(next != kbd.ir){
		*kbd.iw = ch;
		kbd.iw = next;
	}
	iunlock(&kbd.lockputc);
	return 0;
}

/*
 *  Put character, possibly a rune, into kbd read queue at interrupt time.
 *  Called at interrupt time to process a character.
 */
int
kbdputc(Queue*, int ch)
{
	int i, n;
	char buf[UTFmax];
	Rune r;
	char *next;

	if(kbd.ir == nil)
		return 0;		/* in case we're not inited yet */

	ilock(&kbd.lockputc);		/* just a mutex */
	r = ch;
	n = runetochar(buf, &r);
	for(i = 0; i < n; i++){
		next = kbd.iw+1;
		if(next >= kbd.ie)
			next = kbd.istage;
		if(next == kbd.ir)
			break;
		*kbd.iw = buf[i];
		kbd.iw = next;
	}
	iunlock(&kbd.lockputc);
	return 0;
}

/*
 *  we save up input characters till clock time to reduce
 *  per character interrupt overhead.
 */
static void
kbdputcclock(void)
{
	char *iw;

	/* this amortizes cost of qproduce */
	if(kbd.iw != kbd.ir){
		iw = kbd.iw;
		if(iw < kbd.ir){
			echo(kbd.ir, kbd.ie-kbd.ir);
			kbd.ir = kbd.istage;
		}
		if(kbd.ir != iw){
			echo(kbd.ir, iw-kbd.ir);
			kbd.ir = iw;
		}
	}
}

enum{
	Qdir,
	Qbintime,
	Qcons,
	Qconsctl,
	Qcputime,
	Qdrivers,
	Qkmesg,
	Qkprint,
	Qhostdomain,			/* unused since 9P2000 */
	Qhostowner,
	Qnull,
	Qosversion,
	Qpgrpid,
	Qpid,
	Qppid,
	Qrandom,
	Qreboot,
	Qswap,
	Qsysname,
	Qsysstat,
	Qtime,
	Quser,
	Qzero,
	Qconfig,
};

enum
{
	VLNUMSIZE=	22,
};

static Dirtab consdir[]={
	".",	{Qdir, 0, QTDIR},	0,		DMDIR|0555,
	"bintime",	{Qbintime},	24,		0664,
	"cons",		{Qcons},	0,		0660,
	"consctl",	{Qconsctl},	0,		0220,
	"cputime",	{Qcputime},	6*NUMSIZE,	0444,
	"drivers",	{Qdrivers},	0,		0444,
	"hostdomain",	{Qhostdomain},	DOMLEN,		0664,
	"hostowner",	{Qhostowner},	0,		0664,
	"kmesg",	{Qkmesg},	0,		0440,
	"kprint",	{Qkprint, 0, QTEXCL},	0,	DMEXCL|0440,
	"null",		{Qnull},	0,		0666,
	"osversion",	{Qosversion},	0,		0444,
	"pgrpid",	{Qpgrpid},	NUMSIZE,	0444,
	"pid",		{Qpid},		NUMSIZE,	0444,
	"ppid",		{Qppid},	NUMSIZE,	0444,
	"random",	{Qrandom},	0,		0444,
	/* writable by all for boot kernels */
	"reboot",	{Qreboot},	0,		0664,
	"swap",		{Qswap},	0,		0664,
	"sysname",	{Qsysname},	0,		0664,
	"sysstat",	{Qsysstat},	0,		0666,
	"time",		{Qtime},	NUMSIZE+3*VLNUMSIZE,	0664,
	"user",		{Quser},	0,		0666,
	"zero",		{Qzero},	0,		0444,
	"config",	{Qconfig},	0,		0444,
};

int
readnum(ulong off, char *buf, ulong n, ulong val, int size)
{
	char tmp[64];

	snprint(tmp, sizeof(tmp), "%*lud", size-1, val);
	tmp[size-1] = ' ';
	if(off >= size)
		return 0;
	if(off+n > size)
		n = size-off;
	memmove(buf, tmp+off, n);
	return n;
}

long
readstr(long offset, char *buf, long n, char *str)
{
	ulong size;

	size = strlen(str);
	if(offset >= size)
		return 0;
	if(offset+n > size)
		n = size-offset;
	memmove(buf, str+offset, n);
	return n;
}

static void
consinit(void)
{
	todinit();
	randominit();
	/*
	 * at 115200 baud, the 1024 char buffer takes 56 ms to process,
	 * processing it every 22 ms should be fine
	 */
	addclock0link(kbdputcclock, 22);
	kickkbdq();
	memset(&sys->kmsglock, 0, sizeof sys->kmsglock);
}

static Chan*
consattach(char *spec)
{
	return devattach(consdevtab.dc, spec);
}

static Walkqid*
conswalk(Chan *c, Chan *nc, char **name, int nname)
{
	return devwalk(c, nc, name,nname, consdir, nelem(consdir), devgen);
}

static Sysstatlen
consstat(Chan *c, uchar *dp, Sysstatlen n)
{
	return devstat(c, dp, n, consdir, nelem(consdir), devgen);
}

static Chan*
consopen(Chan *c, int omode)
{
	c->aux = nil;
	c = devopen(c, omode, consdir, nelem(consdir), devgen);
	switch((ulong)c->qid.path){
	case Qconsctl:
		incref(&kbd.ctl);
		break;

	case Qkprint:
		if(_tas(&kprintinuse) != 0){
			c->flag &= ~COPEN;
			error(Einuse);
		}
		if(kprintoq == nil){
			kprintoq = qopen(8*1024, Qcoalesce, 0, 0);
			if(kprintoq == nil){
				c->flag &= ~COPEN;
				error(Enomem);
			}
			qnoblock(kprintoq, 1);
			consdevs[Conskprint].q = kprintoq;
		}else
			qreopen(kprintoq);
		c->iounit = qiomaxatomic;
		break;
	}
	return c;
}

static void
consclose(Chan *c)
{
	switch((ulong)c->qid.path){
	/* last close of control file turns off raw */
	case Qconsctl:
		if(c->flag&COPEN){
			if(decref(&kbd.ctl) == 0)
				kbd.raw = 0;
		}
		break;

	/* close of kprint allows other opens */
	case Qkprint:
		if(c->flag & COPEN){
			kprintinuse = 0;
			qhangup(kprintoq, nil);
		}
		break;
	}
}

static int
percent(ulong a, ulong b)
{
	if (b == 0)
		b = 1;		/* don't divide by zero */
	if (a >= b)
		return 100;	/* cap at 100% */
	return (a * 100ull) / b;
}

static long
consread(Chan *c, void *buf, long n, vlong off)
{
	ulong l;
	Mach *mp;
	char *b, *bp, ch;
	char tmp[300]; /* must be big enough for Qswap, including malloc output */
	int i, k, id, send;
	long offset;

	if(n <= 0)
		return n;

	offset = off;
	switch((ulong)c->qid.path){
	case Qdir:
		return devdirread(c, buf, n, consdir, nelem(consdir), devgen);

	case Qcons:
		if (lineq == nil)
			error("/dev/cons: lineq is nil");
		if (kbdq == nil)
			error("/dev/cons: kbdq is nil");
		qlock(&kbd);
		if(waserror()) {
			qunlock(&kbd);
			nexterror();
		}
		while(!qcanread(lineq)){
			if(qread(kbdq, &ch, 1) == 0)
				continue;
			send = 0;
			if(ch == 0){
				/* flush output on rawoff -> rawon */
				if(kbd.x > 0)
					send = !qcanread(kbdq);
			}else if(kbd.raw){
				kbd.line[kbd.x++] = ch;
				send = !qcanread(kbdq);
			}else{
				switch(ch){
				case '\b':
					if(kbd.x > 0)
						kbd.x--;
					break;
				case CTRL('u'):
					kbd.x = 0;
					break;
				case '\n':
				case CTRL('d'):
					send = 1;
				default:
					if(ch != CTRL('d'))
						kbd.line[kbd.x++] = ch;
					break;
				}
			}
			if(send || kbd.x == sizeof kbd.line){
				qwrite(lineq, kbd.line, kbd.x);
				kbd.x = 0;
			}
		}
		n = qread(lineq, buf, n);
		qunlock(&kbd);
		poperror();
		return n;

	case Qcputime:
		k = offset;
		if(k >= 6*NUMSIZE)
			return 0;
		if(k+n > 6*NUMSIZE)
			n = 6*NUMSIZE - k;
		/* easiest to format in a separate buffer and copy out */
		for(i=0; i<6 && NUMSIZE*i<k+n; i++){
			l = up->time[i];
			if(i == TReal)
				l = sys->ticks - l;
			l = TK2MS(l);
			readnum(0, tmp+NUMSIZE*i, NUMSIZE, l, NUMSIZE);
		}
		memmove(buf, tmp+k, n);
		return n;

	case Qkmesg:
		/*
		 * This is unlocked to avoid tying up a process
		 * that's writing to the buffer.  kmesg.n never
		 * gets smaller, so worst case the reader will
		 * see a slurred buffer.
		 */
		if(off >= kmesg.n)
			n = 0;
		else{
			if(off+n > kmesg.n)
				n = kmesg.n - off;
			memmove(buf, kmesg.buf+off, n);
			/* replace NULs that sneak in */
			for (b = buf; b < (char *)buf + n; b++)
				if (*b == '\0')
					*b = ' ';
		}
		return n;

	case Qkprint:
		return qread(kprintoq, buf, n);

	case Qpgrpid:
		return readnum(offset, buf, n, up->pgrp->pgrpid, NUMSIZE);

	case Qpid:
		return readnum(offset, buf, n, up->pid, NUMSIZE);

	case Qppid:
		return readnum(offset, buf, n, up->parentpid, NUMSIZE);

	case Qtime:
		return readtime(offset, buf, n);

	case Qbintime:
		return readbintime(buf, n);

	case Qhostowner:
		return readstr(offset, buf, n, eve);

	case Qhostdomain:
		return readstr(offset, buf, n, hostdomain);

	case Quser:
		return readstr(offset, buf, n, up->user);

	case Qnull:
		return 0;

	case Qconfig:
		return readstr(offset, buf, n, configfile);

	case Qsysstat:
		b = smalloc(sys->nonline*(NUMSIZE*11+1) + 1);	/* +1 for NUL */
		bp = b;
		for(id = 0; id < MACHMAX; id++){
			if((mp = sys->machptr[id]) == nil || !mp->online)
				continue;
			readnum(0, bp, NUMSIZE, id, NUMSIZE);
			bp += NUMSIZE;
			readnum(0, bp, NUMSIZE, mp->cs, NUMSIZE);
			bp += NUMSIZE;
			readnum(0, bp, NUMSIZE, mp->intr, NUMSIZE);
			bp += NUMSIZE;
			readnum(0, bp, NUMSIZE, mp->syscall, NUMSIZE);
			bp += NUMSIZE;
			readnum(0, bp, NUMSIZE, mp->pfault, NUMSIZE);
			bp += NUMSIZE;
			readnum(0, bp, NUMSIZE, mp->tlbfault, NUMSIZE);
			bp += NUMSIZE;
			readnum(0, bp, NUMSIZE, mp->tlbpurge, NUMSIZE);
			bp += NUMSIZE;
			readnum(0, bp, NUMSIZE, mp->load, NUMSIZE);
			bp += NUMSIZE;
			readnum(0, bp, NUMSIZE, percent(mp->perf.avg_inidle,
				mp->perf.period), NUMSIZE);
			bp += NUMSIZE;
			readnum(0, bp, NUMSIZE, percent(mp->perf.avg_inintr,
				mp->perf.period), NUMSIZE);
			bp += NUMSIZE;
			*bp++ = '\n';
		}
		if(waserror()){
			free(b);
			nexterror();
		}
		n = readstr(offset, buf, n, b);
		free(b);
		poperror();
		return n;

	case Qswap:
		l = snprint(tmp, sizeof tmp,
			"%llud memory\n"
			"%d pagesize\n"
			"%llud kernel\n"
			"%lld/%llud user\n"
			"0/0 swap\n",		/* keep old 9 scripts happy */
			sys->pmoccupied,
			PGSZ,
			(vlong)PGROUND(sys->vmend - KTZERO)/PGSZ,
			(vlong)(palloc.user-palloc.freecount),
			(uvlong)palloc.user);
		b = buf;
		i = readstr(offset, b, MIN(l, n), tmp);
		b += i;
		n -= i;
		if(offset > l)
			offset -= l;
		else
			offset = 0;

		/* c not used */
		return i + mallocreadsummary(c, b, n, offset);

	case Qsysname:
		if(sysname == nil)
			return 0;
		return readstr(offset, buf, n, sysname);

	case Qrandom:
		return randomread(buf, n);

	case Qdrivers:
		return devtabread(c, buf, n, off);

	case Qzero:
		memset(buf, 0, n);
		return n;

	case Qosversion:
		snprint(tmp, sizeof tmp, "2000");
		n = readstr(offset, buf, n, tmp);
		return n;

	default:
		print("consread %#llux\n", c->qid.path);
		error("consread of unknown file");
		notreached();
	}
}

static long
conswrite(Chan *c, void *va, long n, vlong off)
{
	char buf[256], ch;
	long l, bp;
	char *a;
	Mach *mp;
	int i;
	ulong offset;
	Cmdbuf *cb;
	Cmdtab *ct;

	a = va;
	offset = off;

	switch((ulong)c->qid.path){
	case Qcons:
		/*
		 * Can't page fault in putstrn, so copy the data locally.
		 */
		for(l = n; l > 0; l -= bp){
			bp = MIN(l, sizeof buf);
			memmove(buf, a, bp);
			putstrn0(buf, bp, 1);
			a += bp;
		}
		break;

	case Qconsctl:
		if(n >= sizeof(buf))
			n = sizeof(buf)-1;
		strncpy(buf, a, n);
		buf[n] = 0;
		for(a = buf; a;){
			if(strncmp(a, "rawon", 5) == 0){
				kbd.raw = 1;
				/* clumsy hack - wake up reader */
				ch = 0;
				qwrite(kbdq, &ch, 1);
			}
			else if(strncmp(a, "rawoff", 6) == 0)
				kbd.raw = 0;
			else if(strncmp(a, "ctlpon", 6) == 0)
				kbd.ctlpoff = 0;
			else if(strncmp(a, "ctlpoff", 7) == 0)
				kbd.ctlpoff = 1;
			if(a = strchr(a, ' '))
				a++;
		}
		break;

	case Qtime:
		if(!iseve())
			error(Eperm);
		return writetime(a, n);

	case Qbintime:
		if(!iseve())
			error(Eperm);
		return writebintime(a, n);

	case Qhostowner:
		return hostownerwrite(a, n);

	case Qhostdomain:
		return hostdomainwrite(a, n);

	case Quser:
		return userwrite(a, n);

	case Qnull:
		break;

	case Qconfig:
		error(Eperm);
		break;

	case Qreboot:
		if(!bootkernel && !iseve())
			error(Eperm);
		cb = parsecmd(a, n);

		if(waserror()) {
			free(cb);
			nexterror();
		}
		ct = lookupcmd(cb, rebootmsg, nelem(rebootmsg));
		switch(ct->index) {
		case CMhalt:
			reboot(nil, 0, 0);
			break;
		case CMreboot:
			rebootcmd(cb->nf-1, cb->f+1);
			break;
		case CMpanic:
			*(ulong*)0=0;
			panic("/dev/reboot");
		}
		poperror();
		free(cb);
		break;

	case Qsysstat:
		for(i = 0; i < MACHMAX; i++)
			if((mp = sys->machptr[i]) != nil && mp->online)
				mp->cs = mp->intr = mp->syscall = mp->pfault =
					mp->tlbfault = mp->tlbpurge = 0;
		break;

	case Qswap:
		/* no more */
		break;

	case Qsysname:
		if(offset != 0 || n <= 0 || n >= sizeof buf)
			error(Ebadarg);
		strncpy(buf, a, n);
		buf[n] = 0;
		if(buf[n-1] == '\n')
			buf[n-1] = 0;
		kstrdup(&sysname, buf);
		break;

	default:
		print("conswrite: %#llux\n", c->qid.path);
		error("conswrite of unknown file");
	}
	return n;
}

Dev consdevtab = {
	'c',
	"cons",

	devreset,
	consinit,
	devshutdown,
	consattach,
	conswalk,
	consstat,
	consopen,
	devcreate,
	consclose,
	consread,
	devbread,
	conswrite,
	devbwrite,
	devremove,
	devwstat,
};

static	ulong	randn;

static void
seedrand(void)
{
	if(!waserror()){
		randomread((void*)&randn, sizeof(randn));
		poperror();
	}
}

int
nrand(int n)
{
	if(randn == 0)
		seedrand();
	randn = randn*1103515245 + 12345 + sys->ticks;
	return (randn>>16) % n;
}

int
rand(void)
{
	nrand(1);
	return randn;
}

static uvlong uvorder = 0x0001020304050607ULL;

static uchar*
be2vlong(vlong *to, uchar *f)
{
	uchar *t, *o;
	int i;

	t = (uchar*)to;
	o = (uchar*)&uvorder;
	for(i = 0; i < sizeof(vlong); i++)
		t[o[i]] = f[i];
	return f+sizeof(vlong);
}

static uchar*
vlong2be(uchar *t, vlong from)
{
	uchar *f, *o;
	int i;

	f = (uchar*)&from;
	o = (uchar*)&uvorder;
	for(i = 0; i < sizeof(vlong); i++)
		t[i] = f[o[i]];
	return t+sizeof(vlong);
}

static long order = 0x00010203;

static uchar*
be2long(long *to, uchar *f)
{
	uchar *t, *o;
	int i;

	t = (uchar*)to;
	o = (uchar*)&order;
	for(i = 0; i < sizeof(long); i++)
		t[o[i]] = f[i];
	return f+sizeof(long);
}

char *Ebadtimectl = "bad time control";

/*
 *  like the old #c/time but with added info.  Return
 *
 *	secs	nanosecs	fastticks	fasthz	mono
 */
static int
readtime(ulong off, char *buf, int n)
{
	vlong nsec, ticks, mono;
	long sec;
	char str[5*VLNUMSIZE];

	ticks = 0;
	nsec = todget(&ticks, &mono);
	if(fasthz == 0)
		fastticks((uvlong*)&fasthz);
	sec = nsec/1000000000ULL;
	snprint(str, sizeof(str), "%*lud %*llud %*llud %*llud %*llud ",
		NUMSIZE-1, sec,
		VLNUMSIZE-1, nsec,
		VLNUMSIZE-1, ticks,
		VLNUMSIZE-1, fasthz,
		VLNUMSIZE-1, mono);
	return readstr(off, buf, n, str);
}

/*
 *  set the time in seconds
 */
static int
writetime(char *buf, int n)
{
	char b[13];
	long i;

	if(n >= sizeof(b))
		error(Ebadtimectl);
	strncpy(b, buf, n);
	b[n] = 0;
	i = strtol(b, 0, 0);
	if(i <= 0)
		error(Ebadtimectl);
	todset(i*1000000000LL, 0, 0);
	return n;
}

/*
 *  read binary time info.  all numbers are little endian.
 *  ticks and nsec are syncronized.
 */
static int
readbintime(char *buf, int n)
{
	int i;
	vlong nsec, ticks, mono;
	uchar *b = (uchar*)buf;

	i = 0;
	if(fasthz == 0LL)
		fastticks((uvlong*)&fasthz);
	nsec = todget(&ticks, &mono);
	if(n >= 4*sizeof(uvlong)){
		vlong2be(b+3*sizeof(uvlong), mono);
		i += sizeof(uvlong);
	}
	if(n >= 3*sizeof(uvlong)){
		vlong2be(b+2*sizeof(uvlong), fasthz);
		i += sizeof(uvlong);
	}
	if(n >= 2*sizeof(uvlong)){
		vlong2be(b+sizeof(uvlong), ticks);
		i += sizeof(uvlong);
	}
	if(n >= 8){
		vlong2be(b, nsec);
		i += sizeof(vlong);
	}
	return i;
}

static vlong
vabs(vlong vl)
{
	return vl >= 0? vl: -vl;
}

static int
isclosefreq(vlong oldhz, vlong newhz)
{
	return vabs(newhz - oldhz) < oldhz/2;
}

/*
 *  set any of the following
 *	- time in nsec
 *	- nsec trim applied over some seconds
 *	- clock frequency
 */
static int
writebintime(char *buf, int n)
{
	uchar *p;
	vlong delta, nhz;
	long period;

	n--;
	p = (uchar*)buf + 1;
	switch(*buf){
	case 'n':
		if(n < sizeof(vlong))
			error(Ebadtimectl);
		be2vlong(&delta, p);
		todset(delta, 0, 0);
		break;
	case 'd':
		if(n < sizeof(vlong)+sizeof(long))
			error(Ebadtimectl);
		p = be2vlong(&delta, p);
		be2long(&period, p);
		todset(-1, delta, period);
		break;
	case 'f':
		if(n < sizeof(uvlong))
			error(Ebadtimectl);
		be2vlong(&nhz, p);
		if(nhz <= 0)
			error(Ebadtimectl);
		/* check new freq for plausibility; emulators can be off */
		if (fasthz == 0 || isclosefreq(fasthz, nhz)) {
			fasthz = nhz;
			todsetfreq(fasthz);
		} else {
			print("writebintime: old hz %,lld; rejected "
				"new hz %,lld\n", fasthz, nhz);
			error(Ebadtimectl);
		}
		break;
	}
	return n;
}
