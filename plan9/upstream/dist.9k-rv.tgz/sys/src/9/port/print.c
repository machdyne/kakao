/*
 * print - force use of kernel Locks, which differ from user Locks.
 *	also avoid loading FP conversions.
 */
#include "u.h"
#include "../port/lib.h"
#include "mem.h"
#include "dat.h"
#include "fns.h"

int _noprint;

static Lock fmtl;

void
_fmtlock(void)
{
	if (!noprint)
		ilock(&fmtl);
}

void
_fmtunlock(void)
{
	if (!noprint)
		iunlock(&fmtl);
}

int
_efgfmt(Fmt*)
{
	return -1;
}

int
mregfmt(Fmt* f)
{
	uintptr mreg;

	mreg = va_arg(f->args, uintptr);
	if(sizeof(mreg) == sizeof(uvlong))
		return fmtprint(f, "%#16.16p", (uintptr)mreg);
	return fmtprint(f, "%#8.8ux", (uint)mreg);
}

typedef struct Unit Unit;
struct Unit {
	uvlong	scale;
	char	sfx[2];
};

static Unit units[] = {
	EB, "E", PB, "P", TB, "T", GB, "G", MB, "M", KB, "K", 1, "",
};

static void
prsize(char *buf, int len, uvlong size)
{
	uvlong scale;
	Unit *unit;

	for (unit = units; unit < units + nelem(units) - 1; unit++)
		if (size == unit->scale || size >= 10*unit->scale)
			break;
	/* round scaled size */
	scale = unit->scale;
	snprint(buf, len, "%llud%s", (size + scale/2) / scale, unit->sfx);
}

int
unitsconv(Fmt *f)
{
	char buf[32];

	switch(f->r) {
	case 'N':
		prsize(buf, sizeof buf, va_arg(f->args, uvlong));
		return fmtstrcpy(f, buf);
	default:
		return fmtstrcpy(f, "(unitsconv)");
	}
}

void
fmtinit(void)
{
	quotefmtinstall();
	fmtinstall('N', unitsconv);
	archfmtinstall();
}
