/*
 * IMPORTANT!  DO NOT ADD LIBRARY CALLS TO THIS FILE.
 * The entire text image must fit on one page
 * (and there's no data segment, so any read/write data must be on the stack).
 */

#include <u.h>
#include <libc.h>

enum {
	Alignmagic = 0x12345678,
};

char cons[] = "#c/cons";
char boot[] = "/boot/boot";
char dev[] = "/dev";
char c[] = "#c";
char e[] = "#e";
char ec[] = "#ec";
char s[] = "#s";
char srv[] = "/srv";
char env[] = "/env";

static int alignmagic = Alignmagic;
static char unaligned[] = "initcode data seg unaligned!\n";

void
startboot(char *argv0, char **argv)
{
	char *p;
	char buf[ERRMAX];

	USED(argv0);
	/*
	 * if needed, open the console here so that /boot/boot,
	 * which could be a shell script, can inherit the open fds.
	 */
	if (dup(0, 10) >= 0)		/* standard fds open? */
		close(10);
	else {
		/* standard fds are closed */
		open(cons, OREAD);
		open(cons, OWRITE);
		open(cons, OWRITE);
	}
//	write(2, "initcode...", 11);

	if (alignmagic != Alignmagic)
		write(2, unaligned, sizeof unaligned - 1);
	bind(c, dev, MAFTER);
	bind(ec, env, MAFTER);
	bind(e, env, MCREATE|MAFTER);
	bind(s, srv, MREPL|MCREATE);
//	write(2, "exec boot...", 12);
	exec(boot, argv);

	/* explain failure to exec boot */
	errstr(buf, sizeof buf);
	for (p = buf; *p != '\0'; p++)
		;
	*p = '\n';
	write(2, buf, p + 1 - buf);
	*p = '\0';
	_exits(buf);
}
