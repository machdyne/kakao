/*
 * device table operations: traversals and shutdowns.
 */
#include "u.h"
#include "../port/lib.h"
#include "mem.h"
#include "dat.h"
#include "fns.h"
#include "../port/error.h"

#define STDBG(...)	if (debugstart) iprint(__VA_ARGS__); else {}

int debugstart;			/* may be toggled in sysr1 */

extern Dev* devtab[];

void
devtabreset(void)		/* discover devices in 9k */
{
	int i;

	todinit();	/* avoid later reentry causing infinite recursion */
	debugstart = getconf("*debugstart") != nil;
	STDBG("reset:");
	for(i=0; devtab[i] != nil; i++) {
		STDBG("[%s]", devtab[i]->name);
		devtab[i]->reset();
		splhi();		/* paranoia */
	}
	STDBG("\n");
}

void
devtabinit(void)
{
	int i;

	STDBG("init:");
	for(i=0; devtab[i] != nil; i++) {
		STDBG("(%s)", devtab[i]->name);
		devtab[i]->init();
	}
	STDBG("\n");
}

void
devtabshutdown(void)
{
	int i;

	/* shutdown in reverse order */
	for(i=0; devtab[i] != nil; i++)
		;
	for(i--; i >= 0; i--)
		devtab[i]->shutdown();
}

Dev*
devtabget(Rune dc, int user)
{
	int i;

	for(i = 0; devtab[i] != nil; i++)
		if(devtab[i]->dc == dc)
			return devtab[i];
	if(user == 0)
		panic("devtabget %C", dc);
	return nil;
}

long
devtabread(Chan*, void* buf, long n, vlong off)
{
	int i;
	Dev *dev;
	char *alloc, *e, *p;

	alloc = malloc(READSTR);
	if(alloc == nil)
		error(Enomem);

	p = alloc;
	e = p + READSTR;
	for(i = 0; devtab[i] != nil; i++){
		dev = devtab[i];
		p = seprint(p, e, "#%C %s\n", dev->dc, dev->name);
	}

	if(waserror()){
		free(alloc);
		nexterror();
	}
	n = readstr(off, buf, n, alloc);
	free(alloc);
	poperror();

	return n;
}
