/*
 * mmc/sd/sdio host controller interface, plan 9 version for bcm port.
 * not `sd' as in `storage device' (devsd).
 */
struct SDio {
	char	*name;
	int	(*init)(void);
	void	(*enable)(void);
	int	(*inquiry)(char*, int);
	int	(*cmd)(ulong, ulong, ulong*);
	void	(*iosetup)(int, void*, int, int);
	void	(*io)(int, uchar*, int);
	void	(*disable)(void);		/* used by 9/port/sdmmc.c */
	int	(*cardintr)(int, int);		/* used by 9k/rv/sdpf.c */
};
