/*
 * driver for NVM Express 1.1 interface to PCI-Express solid state disk
 * (i.e., flash memory).
 *
 * currently the controller is in the drive, so there's no multiplexing
 * of drives through the controller.  multiple namespaces (actually number
 * spaces) are assumed to refer to different views of the same disk
 * (different block sizes).
 *
 * many features of NVME are ignored in the interest of simplicity and speed.
 * many of them are intended to jump on a bandwagon (e.g., VMs) or check a box.
 * using interrupts rather than polling costs us about 4% in large-block
 * dedicated sequential read performance.
 */
#include "u.h"
#include "../port/lib.h"
#include "mem.h"
#include "dat.h"
#include "fns.h"
#include "io.h"
#include "../port/error.h"
#include "../port/sd.h"
// #include "../port/dbgprint.h"

#define PAGEOF(ctlr, p) ((uintptr)(p) & ~((ctlr)->pgsz - 1ULL))

#define QFULL(qp)	((qp)->sidx.hd == sqidxinc((qp), (qp)->sidx.tl))
// #define QEMPTY(qp)	((qp)->sidx.hd == (qp)->sidx.tl)

#define admqp(ctlr)	(&(ctlr)->qpair[Qadmin])
#define ioqp(ctlr)	(&(ctlr)->qpair[Qio])

#define nvmeadmissue(ctlr, nvop, nsid, buf) \
	nvmeissue(ctlr, admqp(ctlr), nil, nvop, nsid, buf, 0, 1)

enum {
	/* fundamental constants */
	Qadmin,			/* queue-pair ordinals; Qadmin fixed at 0 */
	Qio,
	Nqueues,

	Vall = 1<<Qadmin | 1<<Qio,	/* all interesting vectors */

	Subq = 0,		/* queue-pair indices */
	Complq,
	Qtypes,

	Nsunused = 0,
	Nsall	= ~0ul,

	Idns	= 0,
	Idctlr,
	Idnsids,

	Minsect	= 512,
	Iodirs = Write+1+1,	/* read, write, rdwr */

	Reserved = (ushort)~0,		/* placeholder cmdid */
};
enum {
	/* tunable parameters */
	Intrdebug = 0,
	Debugns = 0,
	Measure	= 1,			/* flag: measure transfer times */

	/*
	 * the kernel may print with interrupts masked for some seconds, and a
	 * flurry of writes may make the controller or drive unresponsive at
	 * least for a while (e.g., for garbage collection), so allow for that.
	 */
	Timeout = 2*60*1000,	/* adjust to taste. started at 2000 ms. */
	/*
	 * limiting writes without a pause seems to avoid overheating
	 * and thus misbehaviour (read delivering garbage?).  this started
	 * relatively recently, so may be due to aging hardware.  0 is off.
	 */
	Writeheatbytes = 64*MB,

	/*
	 * NVME page size must be >= sector size.  anything over 8K only
	 * benefits bulk copies and benchmarks.
	 */
	Startpgsz = Sdalign,	/* on samsung sm951, 4k ≤ page_size ≤ 128MB */

	/*
	 * busy drive has operations timeout; trying to locate the fault.
	 * one entry in each queue is unused (head vs tail separation),
	 * so queue length of 1 wedges.  2 is fine.
	 */
	Sqlen	= 32,	/* maxima; queue lengths must be powers of 2 < 4K */
	Cqlen	= Sqlen,

	NCtlr	= 8,
	NCtlrdrv= 1,
	NDrive	= NCtlr * NCtlrdrv,
};

/* admin commands */
enum Adminops {
	Admmkiosq	= 1,	/* create i/o submission q */
	Admmkiocq	= 5,	/* create i/o completion q */
	Admid		= 6,	/* identify */
};

/* I/O commands */
enum Opcode {
	Cmdflush	= 0,
	Cmdwrite	= 1,
	Cmdread		= 2,
	Cmdwriteuncorr	= 4,
	Cmdcompare	= 5,
	Cmddsm		= 9,
};

typedef struct Cmd Cmd;
typedef struct Completion Completion;
typedef struct Ctlr Ctlr;
typedef struct Ctlrid Ctlrid;
typedef struct Doorbell Doorbell;
typedef struct Lbafmt Lbafmt;
typedef struct Nsid Nsid;
typedef struct Nvindx Nvindx;
typedef struct Qpair Qpair;
typedef struct Regs Regs;
typedef struct Transfer Transfer;

extern SDifc sdnvmeifc;

struct Nvindx {
	ushort	hd;		/* remove at this index */
	ushort	tl;		/* add at this index */
};

struct Qpair {
	Cmd	*q;		/* base of Cmd array */
	Nvindx	sidx;
	short	sqlen;

	Completion *cmpl;	/* base of Completion array */
	Nvindx	cidx;
	short	cqlen;
	uchar	phase;		/* initial phase bit setting in cmpl */
};

/* these are reused and never freed */
struct Transfer {
	Transfer *next;
	Rendez;
	uvlong	stcyc;		/* cycles at enqueue */
	int	status;		/* from completion */
	ulong	qtm;		/* time at enqueue */
	ushort	cmdid;		/* 0 means available */
	uchar	rdwr;
	ulong	done;		/* flag for rendezvous */
};

typedef struct Dirxfrs Dirxfrs;
struct Ctlr {
	Regs*	regs;		/* memory-mapped I/O registers */
	SDev*	sdev;
	Intrcommon;
	uintptr	port;		/* physical addr of I/O registers */

	int	pgsz;		/* size of an `nvme page' */
	int	minpgsz;
	int	mdts;		/* actual value, not log2; unit minpgsz */
	short	sqlen;		/* submission q length */
	short	cqlen;		/* completion q length */
	int	stride;	/* bytes from base of one doorbell reg. to the next */

	/* per controller */
	/* locks must be cached on risc-v */
	QLock;			/* serialise q notifications */
	Rendez;			/* q empty/full notifications */
	Lock	issuelock;	/* intr svc, regs, inflight & q heads & tail */
	Lock	xfrlock;
	Lock	shutlock;
	QLock	throtlck;	/* lock for write throttling */

	short	inflight;	/* count of xfrs in progress */
	int	intrsena;	/* interrupts we care about */
	Transfer *xfrs;		/* transfers in flight or done */

	/* q & cmpl queues need to be uncached */
	Qpair	qpair[Nqueues];	/* use a single admin queue pair */

	/* per-drive scalars, since there is only one drive */
	vlong	sectors;	/* total, copy to SDunits */
	int	secsize;	/* sector size, copy to SDunits */
	ushort	ns;		/* namespace index in Nsid->lbafmt */
	uvlong	written;	/* used to throttle writes */
	ulong	writetick;	/* last write tick */
	/* stats */
	ulong	throttles;	/* count of throttle events */
	ulong	timeouts;
	short	maxsqlen;	/* high water mark of sub queue: 3, so far */
	struct Dirxfrs {
		uvlong	count;
		uvlong	totns;
	} dirxfrs[Iodirs];	/* xfers: read, write, rdwr */

	/* per-drive bigger arrays */
	char	serial[20+1];
	char	model[40+1];
	char	fw[8+1];
};

struct Regs {			/* memory-mapped I/O registers; hw layout */
	uvlong	cap;		/* controller capabilities */
	ulong	vs;		/* version */
	/* intm* bits are actually vector number offsets */
	ulong	intmset;	/* intr mask set: bit # is i/o completion q # */
	ulong	intmclr;	/* intr mask clear: " */
	ulong	cc;		/* controller configuration */
	ulong	nssrc;		/* reset, iff cap.nssrs set */
	ulong	csts;		/* controller status */
	ulong	_rsvd2;		/* reserved */
	ulong	aqa;		/* admin queue attributes */
	uvlong	asq;		/* admin submit queue base address */
	uvlong	acq;		/* admin completion queue base address */
	uchar	_pad0[0x1000 - 0x38];
	/* this is the nominal doorbell layout, with stride of 4 */
	struct Doorbell {
		ulong	sqtl;	/* submission queue tail */
		ulong	cqhd;	/* completion queue head */
	} doorbell[Nqueues];
};

/*
 * making the doorbell stride variable at run time requires changing the
 * declaration and addressing of the Regs->doorbell array, making it clunkier.
 * supposedly non-zero strides are only desirable in VMs, for efficiency.
 */
/* clunky doorbell register addressing for any stride */
/* instead of &ctlr->regs->doorbell[qno].sqtl */
#define doorbellsqtl(ctlr, qp) (ulong *)\
	((char *)(ctlr)->regs->doorbell + (ctlr)->stride*(Qtypes*(qp) + Subq))
/* instead of &ctlr->regs->doorbell[qno].cqhd */
#define doorbellcqhd(ctlr, qp) (ulong *)\
	((char *)(ctlr)->regs->doorbell + (ctlr)->stride*(Qtypes*(qp) + Complq))

enum {
	/* cap */
	Nssrs		= 1ull << 36,

	/* cc */
	Enable		= 1 << 0,
	Cssnvm		= 0 << 4,	/* nvm command set */
	Cssmask		= 7 << 4,
	Shnnone		= 0 << 14,	/* shutdown style */
	Shnnormal	= 1 << 14,
	Shnabrupt	= 2 << 14,
	Shnmask		= 3 << 14,

	/* csts */
	Rdy		= 1 << 0,	/* okay to add to sub. q */
	Cfs		= 1 << 1,	/* controller fatal status */
	Shstnormal	= 0 << 2,	/* shutdown status */
	Shstoccur	= 1 << 2,
	Shstcmplt	= 2 << 2,
	Shstmask	= 3 << 2,
	Nssro		= 1 << 4,
};

struct Cmd {			/* submission queue entry (hw) */
	/* common 40-byte header */
	uchar	opcode;		/* command dword 0 */
	uchar	flags;
	ushort	cmdid;
	ulong	nsid;
	ulong	cdw2[2];	/* not used */
	uvlong	metadata;
	uvlong	prp1;		/* buffer memory address */
	uvlong	prp2;		/* zero, buffer addr, or prp list addr */

	union {
		ulong	cdw10[6]; /* admin: command dwords 10-15 */
		struct {	/* nvm i/o */
			uvlong	slba;
			ushort	length;
			ushort	control;
			ulong	dsmgmt;
			/* rest are for end-to-end protection only */
			ulong	reftag;
			ushort	apptag;
			ushort	appmask;
		};
	};
};

enum {
	/* cdw10[1] for Admmkiocq */
	Ien	= 1<<1,		/* intr enabled */
	Pc	= 1<<0,		/* physically contiguous */
};

struct Completion {		/* completion queue entry (hw) */
	ulong	specific;
	ulong	_pad;
	ushort	sqhd;		/* updated by hw, i hope */
	ushort	sqid;
	ushort	cmdid;
	ushort	stsphs;		/* status + 1 phase bit */
};

enum {
	Phase	= 1,		/* phase bit in stsphs */
};

struct Ctlrid {			/* identify cmd, cns=1 */
	ushort	pcivid;
	ushort	pcissvid;
	char	serial[20];	/* space-padded, unterminated strings */
	char	model[40];
	char	fw[8];
	char	_72_[77-72];
	uchar	mdts;		/* log2(max data xfr size), unit: min pg sz */
				/* 0 is unlimited */
	char	_78_[516-78];	/* ... lots of uninteresting stuff ... */
	ulong	nns;		/* number of namespaces present */

	char	_520_[526-520];	/* ... lots of uninteresting stuff ... */
	/* after 1.1 */
	ushort	awun;		/* atomic write unit */
	/* ... lots of uninteresting stuff through offset 4095 */
};

struct Nsid {			/* identify cmd, cns=0 */
	uvlong	size;		/* in logical blocks */
	uvlong	cap;
	uvlong	used;
	uchar	feat;		/* option feature bits */
	uchar	nlbafmts;	/* elements in lbafmt */
	uchar	fmtlbasz;	/* low 4 bits index lbafmt */
	uchar	mdcap;
	uchar	dpc;		/* end-to-end data protection stuff */
	uchar	dps;
	uchar	optnmic;
	uchar	optrescap;	/* reservation capabilities */

	/* after 1.1 */
	uchar	fpi;
	uchar	dlfeat;
	/* atomicity */
	ushort	nawun;		/* atomic write size; see awun */
	ushort	nawupf;		/* " under power failure */
	ushort	nacwu;		/* compare-&-swap size */
	ushort	nabsn;		/* boundary size */
	ushort	nabspf;		/* " under power failure */
	ushort	nabo;		/* boundary offset */
	/* end atomicity */
	ushort	noiob;		/* optimal i/o boundary */
	/* end after 1.1 */
	uchar	_pad0[128-48];	/* uninteresting stuff */

	struct Lbafmt {
		ushort	mdsize;
		uchar	lglbasize; /* log2(lba size) */
		uchar	relperf;
	} lbafmt[16];
	/* ... uninteresting stuff through offset 4095 */
};

CTASSERT(sizeof(Cmd) == 64, cmd_wrong_size);
CTASSERT(sizeof(Completion) == 16, compl_wrong_size);

static Lock clocklck;
static int clockrunning;

static int nctlrs;
static Ctlr *ctlrs[NCtlr];

static void
isfatal(Ctlr *ctlr, char *where)
{
	if (ctlr->regs->csts & Cfs)
		iprint("sd%C0: %s: fatal nvme controller error\n",
			ctlr->sdev->idno, where);
}

static Transfer *
findxfr(Ctlr *ctlr, int cmdid)
{
	Transfer *xfr;

	for (xfr = ctlr->xfrs; xfr; xfr = xfr->next)
		if (xfr->cmdid == cmdid)
			return xfr;
	return nil;
}

/*
 * on risc-v, use clint ticks (consistent across cores) instead of timestamp
 * cycles (only consistent across cores on x86).
 */
static void
measureupd(Ctlr *ctlr, Transfer *xfr)
{
	uint rdwr;
	uvlong cycs, ns;
	Dirxfrs *dx;

	rdwr = xfr->rdwr;
	if (rdwr >= Iodirs)
		return;
	cycs = meascycles() - xfr->stcyc;
	ns = (cycs * 1000) / measunits;
	if (ns < 100*1000) {
		dx = &ctlr->dirxfrs[rdwr];
		dx->totns += ns;
		dx->count++;
	}
}

/*
 * cqhd is head of the completion queue.
 * mark its transfer done, notify anybody waiting for it.
 */
static void
completexfr(Ctlr *ctlr, Completion *cqhd, int qno)
{
	Transfer *xfr;

	if (Intrdebug)
		iprint("intr q %d cmdid %d...", qno, cqhd->cmdid);
	xfr = findxfr(ctlr, cqhd->cmdid);
	if (xfr == nil)
		panic("sd%C0: nvmeinterrupt: unexpected completion cmd id %d",
			ctlr->sdev->idno, cqhd->cmdid);
	if (Measure && qno == Qio)
		measureupd(ctlr, xfr);	/* cycle-based measurements */
	xfr->status = cqhd->stsphs & ~Phase;
	xfr->done = 1;
	xfr->qtm = 0;
	coherence();
	wakeup(xfr);		/* notify of completion */
}

/* advance sub. q head to completion's, notify waiters */
static void
advancesqhd(Ctlr *ctlr, Qpair *qp, Completion *cqhd, int qno)
{
	if (Intrdebug)
		iprint("sub q %d sqhd set to %d...", qno, cqhd->sqhd);
	/* could zero slbas from qp->sidx.hd to before cqhd->sqhd */
	qp->sidx.hd = cqhd->sqhd;
	wakeup(ctlr);		/* notify of sqhd advance */
}

/*
 * advance compl. q head, notify ctlr., which will extinguish intr source
 * (by acknowledging this completion) and remove cqhd from the compl. q.
 */
static void
advancecqhd(Ctlr *ctlr, Qpair *qp, int qno)
{
	if (++qp->cidx.hd >= ctlr->cqlen) {
		qp->cidx.hd = 0;
		qp->phase ^= Phase;
	}
	if (Intrdebug)
		iprint("doorbell q %d cqhd set to %d\n", qno, qp->cidx.hd);
	*doorbellcqhd(ctlr, qno) = qp->cidx.hd;
	coherence();
}

static int
scancq(Ctlr *ctlr, int qno)
{
	int ndone;
	Completion *cqhd;
	Qpair *qp;

	ndone = 0;
	if (ctlr == nil)
		return 0;
	for (qp = &ctlr->qpair[qno]; ; ) {
		cqhd = &qp->cmpl[qp->cidx.hd];
		if ((cqhd->stsphs & Phase) == qp->phase)
			break;
		completexfr(ctlr, cqhd, qno);
		advancesqhd(ctlr, qp, cqhd, qno);
		/*
		 * toggles qp->phase if qp->cidx.hd wraps when incr'd.
		 */
		advancecqhd(ctlr, qp, qno);
		ndone++;
	}
	return ndone;
}

/*
 * Act on and clear the interrupt(s).
 * In order to share PCI IRQs, just ignore spurious interrupts.
 * Advances queue head indices past completed operations.
 */
static Intrsvcret
nvmeinterrupt(Ureg *, void* arg)
{
	int ndone, donepass;
	ulong causes;
	Ctlr *ctlr;
	Regs *regs;

	ctlr = arg;
	if (ctlr == nil)
		return Intrforme;
	regs = ctlr->regs;
	if (regs == nil)
		return Intrforme;
	ilock(&ctlr->issuelock); /* keep other cpus out of intr svc, indices */
	causes = regs->intmset; USED(causes);
	if (TODO && ctlr->inflight == 0) {  /* not expecting an interrupt? */
		/* probably lost a race with polling: nothing to do */
		iunlock(&ctlr->issuelock);
//		return Intrnotforme;	/* causes spurious intr complaints */
		return Intrforme;
	}

	ndone = 0;
	do {
		donepass  = scancq(ctlr, Qio);
		donepass += scancq(ctlr, Qadmin);
		ndone += donepass;
	} while (donepass > 0);

	ctlr->inflight -= ndone;
	if (ctlr->inflight < 0)
		iprint("nvmeinterrupt: inflight botch\n");
	/* unmask intr. sources of interest iff transfers are in flight */
	if (ctlr->inflight == 0)
		ctlr->intrsena = 0;
	else
		regs->intmclr = Vall;
	iunlock(&ctlr->issuelock);
	/* harmless, don't complain. maybe due to throttle */
	if (1 || ndone > 0)
		return Intrforme;
	else
		return Intrnotforme;
}

/* return cmd id other than zero and Reserved */
static int
cidalloc(void)
{
	int thisid;
	static int cid;
	static Lock cidlck;

	ilock(&cidlck);
	++cid;
	if ((ushort)cid == 0 || (ushort)cid == Reserved)
		cid = 1;
	thisid = cid;
	iunlock(&cidlck);
	return thisid;
}

static void
mkadmcmd(Ctlr *ctlr, Cmd *cmd, int op)
{
	/* we are using single-message msi, if any */
	cmd->slba = 0;
	switch (op) {
	case Admmkiosq:				/* create io submission q */
		cmd->cdw10[0] = (ctlr->sqlen - 1)<<16 | Qio;
		cmd->cdw10[1] = Qio<<16 | Pc;	/* io completion q id */
		break;
	case Admmkiocq:				/* create io completion q */
		cmd->cdw10[0] = (ctlr->cqlen - 1)<<16 | Qio;
		cmd->cdw10[1] = Ien | Pc;	/* vector 0 since no msi-x */
		break;
	case Admid:
		if (cmd->nsid == Nsall) {
			cmd->cdw10[0] = Idctlr;
			cmd->nsid = 0;
		} else
			cmd->cdw10[0] = Idns;
		break;
	}
}

/*
 * set PRP physical buffer address(es) in cmd
 */
static void
setcmdprpaddrs(Ctlr *ctlr, Cmd *cmd, SDreq *r, void *buf, ulong dlen)
{
	ulong pgsz;
	uintptr addr;

	addr = (uintptr)buf;			/* will be Sdalign-ed */
	if (addr != 0) {
		if (addr < KZERO)
			print("nvme mkcmd: %#p not kernel virtual address\n",
				addr);
		if (r && !r->write && dlen >= sizeof(uvlong))
			*(uvlong *)addr = 0;	/* read debugging */

		/* each prp entry points to at most an nvme page */
		cmd->prp1 = PCIWADDR((void *)addr);	/* must be Sdalign-ed */
		pgsz = ctlr->pgsz;
		if (r && dlen > pgsz && dlen <= 2*pgsz)
			cmd->prp2 = PAGEOF(ctlr, cmd->prp1) + pgsz;
		else
			cmd->prp2 = 0;
	}
}

/*
 * set transfer length in sectors in cmd
 */
static void
setcmdlen(Cmd *cmd, SDreq *r, ulong dlen)
{
	long count;
	SDunit *unit;

	count = 0;
	if (r) {
		unit = r->unit;
		if (unit) {
			count = dlen / unit->secsize;
			if (count <= 0) {
				print("nvmeissue: sector count %ld for i/o "
					"of length %ld\n", count, dlen);
				return;
			}
			assert(unit->secsize * count <= dlen);
		}
	}
	cmd->length = count - 1;	/* sectors */
}

/* fill in submission queue entry *cmd */
static void
mkcmd(Ctlr *ctlr, Cmd *cmd, SDreq *r, int op, ulong nsid, void *buf, int qno,
	vlong lba)
{
	ulong dlen;

	memset(cmd, 0, sizeof *cmd);
	cmd->opcode = op;
	cmd->cmdid = cidalloc();
	cmd->nsid = nsid;
	cmd->length = -1;		/* default, in sectors */

	dlen = (r? r->dlen: Minsect);
	setcmdprpaddrs(ctlr, cmd, r, buf, dlen);

	if (qno == Qadmin) {
		mkadmcmd(ctlr, cmd, op);	/* uncommon case */
		return;
	}

	if (op != Cmdread && op != Cmdwrite && op != Cmdflush)
		panic("sdnvme: bad Cmd %d for queue id %d", op, qno);
	cmd->slba = lba;
	assert(nsid);

	if (r)
		assert(r->data == buf);
	setcmdlen(cmd, r, dlen);
}

static void
updmaxqlen(Ctlr *ctlr, Qpair *qp, SDreq *r)
{
	int qlen;

	if (r == nil)
		return;
	qlen = (qp->sidx.tl + qp->sqlen - qp->sidx.hd) % qp->sqlen;
	if (qlen > ctlr->maxsqlen)
		ctlr->maxsqlen = qlen;
}

/*
 * send a command via the submission queue.
 * call with ctlr->issuelock held.
 * advances submission queue's tail index.
 */
static void
sendcmd(Ctlr *ctlr, Qpair *qp, Transfer *xfr, SDreq *r, ushort cmdid)
{
	int qno;

	xfr->done = 0;
	xfr->cmdid = cmdid;
	xfr->qtm = TK2MS(sys->ticks);
	qno = qp - ctlr->qpair;
	assert(qno >= 0 && qno < Nqueues);
	if (Intrdebug)
		iprint("issue queue %d cmdid %d...", qno, xfr->cmdid);

	updmaxqlen(ctlr, qp, r);
	xfr->stcyc = 0;
	if (Measure)
		xfr->stcyc = meascycles();

	/*
	 * Notify controller of new submission queue entry,
	 * which triggers execution of it.
	 */
	ctlr->inflight++;
	coherence();
	*doorbellsqtl(ctlr, qno) = qp->sidx.tl;		/* start i/o */
	coherence();
	ctlr->regs->intmclr = ctlr->intrsena = Vall;	/* unmask intrs */
	coherence();
}

static int
doneio(void* arg)
{
	coherence();
	return ((Transfer *)arg)->done;
}

static uint
sqidxinc(Qpair *qp, uint idx)
{
	if (++idx >= qp->sqlen)
		idx = 0;
	return idx;
}

static Transfer *
getfreexfr(Ctlr *ctlr)
{
	Transfer *xfr;

	ilock(&ctlr->xfrlock);			/* allocate xfr */
	xfr = findxfr(ctlr, 0);
	if (xfr == nil) {
		xfr = malloc(sizeof *xfr);
		if (xfr == nil)
			panic("nvmeissue: out of memory");
		xfr->next = ctlr->xfrs;
		ctlr->xfrs = xfr;	/* add new xfr to chain */
	}
	xfr->cmdid = Reserved;
	xfr->qtm = 0;
	iunlock(&ctlr->xfrlock);
	return xfr;
}

static int
qnotfull(void *arg)
{
	return !QFULL((Qpair *)arg);
}

/*
 * call with ctlr->QLock held.  ensure sub q (qp) space.
 */
static void
qdrain(Ctlr *ctlr, Qpair *qp)
{
	int trips;

	for (trips = 15000; trips > 0 && QFULL(qp); trips--)
		/*
		 * very uncommon case.
		 * we hope that the sub q is draining, but make sure we don't
		 * get stuck here if it's disabled, during shutdown, say.
		 */
		tsleep(ctlr, qnotfull, qp, 1);
	panic("nvme: qdrain stuck");
}

static void
prerr(int sts)
{
	if (sts)
		iprint("nvmeissue: cmd error status %#ux: "
			"code %#ux type %d more %d do-not-retry %d\n", sts,
			(sts >>  1) & MASK(8), (sts >>  9) & MASK(3),
			(sts >> 14) & MASK(1), (sts >> 15) & MASK(1));
}

static void
incomplete(Ctlr *ctlr, Transfer *xfr, Cmd *qtl, int qno, long tmout)
{
	/*
	 * i/o didn't complete after several seconds,
	 * so what state is the controller in?
	 */
	isfatal(ctlr, "nvmeissue");
	panic("sd%C0: nvmeissue: q %d cmd id %d op %#x didn't complete in %ld ms.",
		ctlr->sdev->idno, qno, xfr->cmdid, qtl->opcode, tmout);
}

/*
 * to avoid overheating, if too much has been written too recently, sleep to
 * ensure 1 second between previous and next writes.  needn't hold up reads.
 */
static void
throttle(Ctlr *ctlr, uvlong dlen)
{
	int coolticks;

	qlock(&ctlr->throtlck);
	if (Writeheatbytes > 0 && ctlr->written >= Writeheatbytes) {
		coolticks = sys->ticks - ctlr->writetick;
		if (coolticks < HZ)
			tsleep(&up->sleep, return0, 0, (HZ-coolticks)*1000/HZ);
		ctlr->written = 0;
		ctlr->throttles++;
	}
	ctlr->written += dlen;
	ctlr->writetick = sys->ticks;
	qunlock(&ctlr->throtlck);
}

static void
setxfrread(Transfer *xfr, void *, uintptr )
{
	xfr->rdwr = Read;
}

/* set xfr->rdwr and fiddle the caches before a transfer */
static void *
xfrcachebefore(Transfer *xfr, int qno, int nvop, void *data, uintptr dlen)
{
	if (qno == Qio) {
		if (nvop == Cmdread)
			setxfrread(xfr, data, dlen);
		else if (nvop == Cmdwrite) {
			xfr->rdwr = Write;
		}
	} else if (qno == Qadmin) {
		if (nvop == Admid)
			setxfrread(xfr, data, dlen);
	} else
		panic("nvmeissue: queue id %d out of range", qno);
	return data;
}

/* fiddle the caches after a transfer */
static void
xfrcacheafter(Transfer *, void *, uintptr )
{
}

static void
waitxfr(Ctlr *ctlr, Transfer *xfr, int qno, Cmd *qtl)
{
	long tmout;
	Mpl pl;

	tmout = (qno == Qadmin? 1000: Timeout);
	/* up has been nil here during shutdown on p550 9k */
	if (up == nil) {			/* can't use error macros */
		pl = spllo();
		awaitbitpatms(&xfr->done, 1, 1, tmout);
		splx(pl);
	} else {
		while(waserror())
			;
		/* this is the only process waiting for this xfr. */
		tsleep(xfr, doneio, xfr, tmout);
		poperror();
	}
	if (!xfr->done) {
		/* we see missing intrs with the Samsung 983 DCT. */
		ctlr->timeouts++;
		nvmeinterrupt(nil, ctlr);
		if (!xfr->done)
			incomplete(ctlr, xfr, qtl, qno, tmout);
	}
}

/*
 * add new nvme command to tail of submission queue of Qpair,
 * and wait for it to complete.  return status with phase bit zeroed.
 * nvop is an nvme operation code, not a scsi op code.
 */
static int
nvmeissue(Ctlr *ctlr, Qpair *qp, SDreq *r, int nvop, ulong nsid, void *data,
	uvlong lba, uintptr dlen)
{
	int qno;
	ushort sts;
	Cmd *qtl;
	Transfer *xfr;

	/* initialise a new Transfer and flush its data's caches */
	xfr = getfreexfr(ctlr);
	xfr->rdwr = 2;
	if (r) {			/* any SDreq overrides args */
		data = r->data;
		dlen = r->dlen;
	}
	if (dlen > 2*ctlr->pgsz)
		iprint("nvmeissue: dlen %llud > 2*pgsz (%d)\n",
			(uvlong)dlen, 2*ctlr->pgsz);
	qno = qp - ctlr->qpair;
	data = xfrcachebefore(xfr, qno, nvop, data, dlen);

	if (r && r->write)
		throttle(ctlr, dlen);
	qlock(ctlr);
	if (QFULL(qp))
		qdrain(ctlr, qp);	/* rare case */
	/*
	 * serialise composition of the command struct in reserved space at old
	 * sub q tail.  mkcmd converts "data" to physical address space for
	 * command.
	 */
	ilock(&ctlr->issuelock);
	qtl = &qp->q[qp->sidx.tl];	/* reserve uncached sub q tail space */
	qp->sidx.tl = sqidxinc(qp, qp->sidx.tl);	/* advance tail */
	mkcmd(ctlr, qtl, r, nvop, nsid, data, qno, lba);
	sendcmd(ctlr, qp, xfr, r, qtl->cmdid);
	iunlock(&ctlr->issuelock);
	qunlock(ctlr);

	waitxfr(ctlr, xfr, qno, qtl);
	xfrcacheafter(xfr, data, dlen);
	sts = xfr->status;
	xfr->cmdid = 0;				/* xfr available for re-use */
	if (sts)
		prerr(sts);
	return sts;
}

/* map scsi to nvm opcodes */
static int
scsiop2nvme(uchar* cmd)
{
	if (isscsiread(*cmd))
	 	return Cmdread;
	else if (isscsiwrite(*cmd))
	 	return Cmdwrite;
	else {
		iprint("scsiop2nvme: scsi cmd %#ux unexpected\n", *cmd);
		return -1;
	}
}

static int
issueios(SDreq *r)
{
	int n, max, iostat, nvmcmd;
	ulong count;			/* sectors */
	uvlong lba;
	Ctlr *ctlr;
	SDunit *unit;

	DBG("issueios...");
	scsilbacount(r->cmd, r->clen, &lba, &count);
	unit = r->unit;
	if(count * unit->secsize > r->dlen)
		count = r->dlen / unit->secsize;
	ctlr = unit->dev->ctlr;
	max = 2*ctlr->pgsz / unit->secsize;	/* needs 1 or 2 prp addrs */
	/* to do this in generality, need to allocate a prp list page */
	if (0)
		max = (ctlr->mdts? ctlr->mdts * ctlr->minpgsz: 128*KB) /
			unit->secsize;
	nvmcmd = scsiop2nvme(r->cmd);
	if (nvmcmd == -1)
		error("nvme: scsi cmd unexpected");

	iostat = 0;
	for (; count > 0; count -= n){
		n = MIN(count, max);
		r->dlen = n * unit->secsize;
		iostat = nvmeissue(ctlr, ioqp(ctlr), r, nvmcmd, ctlr->ns,
			r->data, lba, n);
		if (iostat)
			break;
		lba += n;
		r->data = (uchar *)r->data + r->dlen;
	}
	return iostat;
}

/*
 * Issue an I/O (SCSI) command to a controller and wait for it to complete.
 * The command and its length is contained in r->cmd and r->cmdlen.
 * If any data is to be returned, r->dlen should be non-zero, and
 * the returned data will be placed in r->data.
 */
static int
nvmerio(SDreq* r)
{
	int i, iostat;
	ulong origdlen;
	uchar *origdata;
	static char info[256];

	if(*r->cmd == ScmdSynccache || *r->cmd == ScmdSynccache16)
		return sdsetsense(r, SDok, 0, 0, 0);

	/* scsi command to get information about the drive or disk? */
	if((i = sdfakescsi(r, info, sizeof info)) != SDnostatus){
		r->status = i;
		return i;
	}

	/*
	 * Cap the size of individual transfers and repeat if needed.
	 * Save r->data and r->dlen, and restore them after issueios.
	 * could call scsibio, which allocates an SDreq.
	 */
	if(r->data == nil)
		return SDok;
	origdata = r->data;
	origdlen = r->dlen;

	assert(r->unit->secsize >= Minsect &&
		r->unit->secsize <= ((Ctlr *)r->unit->dev->ctlr)->pgsz);
	iostat = issueios(r);

	r->rlen = (uchar *)r->data - origdata;
	r->data = origdata;
	r->dlen = origdlen;
	r->status = SDok;
	if (iostat != 0) {
		r->status = SDeio;
		/* 3, 0xc, 2: write error, reallocation failed */
		sdsetsense(r, SDcheck, 3, 0xc, 2);
	}
	return r->status;
}

static int
nvmerctl(SDunit* unit, char* p, int l)
{
	int n;
	Ctlr *ctlr;
	Regs *regs;

	if((ctlr = unit->dev->ctlr) == nil)
		return 0;
	regs = ctlr->regs;
	n = snprint(p, l, "config %#lux capabilities %#llux status %#lux\n",
		regs->cc, regs->cap, regs->csts);
	/*
	 * devsd has already generated "inquiry" line using the model,
	 * so printing ctlr->model here would be redundant.
	 */
	n += snprint(p+n, l-n, "serial %s\n", ctlr->serial);
	if(unit->sectors)
		n += snprint(p+n, l-n, "geometry %lld %lud\n",
			unit->sectors, unit->secsize);
	return n;
}

static uvlong
nonzerocnt(Ctlr *ctlr, int rdwr)
{
	uvlong count;

	count = ctlr->dirxfrs[rdwr].count;
	return count? count: 1;			/* don't divide by zero */
}

/*
 * must emit exactly one line per controller (per sd(3)).
 *
 * on a busy fossil, the output was:
 *	sdo nvme [⋯]: : max sub q len 6/32; avg ns: rd 11582 wr 10555; \
 *		ops rd 2,470,385 wr 2,507,557; timeouts 0 throttles 316
 * but on the samsung 990 pro, it was:
 *	sdn nvme [⋯]: max sub q len 1/32; avg ns: rd 15,276 wr 9,784; \
 *		ops rd 22,881 wr 22,702; timeouts 0 throttles 2
 *
 * which suggests that more than one transfer per queue is rare unless
 * we throttle writes to avoid overheating,
 * thus one gets most of the benefit we see from a queue depth of 1,
 * at least with page size of 4K and block size of 8K.
 */
static char *
nvmertopctl(SDev *sdev, char *p, char *e)
{
	Ctlr *ctlr;
	Dirxfrs *dsr, *dsw;

	ctlr = sdev->ctlr;
	dsr = &ctlr->dirxfrs[Read];
	dsw = &ctlr->dirxfrs[Write];
	return seprint(p, e, "sd%c nvme regs %#p irq %d: max sub q len %d/%d;"
		" avg ns: rd %,lld wr %,lld; ops rd %,lld wr %,lld;"
		" timeouts %ld throttles %ld\n",
		sdev->idno, ctlr->port, ctlr->irq, ctlr->maxsqlen, ctlr->sqlen,
		dsr->totns / nonzerocnt(ctlr, Read),
		dsw->totns / nonzerocnt(ctlr, Write),
		dsr->count, dsw->count, ctlr->timeouts, ctlr->throttles);
}

static void
reset(Regs *regs)
{
	DBG("reset regs->cc %#lux...", regs->cc);
	if (regs->cc & Enable) {
		DBG("enabled, awaiting ready...");
		if (awaitbitpat(&regs->csts, Rdy, Rdy) < 0)
			iprint("nvme reset timed out awaiting ready\n");
		regs->cc &= ~Enable;
		coherence();
	}
	/* else may have previously cleared Enable & be waiting for not ready */
	DBG("disabled, awaiting not ready...");
	if (awaitbitpat(&regs->csts, Rdy, 0) < 0)
		iprint("nvme reset timed out awaiting not ready\n");
}

static void
nvmedrive(SDunit *unit)
{
	uchar *p;
	Ctlr *ctlr;

	DBG("nvmedrive...");
	unit->sense[0] = 0x70;
	unit->sense[7] = sizeof(unit->sense)-7;

	memset(unit->inquiry, 0, sizeof unit->inquiry);
	unit->inquiry[0] = SDperdisk;
	unit->inquiry[2] = 2;
	unit->inquiry[3] = 2;
	unit->inquiry[4] = sizeof unit->inquiry - 4;
	p = &unit->inquiry[8];
	ctlr = unit->dev->ctlr;
	/* model is smaller than unit->inquiry-8 */
	strncpy((char *)p, ctlr->model, sizeof ctlr->model);

	unit->secsize = ctlr->secsize;
	unit->sectors = ctlr->sectors;
	print("#S/sd%C%d: nvme %,lld sectors: %s fw %s serial %s\n",
		unit->dev->idno, unit->subno, unit->sectors,
		ctlr->model, ctlr->fw, ctlr->serial);
}

static void
pickpgsz(Ctlr *ctlr)
{
	ulong minpgsz, maxpgsz;

	minpgsz = 1 << (12 + ((ctlr->regs->cap >> 48) & MASK(4)));
	maxpgsz = 1 << (12 + ((ctlr->regs->cap >> 52) & MASK(4)));
	ctlr->minpgsz = minpgsz;		/* for Ctlrid->mdts */
	ctlr->pgsz = MIN(Startpgsz, maxpgsz);
	if (ctlr->pgsz < minpgsz)
		ctlr->pgsz = minpgsz;
	if (Sdalign >= 4*KB && ctlr->pgsz > Sdalign)
		ctlr->pgsz = Sdalign;
	if (ctlr->pgsz < 4*KB)			/* sanity */
		ctlr->pgsz = 4*KB;
}

static void
pickqlens(Ctlr *ctlr)
{
	ulong mqes;

	mqes = (ctlr->regs->cap & MASK(16)) + 1;  /* max i/o [sc] q len */
	ctlr->sqlen = MIN(mqes, Sqlen);
	ctlr->cqlen = MIN(mqes, Cqlen);
}

static void
nvmreset(Regs *regs)
{
	if (regs->cap & Nssrs) {		/* nvm subsys reset avail.? */
		regs->cc |= Nssro;		/* clear Nssro by setting it */
		regs->nssrc = 'N'<<24 | 'V'<<16 | 'M'<<8 | 'e';
		if (awaitbitpat(&regs->csts, Nssro, Nssro) < 0)
			print("nvme subsys reset timed out awaiting Nssro\n");
	}
}

static SDev*
nvmeprobe(Pcidev *p)
{
	int logstride;
	uintptr port;
	Ctlr *ctlr;
	Regs *regs;
	SDev *sdev;
	static int count;

	port = (ulong)p->mem[0].bar & ~0x0f;	/* assume 32-bit bars */
	regs = vmap(port, p->mem[0].size);
	if(regs == nil){
		print("nvmeprobe: phys address %#p in use did=%#ux\n",
			port, p->did);
		return nil;
	}
	DBG("nvmeprobe: port %#p vmapped regs %#p\n", port, regs);
	if (regs == 0 || (uintptr)regs == ~(uintptr)0)
		panic("sdnvme: bad regs %#p", regs);

	sdev = nil; USED(sdev);
	if ((ctlr = malloc(sizeof(Ctlr))) == nil ||
	    (sdev = malloc(sizeof(SDev))) == nil) {
fail:
		free(sdev);
		free(ctlr);
		vunmap(regs, p->mem[0].size);
		return nil;
	}

	ctlr->regs = regs;
	ctlr->port = port;
	ctlr->irq = p->intl;
	DBG("nvmeprobe: irq %d\n", ctlr->irq);
	/*
	 * Attempt to hard-reset the board.
	 */
	coherence();
	reset(regs);
#ifdef TODO_notyet
	if (probeulong((ulong *)&regs->cap, Read) < 0)
		iprint("nvmerobe: regs->cap va %#p faulted on read\n",
			&regs->cap);
#endif
	DBG("nvmeprobe: regs->cap %#p: %#llux\n", &regs->cap, regs->cap);
	if (regs->cap == 0 || regs->cap == ~0ull) {
		iprint("nvmeprobe: cap reg wrong: %#p, failing\n",
			(uintptr)regs->cap);
		goto fail;
	}
	logstride = (regs->cap >> 32) & MASK(4);	/* doorbell stride */
	/* this restriction may no longer be needed. test in a vm? */
	if (logstride != 0)
		panic("nvmeprobe: lg doorbell stride must be 2 (for now), not %d",
			2 + logstride);
	ctlr->stride = 1 << (2 + logstride);	/* 2^(2+logstride) */
	// nvmreset(regs);			/* nvm subsys reset avail.? */

	pickpgsz(ctlr);
	pickqlens(ctlr);
	/* we haven't chosen a namespace yet, so we don't know sector size */

	sdev->ifc = &sdnvmeifc;
	sdev->idno = 'n';		/* actually assigned in sdadddevs() */
	sdev->nunit = NCtlrdrv;		/* max. drives (can be number found) */
	sdev->ctlr = ctlr;		/* cross link */
	ctlr->sdev = sdev;

	/*
	 * we (pnp) don't have a `spec' argument, so
	 * we'll assume that sdn0 goes to the first nvme host
	 * adapter found, sdo0 to the next, etc.
	 */
	iprint("#S/sd%C: nvme %ld.%ld.%ld: irq %d regs %#p page size %d "
		"doorbell stride %d\n",
		sdev->idno + count++, regs->vs>>16, (regs->vs>>8) & MASK(8),
		regs->vs & MASK(8), ctlr->irq, ctlr->port, ctlr->pgsz,
		ctlr->stride);

	/* would probe for drives here if there could be more than one. */
	/* upon return, this many sdev->units will be allocated by caller. */
	sdev->nunit = 1;
	return sdev;
}

static void
sdevadd(SDev *sdev, SDev **head, SDev **tail)
{
	if(*head != nil)
		(*tail)->next = sdev;
	else
		*head = sdev;
	*tail = sdev;
}

/*
 * find all nvme controllers
 */
static SDev*
nvmepnp(void)
{
	Ctlr *ctlr;
	Pcidev *p;
	SDev *sdev, *head, *tail;

	p = nil;
	head = tail = nil;
	while(p = pcimatch(p, 0, 0)){
		/* ccrp 2 is NVME */
		if(p->ccrb != Pcibcstore || p->ccru != Pciscnvm || p->ccrp != 2)
			continue;
		if((sdev = nvmeprobe(p)) == nil)
			continue;
		ctlr = sdev->ctlr;
		ctlr->pcidev = p;
		sdevadd(sdev, &head, &tail);
		if (nctlrs >= NCtlr)
			print("too many nvme controllers\n");
		else
			ctlrs[nctlrs++] = ctlr;
	}
	DBG("nvmepnp done...");
	return head;
}

static void
allocqpair(Ctlr *ctlr, Qpair *qp)
{
	assert(ctlr->pgsz);
	qp->sqlen = ctlr->sqlen;
	qp->cqlen = ctlr->cqlen;
	qp->q    = mallocalign(qp->sqlen * sizeof *qp->q,    ctlr->pgsz, 0, 0);
	qp->cmpl = mallocalign(qp->cqlen * sizeof *qp->cmpl, ctlr->pgsz, 0, 0);
	if (qp->q == nil || qp->cmpl == nil)
		panic("nvmectlrenable: out of memory for queues");
}

static void
configure(Ctlr *ctlr, Qpair *qpadm)
{
	Regs *regs = ctlr->regs;

	regs->aqa = (ctlr->cqlen - 1)<<16 | (ctlr->sqlen - 1);
	regs->asq = PCIWADDR(qpadm->q);
	regs->acq = PCIWADDR(qpadm->cmpl);
	regs->cc = log2(sizeof(Completion))<<20 | log2(sizeof(Cmd))<<16 |
		(log2(ctlr->pgsz)-12) << 7 | Cssnvm;
	coherence();
}

static void
enable(Regs *regs)
{
	if (!(regs->cc & Enable)) {
		DBG("enable: not enabled, awaiting not ready...");
		if (awaitbitpat(&regs->csts, Rdy, 0) < 0)
			iprint("nvme enable timed out awaiting not ready\n");
		regs->cc |= Enable;
		coherence();
	}
	/* else may have previously set Enable & be waiting for ready */
	DBG("enable: enabled, awaiting ready...");
	if (awaitbitpat(&regs->csts, Rdy, Rdy) < 0)
		iprint("nvme enable timed out awaiting ready\n");
}

/*
 * ns numbers start at 1 and are densely-packed.
 * pick one with 512-byte blocks, return preferred lbafmt via *lbafmtp.
 * read an Nsid into *nsid.
 */
static int
bestns(Ctlr *ctlr, int nns, Nsid *nsid, int *lbafmtp)
{
	int i, ns, second, nssecond, lbasize;
	Lbafmt *lbafmt;

	second = 0;
	nssecond = 0;
	*lbafmtp = 0;
	for (ns = 1; ns <= nns; ns++) {
		memset(nsid, 0, sizeof *nsid);
		if (nvmeissue(ctlr, admqp(ctlr), nil, Admid, ns, nsid, 0,
		    sizeof *nsid) != 0)
			panic("nvmectlrenable: Admid(%d) failed", ns);
		for (i = 0; i < nelem(nsid->lbafmt); i++) {
			lbafmt = &nsid->lbafmt[i];
			if (lbafmt->lglbasize == 0)	/* end lbafmt list? */
				break;
			lbasize = 1 << lbafmt->lglbasize;
			if (Debugns)
				print("nvme ns %d: lba %d mdsize %d perf %d\n",
					ns, lbasize, lbafmt->mdsize,
					lbafmt->relperf & 3);
			if (lbafmt->mdsize == 0 && lbasize == Minsect) {
				*lbafmtp = i;
				return ns;
			}
			/* settle for 4k if that's all there is */
			if (lbafmt->mdsize == 0 && lbasize == 4096) {
				second = i;
				nssecond = ns;
			}
		}
	}
	if (nssecond)
		*lbafmtp = second;
	return second;
}

/*
 * copy id string from controller, trim trailing blanks, downcase.
 * assumes src is unterminated and dest is at least one byte larger.
 */
static void
idcopy(char *dest, char *src, int size)
{
	char *p, *pend;

	memmove(dest, src, size);
	pend = &dest[size];
	*pend-- = '\0';
	for (p = pend; p > dest && *p == ' '; p--)
		*p = '\0';
	for (p = dest; p <= pend && *p != '\0'; p++)
		*p = tolower(*p);
}

static void
nvmeintron(SDev *sdev)
{
	char name[32];
	Ctlr *ctlr;

	DBG("nvmeintron...");
	ctlr = sdev->ctlr;
	snprint(name, sizeof(name), "sd%c (%s)", sdev->idno, sdev->ifc->name);
	enableintr(ctlr, nvmeinterrupt, ctlr, name);
	ctlr->regs->intmset = ~0;	/* mask all interrupt sources */
}

static void
zeroqhdtls(Qpair *qp)
{
	qp->cidx.hd = qp->sidx.tl = 0;
	qp->cidx.tl = qp->sidx.hd = 0;	/* paranoia */
	coherence();
}

/*
 * return malloced id page, copy id strings into ctlr.
 * return ctlrid->nns via nnsp.
 */
static char *
getidpage(Ctlr *ctlr, int *nnsp)
{
	Ctlrid *ctlrid;

	ctlrid = mallocalign(BY2PG, ctlr->pgsz, 0, 0);
	if (ctlrid == nil)
		panic("nvmectlrenable: out of memory");
	memset(ctlrid, 0, sizeof *ctlrid);
	if (nvmeissue(ctlr, admqp(ctlr), nil, Admid, Nsall, ctlrid, 0,
	    sizeof *ctlrid) != 0)
		panic("nvmectlrenable: Admid(Nsall) failed");

	/* smuggle hw id strings into ctlr for later printing */
	idcopy(ctlr->serial, ctlrid->serial, sizeof ctlrid->serial);
	idcopy(ctlr->model, ctlrid->model, sizeof ctlrid->model);
	idcopy(ctlr->fw, ctlrid->fw, sizeof ctlrid->fw);
	if (ctlrid->mdts)
		ctlr->mdts = 1 << ctlrid->mdts;
//	iprint("nvme: max xfr size %d\n", ctlr->mdts * ctlr->minpgsz);
	*nnsp = ctlrid->nns;
	return (char *)ctlrid;
}

static int
nvmectlrenable(Ctlr* ctlr)
{
	int bestlba, nns, gotns;
	Nsid *nsid;
	Qpair *qpadm, *qpio;
	Regs *regs;

	DBG("nvmectrlenable...");
	/* we need at least one admin queue and one i/o queue */
	qpadm = admqp(ctlr);
	allocqpair(ctlr, qpadm);
	qpio = ioqp(ctlr);
	allocqpair(ctlr, qpio);

	regs = ctlr->regs;
	assert(!(regs->cc & Enable));
	configure(ctlr, qpadm);	/* must do this while ctlr is disabled */
	enable(regs);
	zeroqhdtls(qpadm);		/* paranoia */

	regs->intmset = ~0;		/* mask all interrupt sources */
	nvmeintron(ctlr->sdev);

	nsid = (Nsid *)getidpage(ctlr, &nns);

	/*
	 * create first i/o queue with admin queue cmds.
	 * completion queue must be created first.
	 */
	DBG("create i/o queues...");
	if (nvmeadmissue(ctlr, Admmkiocq, Nsunused, qpio->cmpl) != 0)
		panic("nvmectlrenable: Admmkiocq failed");
	if (nvmeadmissue(ctlr, Admmkiosq, Nsunused, qpio->q) != 0)
		panic("nvmectlrenable: Admmkiosq failed");
	zeroqhdtls(qpio);		/* paranoia */

	/* find a suitable namespace, copy parameters into ctlr */
	gotns = bestns(ctlr, nns, nsid, &bestlba);	/* fills in nsid page */
	if (gotns == 0)
		panic("nvmectlrenable: no suitable namespace found");

	/* remember these for SDunit */
	ctlr->secsize = 1 << nsid->lbafmt[bestlba].lglbasize;
	ctlr->sectors = nsid->cap;
	/* cap at 16TB for now, for sanity.  adjust to taste. */
	if (ctlr->sectors > 16*TB/ctlr->secsize)
		ctlr->sectors = 16*TB/ctlr->secsize;
	ctlr->ns = gotns;
	free(nsid);
	if (Debugns)
		print("nvme best ns: %d: sectors %,lld of %d bytes\n",
			ctlr->ns, ctlr->sectors, ctlr->secsize);
	return 1;
}

static void
freeqpair(Qpair *qp)
{
	free(qp->q);
	free(qp->cmpl);
	qp->q = nil;
	qp->cmpl = nil;
}

static void
ckstuck(void)
{
	int i;

	for (i = 0; i < nctlrs; i++)
		nvmeinterrupt(nil, ctlrs[i]);
}

/*
 * activate a single nvme controller, sdev.
 * upon return, sdev->nunit SDunits will be allocated.
 */
static int
nvmeenable(SDev* sdev)
{
	Ctlr *ctlr;

	ctlr = sdev->ctlr;
	if(admqp(ctlr)->q)
		return 0;
	pcisetbme(ctlr->pcidev);
	if(!nvmectlrenable(ctlr)) {
		freeqpair(admqp(ctlr));
		freeqpair(ioqp(ctlr));
		return 0;
	}

	/* watch for hardware bugs */
	lock(&clocklck);
	if (!clockrunning) {
		addclock0link(ckstuck, 1000);
		clockrunning = 1;
	}
	unlock(&clocklck);
	return 1;
}

static void
nvmeintroff(SDev *sdev)
{
	char name[32];
	Ctlr *ctlr;

	ctlr = sdev->ctlr;
	ctlr->regs->intmset = ~0;		/* mask all interrupt sources */

	snprint(name, sizeof(name), "sd%c (%s)", sdev->idno, sdev->ifc->name);
	disableintr(ctlr, nvmeinterrupt, ctlr, name);
}

/*
 * returns when all in-flight transfers are done.
 * call with shutlock & issuelock held.
 */
static void
waitnoxfrs(Ctlr *ctlr)
{
	int i;

	for (i = 1000; i-- > 0 && ctlr->inflight > 0; ) {
		iunlock(&ctlr->shutlock);
		iunlock(&ctlr->issuelock);
		delay(1);
		ilock(&ctlr->issuelock);
		ilock(&ctlr->shutlock);
	}
	if (i <= 0)
		iprint("sdnvme: %d transfers still in flight after 1 s.\n",
			ctlr->inflight);
}

static int
nvmedisable(SDev* sdev)			/* disable interrupts for this sdev */
{
	Ctlr *ctlr;

	ctlr = sdev->ctlr;
	if (ctlr == nil)
		return 1;
	nvmeissue(ctlr, ioqp(ctlr), nil, Cmdflush, Nsall, nil, 0, 1);

	ilock(&ctlr->issuelock);
	ilock(&ctlr->shutlock);

	waitnoxfrs(ctlr);
	nvmeintroff(sdev);
	pciclrbme(ctlr->pcidev);

	iunlock(&ctlr->shutlock);
	iunlock(&ctlr->issuelock);
	return 1;
}

static void
nvmeclear(SDev* sdev)			/* clear the interface for this sdev */
{
	Ctlr *ctlr;

	ctlr = sdev->ctlr;
	if (ctlr == nil)
		return;
	ilock(&ctlr->issuelock);
	ilock(&ctlr->shutlock);
	if (ctlr->regs) {
		waitnoxfrs(ctlr);
		reset(ctlr->regs);	/* ctlrs and drives are one-to-one */
	}
	iunlock(&ctlr->shutlock);
	iunlock(&ctlr->issuelock);
}

/*
 * see if a particular drive exists.
 * must not set unit->sectors here, but rather in nvmeonline.
 */
static int
nvmeverify(SDunit *unit)
{
	if (unit->subno != 0)
		return 0;
	return 1;
}

/*
 * initialise a drive known to exist.
 * returns boolean for success.
 */
static int
nvmeonline(SDunit *unit)
{
	int r;

	if (unit->subno != 0)		/* not me? */
		return 0;
	if (unit->sectors)		/* already inited? */
		return 1;
	r = scsionline(unit);
	if(r == 0)
		return r;
	nvmedrive(unit);
	/*
	 * could hang around until disks are spun up and thus available as
	 * nvram, dos file systems, etc.  you wouldn't expect it, but
	 * the intel 330 sata ssd takes a while to `spin up'.
	 */
	return 1;			/* drive ready */
}

SDifc sdnvmeifc = {
	"nvme",				/* name */

	nvmepnp,			/* pnp */
	nil,				/* legacy */
	nvmeenable,			/* enable */
	nvmedisable,			/* disable */

	nvmeverify,			/* verify */
	nvmeonline,			/* online */
	nvmerio,			/* rio */
	nvmerctl,			/* rctl */
	nil,				/* wctl */

	scsibio,			/* bio */
	nil,				/* probe */
	nvmeclear,			/* clear */
	nvmertopctl,			/* rtopctl */
	nil,				/* wtopctl */
};
