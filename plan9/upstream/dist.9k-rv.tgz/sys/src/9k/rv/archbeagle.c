/*
 * jh7100-specific stuff (u74 for e.g., beagle v): soc init, reset
 */
#include "u.h"
#include "../port/lib.h"
#include "mem.h"
#include "dat.h"
#include "fns.h"

static void
beaglereset(void)
{
	if(soc.wdog0) {
		ulong *wd = (ulong*)soc.wdog0;

		wd[0x13c/4] = 0x378f0765;	/* unlock regs */
		coherence();
		wd[0x104/4] = 1;	/* reset, not interrupt, on timer expiry */
		wd[0x108/4] = 0;	/* watchdog timer count */
		wd[0x110/4] = 1;	/* watchdog enable */
		coherence();
		delay(5000);
	}
}

void (*rvreset)(void) = beaglereset;
