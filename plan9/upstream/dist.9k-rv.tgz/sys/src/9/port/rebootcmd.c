/*
 * rebootcmd - read next kernel and start it
 */
#include	"u.h"
#include	"../port/lib.h"
#include	"mem.h"
#include	"dat.h"
#include	"fns.h"
#include	"../port/error.h"
#include	<a.out.h>
#include 	"/sys/src/libmach/elf.h"

enum {
	Ehdr32sz	= 52,
	Phdr32sz	= 32,
	Shdr32sz	= 40,

	Ehdr64sz	= 64,
	Phdr64sz	= 56,
	Shdr64sz	= 64,
};

static uchar elfident[] = {
	'\177', 'E', 'L', 'F',
};

void
readn(Chan *c, void *vp, long n)
{
	char *p;
	long nn;

	p = vp;
	while(n > 0) {
		nn = CHANDEV(c)->read(c, p, n, c->offset);
		if(nn == 0) {
			iprint("rebootcmd: %ld = readn(c, p, %ld, %lld)\n",
				nn, n, c->offset);
			error(Eshort);
		}
		c->offset += nn;
		p += nn;
		n -= nn;
	}
}

/* assume the elf header is in the byte order of this machine */
int
readelfhdr(Chan *c, ulong, Execvals *evp)
{
	Ehdr ehdr;
	Phdr phdrs[3];

	c->offset = 0;			/* back up */
	readn(c, &ehdr, sizeof ehdr);
	if(memcmp(&ehdr.ident[MAG0], elfident, sizeof elfident) != 0 ||
	    ehdr.ident[CLASS] != ELFCLASS32)
		return -1;

	/* get textsize and datasize from Phdrs */
	readn(c, phdrs, sizeof phdrs);
	evp->entry = ehdr.elfentry;
	evp->textsize = phdrs[0].filesz;
	evp->datasize = phdrs[1].filesz;
	c->offset = ROUNDUP(Ehdr32sz + 3*Phdr32sz, 16);	/* position for text */
	return 0;
}

static int
readelf64hdr(Chan *c, ulong, Execvals *evp)
{
	E64hdr ehdr;
	P64hdr phdrs[3];

	c->offset = 0;			/* back up */
	readn(c, &ehdr, sizeof ehdr);
	if(memcmp(&ehdr.ident[MAG0], elfident, sizeof elfident) != 0 ||
	    ehdr.ident[CLASS] != ELFCLASS64)
		return -1;

	/* get textsize and datasize from Phdrs */
	readn(c, phdrs, sizeof phdrs);
	evp->entry = ehdr.elfentry;
	evp->textsize = phdrs[0].filesz;
	evp->datasize = phdrs[1].filesz;
	c->offset = ROUNDUP(Ehdr64sz + 3*Phdr64sz, 16);	/* position for text */
	return 0;
}

static void
setbootcmd(int argc, char *argv[])
{
	char *buf, *p, *ep;
	int i;

	buf = malloc(1024);
	if(buf == nil)
		error(Enomem);
	p = buf;
	ep = buf + 1024;
	for(i=0; i<argc; i++)
		p = seprint(p, ep, "%q ", argv[i]);
	*p = 0;
	ksetenv("bootcmd", buf, 1);
	free(buf);
}

void
rebootcmd(int argc, char *argv[])
{
	Chan *c;
	Exec exec;
	Execvals ev;
	ulong magic, text, rtext, entry, data, size;
	uvlong stva;				/* for 64-bit kernels */
	uchar *p;

	if(argc == 0)			/* just `halt'? */
		exit(0);

	c = namec(argv[0], Aopen, OEXEC, 0);
	if(waserror()){
		cclose(c);
		nexterror();
	}

	memset(&exec, 0, sizeof exec);
	readn(c, &exec, sizeof(Exec));
	magic = l2be(exec.magic);
	/*
	 * for 64-bit kernels, consume the uvlong start address, even if
	 * we don't yet use it.
	 */
	stva = 0;
	if(magic & HDR_MAGIC)
		readn(c, &stva, sizeof stva);	/* consume header extension */

	/*
	 * AOUT_MAGIC is sometimes defined like this:
	 * #define AOUT_MAGIC	V_MAGIC || magic==M_MAGIC
	 * so we can only use it in a fairly stylized manner.
	 */
	if((magic == AOUT_MAGIC) || isokkernel && isokkernel(magic)) {
		entry = l2be(exec.entry);
		text = l2be(exec.text);
		data = l2be(exec.data);
	} else if(parseboothdr && (*parseboothdr)(c, magic, &ev) >= 0 ||
	    readelfhdr(c, magic, &ev) >= 0 ||
	    readelf64hdr(c, magic, &ev) >= 0){
		entry = ev.entry;
		text = ev.textsize;
		data = ev.datasize;
	} else {
		error(Ebadexec);
		notreached();
	}

	/*
	 * entry may be a virtual address with a different KZERO.
	 * on 64-bit systems, it may be a physical address, with the virtual
	 * address in the header expansion.
	 * convert it to a physical address.
	 */
	entry &= ~KSEGM;

	/* round text out to page boundary */
	rtext = PGROUND(entry+text) - entry;
	size = rtext + data;
	p = malloc(size);
	if(p == nil)
		error(Enomem);

	if(waserror()){
		free(p);
		nexterror();
	}

	readn(c, p, text);
	readn(c, p + rtext, data);

	ksetenv("bootfile", argv[0], 1);
	setbootcmd(argc-1, argv+1);

	reboot((void*)entry, p, size);

	panic("return from reboot!");
}
