/*
 * PCI bus support code.
 *
 * Handles PCI-Express (2003) by mostly ignoring extensions to PCI.
 * Has more than a few magic numbers.
 */
#include "u.h"
#include "../port/lib.h"
#include "mem.h"
#include "dat.h"
#include "fns.h"
#include "io.h"
#include "mp.h"
// #include "../port/dbgprint.h"

// #undef  DBG
// #define DBG	pcilog

#pragma	varargck	type	"T"	int

enum {					/* config space header type bits */
	Hdtmulti	= 1<<7,		/* flag: multi-function device */
};
enum {
	MaxFNO		= 7,
	MaxUBN		= 255,
};

struct
{
	char	output[PCICONSSIZE];
	int	ptr;
}PCICONS;

Lock pcicfginitlock;
int pcicfgmode = -1;	/* 1 = 0xcfc, 2 = 0xcfa, 3 = pci bios */
int pcimaxbno;		/* can be up to 255 */
int pcimaxdno;		/* can be up to 31 */
int pcivga;

Pcidev* pciroot;
Pcidev* pcilist;
Pcidev* pcitail;

int nobios;
static int nopcirouting;

/*
 * these bus names are from the Intel MP spec.
 * the others (not listed) are essentially all obsolete.
 */
static char* bustypes[] = {		/* indexed by Buses; see io.h */
	"INTERN",	"ISA",	"PCI",
};

int
pcilog(char *fmt, ...)
{
	int n;
	va_list arg;
	char buf[PRINTSIZE];

	va_start(arg, fmt);
	n = vseprint(buf, buf+sizeof(buf), fmt, arg) - buf;
	va_end(arg);

	if (PCICONS.ptr + n < sizeof PCICONS.output) {
		memmove(PCICONS.output+PCICONS.ptr, buf, n);
		PCICONS.ptr += n;
	} else
		n = 0;
	return n;
}

int
tbdffmt(Fmt* fmt)
{
	char *p;
	int l, r;
	uint type, tbdf;

	if((p = malloc(READSTR)) == nil)
		return fmtstrcpy(fmt, "(tbdffmt)");

	switch(fmt->r){
	case 'T':
		tbdf = va_arg(fmt->args, int);
		if(tbdf == BUSUNKNOWN)
			snprint(p, READSTR, "unknown");
		else {
			type = BUSTYPE(tbdf);
			if(type < nelem(bustypes))
				l = snprint(p, READSTR, bustypes[type]);
			else
				l = snprint(p, READSTR, "%d", type);
			snprint(p+l, READSTR-l, ".%d.%d.%d",
				BUSBNO(tbdf), BUSDNO(tbdf), BUSFNO(tbdf));
		}
		break;

	default:
		snprint(p, READSTR, "(tbdffmt)");
		break;
	}
	r = fmtstrcpy(fmt, p);
	free(p);

	return r;
}

ulong
pcibarsize(Pcidev *p, int rno)
{
	ulong v, size;

	v = pcicfgrw32(p->tbdf, rno, 0, 1);
	pcicfgrw32(p->tbdf, rno, Baraddrmask, 0);
	size = pcicfgrw32(p->tbdf, rno, 0, 1);
	if(v & Barioaddr)
		size |= ~MASK(16);
	pcicfgrw32(p->tbdf, rno, v, 0);

	return -(size & Baraddrmask);
}

static int
pcisizcmp(void *a, void *b)
{
	return ((Pcisiz *)a)->siz - ((Pcisiz *)b)->siz;
}

ulong
pcimask(ulong v)
{
	ulong mask;

	mask = BI2BY*sizeof(v);
	for(mask = 1<<(mask-1); mask != 0 && (v & mask) == 0; mask >>= 1)
		;
	mask--;
	if((v & mask) == 0)
		return v;

	v |= mask;
	return v+1;
}

/*
 * Allocate IO port address space on this bus (table—itb and ioa).
 */
static ulong
pciallocio(Pcisiz *table, Pcisiz *itb, ulong ioa, int wrreg)
{
	int hole;
	ulong bar;
	Pcidev *p;
	Pcisiz *tptr;

	for(tptr = table; tptr < itb; tptr++) {
		hole = tptr->siz;
		if(tptr->bar == -1)
			hole = 4*KB;
		ioa = (ioa+hole-1) & ~(hole-1);

		p = tptr->dev;
		bar = tptr->bar;
		if(bar == -1)
			p->ioa.bar = ioa;
		else {
			p->pcr |= IOen;
			p->mem[bar].bar = ioa|Barioaddr;
			if(wrreg)
				pcicfgrw32(p->tbdf, PciBAR0+(bar*4),
					ioa|Barioaddr, 0);
		}

		ioa += tptr->siz;
	}
	return ioa;
}

/*
 * Allocate memory address space on this bus (table—mtb and mema).
 */
static ulong
pciallocmem(Pcisiz *table, Pcisiz *mtb, ulong mema, int wrreg)
{
	int hole;
	ulong bar;
	Pcidev *p;
	Pcisiz *tptr;

	for(tptr = table; tptr < mtb; tptr++) {
		hole = tptr->siz;
		if(tptr->bar == -1)
			hole = MB;
		mema = (mema+hole-1) & ~(hole-1);

		p = tptr->dev;
		bar = tptr->bar;
		if(bar == -1)
			p->mema.bar = mema;
		else {
			p->pcr |= MEMen;
			p->mem[bar].bar = mema;
			if(wrreg) {
				DBG("%T: bar %d set to %#lux\n", p->tbdf,
					(int)bar, mema);
				pcicfgrw32(p->tbdf, PciBAR0+(bar*4), mema, 0);
			}
		}
		mema += tptr->siz;
	}
	return mema;
}

static int
pcisize(int size, int minsz)
{
	int hole;

	hole = pcimask(size);
	return hole < minsz? minsz: hole;
}

void	pcibusmap(Pcidev *root, ulong *pmema, ulong *pioa, int wrreg);

#ifdef NO_IOPORTS
int haveioports = 0;
#else
int haveioports = 1;
#endif

/*
 * Build tables of io & memory sizes (*itbp & *mtbp) from the pci tree at root.
 */
static void
pcisizetbl(Pcidev *root, Pcisiz **itbp, Pcisiz **mtbp, ulong ioa, ulong mema)
{
	int i, size, rno;
	ulong v, sioa, smema;
	Pcidev *p;
	Pcisiz *sztb, *itb, *mtb;

	itb = *itbp;
	mtb = *mtbp;
	for(p = root; p != nil; p = p->link)
		if(p->ccrb == Pcibcbridge) {
			if(p->ccru != Pciscbrpci || p->bridge == nil) {
				iprint("pci: ignored bridge %T subclass %d\n",
					p->tbdf, p->ccru);
				continue;
			}

			sioa = ioa;
			smema = mema;
			pcibusmap(p->bridge, &smema, &sioa, Read);

			p->mema.size = pcisize(smema-mema, MB);
			mtb->dev = p;
			mtb->bar = -1;
			mtb->siz = p->mema.size;
			mtb++;

			if (haveioports) {
				p->ioa.size  = pcisize(sioa-ioa, 4*KB);
				itb->dev = p;
				itb->bar = -1;
				itb->siz = p->ioa.size;
				itb++;
			}
		} else
			for(i = 0; i < nelem(p->mem); i++) {
				rno = PciBAR0 + i*4;
				v = pcicfgrw32(p->tbdf, rno, 0, 1);
#ifdef RISC_V
				if(i == 1)	/* TODO: nvme hack, no help */
					continue;
#endif
				size = pcibarsize(p, rno);
				if(size == 0)
					continue;
				if (!haveioports) {
					if (v & Barioaddr)
						continue;
					sztb = mtb++;
				} else
					if (v & Barioaddr)
						sztb = itb++;
					else
						sztb = mtb++;
				sztb->dev = p;
				sztb->bar = i;
				sztb->siz = size;

				p->mem[i].size = size;
			}
	*itbp = itb;
	*mtbp = mtb;
}

/*
 * Set all the bridge addresses & registers
 */
static void
pcibrgconf(Pcidev *root)
{
	ulong v, sioa, smema, base, limit;
	Pcidev *p;

	DBG("config bridges...");
	for(p = root; p != nil; p = p->link) {
		if(p->bridge == nil) {
			pcicfgrw8(p->tbdf, PciLTR, 64, 0);

			p->pcr |= MASen;
			DBG("master enable %T...", p->tbdf);
			pcicfgrw16(p->tbdf, PciPCR, p->pcr, 0);
			continue;
		}

		base = p->ioa.bar;
		limit = base+p->ioa.size-1;
		v = pcicfgrw32(p->tbdf, PciIBR, 0, 1);
		v = (v&0xFFFF0000)|(limit & 0xF000)|((base & 0xF000)>>8);
		pcicfgrw32(p->tbdf, PciIBR, v, 0);
		v = (limit & 0xFFFF0000)|(base>>16);
		pcicfgrw32(p->tbdf, PciIUBR, v, 0);

		base = p->mema.bar;
		limit = base+p->mema.size-1;
		v = (limit & 0xFFF00000)|((base & 0xFFF00000)>>16);
		pcicfgrw32(p->tbdf, PciMBR, v, 0);

		/*
		 * Disable memory prefetch
		 */
		pcicfgrw32(p->tbdf, PciPMBR, 0x0000FFFF, 0);
		pcicfgrw8(p->tbdf, PciLTR, 64, 0);

		/*
		 * Enable the bridge
		 */
		DBG("bridge enable %T...", p->tbdf);
		p->pcr |= IOen|MEMen|MASen;
		pcicfgrw32(p->tbdf, PciPCR, 0xFFFF0000|p->pcr, 0);

		sioa = p->ioa.bar;
		smema = p->mema.bar;
		pcibusmap(p->bridge, &smema, &sioa, Write);
	}
	DBG("\n");
}

void
pcibusmap(Pcidev *root, ulong *pmema, ulong *pioa, int wrreg)
{
	Pcidev *p;
	int ntb;
	ulong mema, ioa;
	Pcisiz *table, *tptr, *mtb, *itb;

	if(!nobios)
		return;

	ioa = *pioa;
	mema = *pmema;
	DBG("pcibusmap wr=%d %T mem=%#lux io=%#lux\n",
		wrreg, root->tbdf, mema, ioa);

	ntb = 0;
	for(p = root; p != nil; p = p->link)
		ntb++;

	ntb *= (PciCIS-PciBAR0)/4;
	table = malloc(2*ntb*sizeof(Pcisiz));
	if(table == nil)
		panic("pcibusmap: no memory");

	/*
	 * Build a table of sizes
	 */
	itb = table;
	tptr = mtb = table+ntb;
	pcisizetbl(root, &itb, &mtb, ioa, mema);

	/*
	 * Sort both tables IO smallest first, Memory largest
	 */
	qsort(table, itb-table, sizeof(Pcisiz), pcisizcmp);
	qsort(tptr, mtb-tptr, sizeof(Pcisiz), pcisizcmp);

	/*
	 * Allocate IO port & memory address space on this bus.
	 */
#ifndef NO_IOPORTS
	*pioa = pciallocio(table, itb, ioa, wrreg);
#endif
	*pmema = pciallocmem(table+ntb, mtb, mema, wrreg);
	free(table);

	/*
	 * Finally set all the bridge addresses & registers
	 */
	if(wrreg)
		pcibrgconf(root);
}

static void
pcireadregs(Pcidev *p)
{
	p->pcr = pcicfgr16(p, PciPCR);
	p->rid = pcicfgr8(p, PciRID);
	p->ccrp = pcicfgr8(p, PciCCRp);
	p->ccru = pcicfgr8(p, PciCCRu);
	p->ccrb = pcicfgr8(p, PciCCRb);
	p->cls = pcicfgr8(p, PciCLS);
	p->ltr = pcicfgr8(p, PciLTR);

	p->intl = pcicfgr8(p, PciINTL);
}

enum {
	Badclass,
	Hdt0,
	Hdtother,
};

static int
pciclassify(Pcidev *p, int hdt)
{
	switch(p->ccrb) {
	case Pcibcdisp:
	case Pcibcstore:
	case Pcibcnet:
	case Pcibcmmedia:
	case Pcibccomm:
	case Pcibcbasesys:
	case Pcibcinput:
	case Pcibcdock:
	case Pcibcproc:
	case Pcibcserial:
	case Pcibcwireless:
	case Pcibcintell:
	case Pcibcsatcom:
	case Pcibccrypto:
	case Pcibcdacq:
		if((hdt & ~Hdtmulti) == 0)
			return Hdt0;
		/* fallthrough */
	case Pcibcpci1:
	case Pcibcmem:
	case Pcibcbridge:
	case 255:		/* unassigned (e.g., vmware comms interface) */
		return Hdtother;
	default:
		iprint("pciscan: %T: unknown base class %d (%#ux)\n",
			p->tbdf, p->ccrb, p->ccrb);
		return Badclass;
	}
}

static int
pcidevconf(Pcidev *p, int maxfno)
{
	int i, rno, hdt;

	/*
	 * If the device is a multi-function device adjust the
	 * loop count so all possible functions are checked.
	 */
	hdt = pcicfgr8(p, PciHDT);
	if(hdt & Hdtmulti)
		maxfno = MaxFNO;

	if (p->ccrb == Pcibcdisp)
		pcivga = 1;
	/*
	 * If appropriate, read the base address registers
	 * and work out the sizes.  Also reset bus mastering
	 * and all interrupts.
	 */
	if (pciclassify(p, hdt) == Hdt0) {
		rno = PciBAR0;
		for(i = 0; i < nelem(p->mem); i++) {
			p->mem[i].bar = pcicfgr32(p, rno);
			p->mem[i].size = pcibarsize(p, rno);
			if(p->mem[i].bar && p->mem[i].size) {
				DBG("bar %d (%#lux, %#ux) ", i,
					p->mem[i].bar, p->mem[i].size);
				DBG("%d-bit bar; ",
					((p->mem[i].bar >> Barwidthshift) &
					 Barwidthmask) == Barwidth32? 32: 64);
			}				// TODO
			rno += 4;
		}
		DBG("\n");
		pciclrbme(p);
		pcinointrs(p);
		pcimsioff(nil, p);
	} else {
		DBG("bridge/mem ctlr...");
		DBG("ccrb %d ccru %d...", p->ccrb, p->ccru);
	}
	return maxfno;
}

int	pcilscan(int bno, Pcidev** list);

/*
 * Find PCI-PCI bridges and recursively descend the tree.
 */
static int
pciwalkbrgs(Pcidev *head, int bno, int maxubn)
{
	Pcidev *p;
	int l, sbn, ubn;

	for(p = head; p != nil; p = p->link){
		if(p->ccrb != Pcibcbridge || p->ccru != Pciscbrpci)
			continue;

		/*
		 * If the secondary or subordinate bus number is not
		 * initialised try to do what the PCI BIOS should have
		 * done and fill in the numbers as the tree is descended.
		 * On the way down the subordinate bus number is set to
		 * the maximum as it's not known how many buses are behind
		 * this one; the final value is set on the way back up.
		 */
		sbn = pcicfgr8(p, PciSBN);
		ubn = pcicfgr8(p, PciUBN);
		if(sbn == 0 || ubn == 0 || nobios) {
			sbn = maxubn+1;
			/*
			 * Make sure memory, I/O and master enables are
			 * off, set the primary, secondary and subordinate
			 * bus numbers and clear the secondary status before
			 * attempting to scan the secondary bus.
			 *
			 * Initialisation of the bridge should be done here.
			 */
			pcicfgw32(p, PciPCR, 0xFFFF0000);
			l = (MaxUBN<<16)|(sbn<<8)|bno;
			pcicfgw32(p, PciPBN, l);
			pcicfgw16(p, PciSPSR, 0xFFFF);

			DBG("pbn %d recurse on sbn %d...", bno, sbn);
			maxubn = pcilscan(sbn, &p->bridge);

			DBG("maxubn %d bridge %#p...", maxubn, p->bridge);
			l = (maxubn<<16)|(sbn<<8)|bno;
			pcicfgw32(p, PciPBN, l);
		} else {
			/*
			 * You can't go back.
			 * This shouldn't be possible, but the
			 * Iwill DK8-HTX seems to have subordinate
			 * bus numbers which get smaller on the
			 * way down. Need to look more closely at
			 * this.
			 */
			if(ubn > maxubn)
				maxubn = ubn;
			DBG("recurse on sbn %d...", sbn);
			pcilscan(sbn, &p->bridge);
			DBG("bridge %#p...", p->bridge);
		}
	}
	return maxubn;
}

/*
 * find all pci devices on bus bno and subordinates, initialise them,
 * add to pcilist, and store the head of the list for bno via list.
 * return maximum ubn (subordinate bus number).
 *
 * side effect: if a video controller is seen, set pcivga non-zero.
 */
int
pcilscan(int bno, Pcidev** list)
{
	Pcidev *p, *head, *tail;
	int dno, fno, l, maxfno, maxubn, tbdf;

	maxubn = bno;
	head = tail = nil;
	DBG("pci: scan bus %d...", bno);
	for(dno = 0; dno <= pcimaxdno; dno++)
		for(maxfno = fno = 0; fno <= maxfno; fno++){
			/*
			 * For this possible device, form the
			 * bus+device+function triplet needed to address it
			 * and try to read the vendor and device ID.
			 * If successful, allocate a device struct and
			 * start to fill it in with some useful information
			 * from the device's configuration space.
			 */
			tbdf = MKBUS(BusPCI, bno, dno, fno);
			l = pcicfgrw32(tbdf, PciVID, 0, 1);
			if(l == ~0 || l == 0)
				continue;

			p = malloc(sizeof(*p));
			if(p == nil)
				panic("pcilscan: no memory");
			p->tbdf = tbdf;
			p->vid = l;
			p->did = l>>16;
			DBG("%T %#ux/%#ux...", tbdf, p->vid, p->did);

			if(pcilist != nil)
				pcitail->list = p;
			else
				pcilist = p;
			pcitail = p;

			pcireadregs(p);
			pciiocfirq(p);
			maxfno = pcidevconf(p, maxfno);

			if(head != nil)
				tail->link = p;
			else
				head = p;
			tail = p;
		}

	/*
	 * Find PCI-PCI bridges and recursively descend the tree.
	 */
	*list = head;
	return pciwalkbrgs(head, bno, maxubn);
}

static void
pciladdbuses(Pcidev* p)
{
	Pcidev *t;

	if(p == nil)
		p = pciroot;
	for(t = p; t != nil; t = t->link)
		addabus(BusPCI, BUSBNO(t->tbdf));
	for(; p != nil; p = p->link)
		if(p->bridge != nil)
			pciladdbuses(p->bridge);
}

/*
 * in case MP table doesn't correctly list all buses, add any missing
 * pci buses to mpbus, thus allowing pcimatchtbdf to match devices on
 * the missing buses.  needed for at least the PC Engines APU2C.
 *
 * apu2 adds these:
 *
 * addbus: new bus 0 type 2
 * addbus: new bus 1 type 2
 * addbus: new bus 2 type 2
 * addbus: new bus 3 type 2
 * addbus: new bus 4 type 1
 */
void
pciaddbuses(Pcidev* p)
{
	if(pcicfgmode == -1)
		pcicfginit();
	lock(&pcicfginitlock);
	pciladdbuses(p);
	unlock(&pcicfginitlock);
}

void
pcibussize(Pcidev *root, ulong *msize, ulong *iosize)
{
	*msize = 0;
	*iosize = 0;
	pcibusmap(root, msize, iosize, Read);
}

void
pcireservemem(void)
{
	int i;
	ulong addr;
	Pcibar *bar;
	Pcidev *p;

	/*
	 * mark all the physical address space claimed by pci devices
	 * as in use, so that it's not given out elsewhere.
	 * beware the type and size of 'Pcibar->bar'.
	 */
	for(p=pciroot; p; p=p->list)
		for(i=0; i<nelem(p->mem); i++) {
			bar = &p->mem[i];
			addr = bar->bar;
			if(addr && (addr & Barioaddr) == 0)  /* mem not port? */
				upareserve(addr & Baraddrmask, bar->size);
		}
}

int
pcicfgr8(Pcidev* pcidev, int rno)
{
	return pcicfgrw8(pcidev->tbdf, rno, 0, 1);
}

void
pcicfgw8(Pcidev* pcidev, int rno, int data)
{
	pcicfgrw8(pcidev->tbdf, rno, data, 0);
}

int
pcicfgr16(Pcidev* pcidev, int rno)
{
	return pcicfgrw16(pcidev->tbdf, rno, 0, 1);
}

void
pcicfgw16(Pcidev* pcidev, int rno, int data)
{
	pcicfgrw16(pcidev->tbdf, rno, data, 0);
}

int
pcicfgr32(Pcidev* pcidev, int rno)
{
	return pcicfgrw32(pcidev->tbdf, rno, 0, 1);
}

void
pcicfgw32(Pcidev* pcidev, int rno, int data)
{
	pcicfgrw32(pcidev->tbdf, rno, data, 0);
}

int
pcisetcfgbit(Pcidev *p, int reg, ulong bit, char *onmsg)
{
	ulong bits, obit;

	bits = pcicfgr32(p, reg);
	obit = bits & bit;
	if (obit)
		print(onmsg);
	else
		pcicfgw32(p, reg, bits | bit);
	return obit;
}

int
pciclrcfgbit(Pcidev *p, int reg, ulong bit, char *offmsg)
{
	ulong bits, obit;

	bits = pcicfgr32(p, reg);
	obit = bits & bit;
	if (obit)
		pcicfgw32(p, reg, bits & ~bit);
	else
		print(offmsg);
	return obit;
}

Pcidev*
pcimatch(Pcidev* prev, int vid, int did)
{
	if(pcicfgmode == -1)
		pcicfginit();

	prev = prev == nil? pcilist: prev->list;
	for(; prev != nil; prev = prev->list)
		if((vid == 0 || prev->vid == vid)
		&& (did == 0 || prev->did == did))
			break;
	return prev;
}

Pcidev*
pcimatchtbdf(int tbdf)
{
	Pcidev *pcidev;

	if(pcicfgmode == -1)
		pcicfginit();

	for(pcidev = pcilist; pcidev != nil; pcidev = pcidev->list)
		if(pcidev->tbdf == tbdf)
			break;
	return pcidev;
}

void
pcilhinv(Pcidev* p)
{
	int i;
	Pcidev *t;

	if(p == nil) {
		putstrn(PCICONS.output, PCICONS.ptr);
		p = pciroot;
		print("bus dev type vid  did intl memory\n");
	}
	for(t = p; t != nil; t = t->link) {
		print("%d  %2d/%d %.2ux %.2ux %.2ux %.4ux %.4ux %3d  ",
			BUSBNO(t->tbdf), BUSDNO(t->tbdf), BUSFNO(t->tbdf),
			t->ccrb, t->ccru, t->ccrp, t->vid, t->did, t->intl);

		for(i = 0; i < nelem(p->mem); i++)
			if(t->mem[i].size != 0)
				print("%d:%.8lux %d ", i,
					t->mem[i].bar, t->mem[i].size);
		if(t->ioa.bar || t->ioa.size)
			print("ioa:%.8lux %d ", t->ioa.bar, t->ioa.size);
		if(t->mema.bar || t->mema.size)
			print("mema:%.8lux %d ", t->mema.bar, t->mema.size);
		if(t->bridge)
			print("->%d", BUSBNO(t->bridge->tbdf));
		print("\n");
	}
	for(; p != nil; p = p->link)
		if(p->bridge != nil)
			pcilhinv(p->bridge);
}

void
pcihinv(Pcidev* p)
{
	if(pcicfgmode == -1)
		pcicfginit();
	lock(&pcicfginitlock);
	pcilhinv(p);
	unlock(&pcicfginitlock);
}


void
pcireset(void)
{
	Pcidev *p;

	DBG("pcireset...");
	if(pcicfgmode < 0)
		pcicfginit();
	if(pcicfgmode < 0)
		return;

	for(p = pcilist; p != nil; p = p->list)
		if(p->ccrb != Pcibcbridge) { /* don't mess with the bridges */
			pciclrbme(p);
			pcinointrs(p);
			pcimsioff(nil, p);
		}
	latecheckhype();
}

void
pcisetioe(Pcidev* p)
{
	p->pcr |= IOen;
	pcicfgw16(p, PciPCR, p->pcr);
}

void
pciclrioe(Pcidev* p)
{
	p->pcr &= ~IOen;
	pcicfgw16(p, PciPCR, p->pcr);
}

void
pcisetbme(Pcidev* p)
{
	p->pcr |= MASen;
	pcicfgw16(p, PciPCR, p->pcr);
}

void
pciclrbme(Pcidev* p)
{
	p->pcr &= ~MASen;
	pcicfgw16(p, PciPCR, p->pcr);
}

void
pcisetmwi(Pcidev* p)
{
	p->pcr |= MemWrInv;
	pcicfgw16(p, PciPCR, p->pcr);
}

void
pciclrmwi(Pcidev* p)
{
	p->pcr &= ~MemWrInv;
	pcicfgw16(p, PciPCR, p->pcr);
}

/* return offset in config space for cap; -1 if not found */
static int
pcigetcap(Pcidev* p, int cap)
{
	int ptr;

	if(!(pcicfgr16(p, PciPSR) & Pcicap))	/* no capabilities? */
		return -1;
	/*
	 * Find the capabilities pointer based on PCI header type.
	 */
	switch(pcicfgr8(p, PciHDT) & ~Hdtmulti){
	default:
		return -1;
	case 0:					/* standard */
	case 1:					/* PCI to PCI bridge */
		ptr = PciCP;
		break;
	case 2:					/* CardBus bridge */
		ptr = 0x14;
		break;
	}
	for (ptr = pcicfgr32(p, ptr); ptr != 0; ptr = pcicfgr8(p, ptr+1))
		/*
		 * Check for validity.
		 * Can't be in standard header and must be double-word aligned.
		 */
		if(pcicfgptrbad(ptr))
			break;
		else if(pcicfgr8(p, ptr) == cap)
			return ptr;
	return -1;
}

static int
pcigetpmrb(Pcidev* p)
{
	if(p->pmrb == 0)
		p->pmrb = pcigetcap(p, Pcicappwr);
	return p->pmrb;
}

/*
 * Power Management Register Block:
 *  offset 0:	Capability ID
 *	   1:	next item pointer
 *	   2:	capabilities (short, PMC)
 *	   4:	control/status (short, PMCSR)
 *	   6:	bridge support extensions
 *	   7:	data
 */

enum {
	Pmc	= 2,
	Pmcsr	= 4,

	Haved1	= 1<<9,			/* in pmc */
	Haved2  = 1<<10,

	Pwrstate = MASK(2),		/* in Pmcsr, power state bits: D0-D3 */
	Pme_en	= 1<<8,
};
int
pcigetpms(Pcidev* p)
{
	int ptr;

	if((ptr = pcigetpmrb(p)) == -1)
		return -1;
	return pcicfgr16(p, ptr+Pmcsr) & Pwrstate; /* power state bits: D0-D3 */
}

int
pcisetpms(Pcidev* p, int state)
{
	int ostate, pmc, ptr;
	ushort pmcsr;

	if((ptr = pcigetpmrb(p)) == -1)
		return -1;

	pmc = pcicfgr16(p, ptr+Pmc);
	pmcsr = pcicfgr16(p, ptr+Pmcsr);
	ostate = pmcsr & Pwrstate;
	pmcsr &= ~Pwrstate;

	switch(state){
	default:
		return -1;
	case 0:
		pmcsr &= ~Pme_en;
		break;
	case 1:
		if(!(pmc & Haved1))
			return -1;
		break;
	case 2:
		if(!(pmc & Haved2))
			return -1;
		break;
	case 3:
		break;
	}
	pmcsr |= state;
	pcicfgw16(p, ptr+Pmcsr, pmcsr);

	return ostate;
}

static int
pcigetmsicap(Pcidev* p)
{
	if(p->msiptr == 0)
		p->msiptr = pcigetcap(p, Pcicapmsi);
	return p->msiptr;
}

int
pcigetmsi(Pcidev *p, Msi *msi)
{
	int ptr;

	if((ptr = pcigetmsicap(p)) == -1)
		return -1;
	msi->ctl = pcicfgr16(p, ptr+2);
	msi->addr = pcicfgr32(p, ptr+4);
	if (msi->ctl & Msiaddr64) {
		msi->addr |= (uvlong)pcicfgr32(p, ptr+8) << 32;
		msi->data = pcicfgr16(p, ptr+0xc);
	} else
		msi->data = pcicfgr16(p, ptr+8);
	return 0;
}

int
pcisetmsi(Pcidev *p, Msi *msi)
{
	int ptr;

	if((ptr = pcigetmsicap(p)) == -1)
		return -1;

	if (msi->ctl & Msienable)
		p->pcr |= IntrDis;  /* no legacy interrupts allowed with msi */
	else
		p->pcr &= ~IntrDis;
	pcicfgw16(p, PciPCR, p->pcr);

	pcicfgw32(p, ptr+4, msi->addr);
	if (msi->ctl & Msiaddr64) {
		pcicfgw32(p, ptr+8, msi->addr>>32);
		pcicfgw16(p, ptr+0xc, msi->data);
	} else
		pcicfgw16(p, ptr+8, msi->data);
	pcicfgw16(p, ptr+2, msi->ctl);		/* write ctl last */
	return 0;
}

int
pcigetmsixcap(Pcidev* p)
{
	if(p->msixptr == 0)
		p->msixptr = pcigetcap(p, Pcicapmsix);
	return p->msixptr;
}

int
pcigetpciecap(Pcidev* p)
{
	if(p->pcieptr == 0)
		p->pcieptr = pcigetcap(p, Pcicappcie);
	return p->pcieptr;
}

void
pcinointrs(Pcidev *p)
{
	p->pcr |= IntrDis;
	pcicfgw16(p, PciPCR, p->pcr);
}

void
pciintrs(Pcidev *p)
{
	p->pcr &= ~IntrDis;
	pcicfgw16(p, PciPCR, p->pcr);
}
