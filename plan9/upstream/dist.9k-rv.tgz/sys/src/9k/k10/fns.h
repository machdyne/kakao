#include "../port/portfns.h"

void	aamloop(int);
//int	acpiinit(void);
void	addabus(int type, int bno);
Dirtab*	addarchfile(char*, int, long(*)(Chan*,void*,long,vlong), long(*)(Chan*,void*,long,vlong));
void	apicinitipi(int apicno);
int	apicavail(Apic *apic);
void	apueccon(void);
void	archfmtinstall(void);
vlong	archhz(void);
void	archinit(void);
int	archmmu(void);
void	archreset(void);
uvlong	asmalloc(uvlong, uvlong, int, int);
int	asmfree(uvlong, uvlong, int);
void	asminit(void);
void	asmmapinit(uvlong, uvlong, int);
void	asmmodinit(ulong, ulong, char*);
int	bsr(Clzuint n);
void	cgaconsputs(char*, int);
void	cgapost(int);
void	checkhype(void);
void	(*coherence)(void);
#define CONSREGS()	uart0regs
int	corecolor(int);
ulong	cpuid(ulong, ulong, ulong[Ncpuidregs]);
void	cpuidcaps(void);
int	cpuidinfo(ulong eax, ulong ecx, ulong info[Ncpuidregs]);
#define	cycles(t) (*(t) = rdtsc())
#define delay(ms) millidelay(ms)
int	etherfmt(Fmt* fmt);
#define	evenaddr(x)				/* x86 doesn't care */
int	fpudevprocio(Proc*, void*, long, uintptr, int);
void	fpuinit(void);
void	fpunoted(void);
void	fpunotify(Ureg*);
void	fpuprocrestore(Proc*);
void	fpuprocsave(Proc*);
void	fpusysprocsetup(Proc*);
void	fpusysrfork(Ureg*);
void	fpusysrforkchild(Proc*, Proc*);
char*	getconf(char*);
void	halt(void);
char*	hypername(void);
#ifdef PS2MOUSE
int	i8042auxcmd(int);
int	i8042auxcmds(uchar*, int);
void	i8042auxenable(void (*)(int, int));
void	i8042reset(void);
#else
#define i8042auxcmd(cmd)
#define i8042auxcmds(s, cmd)
#define i8042auxenable(func)
#endif
void*	i8250alloc(int, int, int);
Uart*	i8250console(char*);
vlong	i8254hz(ulong[2][4]);
void	i8254set(int port, int hz);
void	idlehands(void);
void	(*idlehandsfn)(void);
void	idthandlers(void);
int	inb(int);
ulong	inl(int);
ushort	ins(int);
#ifdef SDATA
void	inss(int, void*, int);
#endif
int	intrdisable(void*);
void*	intrenable(int, Intrsvcret (*)(Ureg*, void*), void*, int, char*);
void	invlpg(uintptr);
int	ioalloc(int, int, int, char*);
void	pickintrcpu(ulong* hi, ulong* lo, Vctl *v);
void	iofree(int);
void	ioinit(void);
int	iounused(int, int);
int	iprint(char*, ...);
int	isaconfig(char*, int, ISAConf*);
int	isapu(void);
int	k10waitfor(long*, int);
void	kbdenable(void);
void	kbdinit(void);
void	kexit(Ureg*);
#define	kmapinval()
void	kmesginit(void);
void	lapicintroff(void);
void	lapicintron(void);
void	lapicnmidisable(void);
void	lapicnmienable(void);
void	latecheckhype(void);
void	links(void);
int	memcolor(uintmem, uintmem*);
void	meminit(void);
void	mfence(void);
void	mmuflushtlb(uvlong);
void	mmuidentitymap(void);
void	mmuinit(void);
uvlong	mmuphysaddr(uintptr);
int	mmuwalk(uintptr, int, PTE**, uvlong (*)(uintptr));
void	monitor(void* address, ulong extensions, ulong hints);
void	mpshutdown(void);
int	msinordt(Vctl *v, Pcidev *pcidev, ulong *hip, ulong *lop, int vecno);
int	multiboot(ulong, ulong, int);
void	mwait(ulong extensions, ulong hints);
void	ndnr(void);
void	nmienable(void);
int	notify(Ureg*);
uchar	nvramread(int);
void	nvramwrite(int, uchar);
void	mboptinit(char*);
void	outb(int, int);
void	outl(int, ulong);
void	outs(int, ushort);
#ifdef SDATA
void	outss(int, void*, int);
#endif
void	pause(void);
void	pciaddbuses(Pcidev*);
ulong	pcibarsize(Pcidev*, int);
void	pcibusmap(Pcidev *root, ulong *pmema, ulong *pioa, int wrreg);
void	pcibussize(Pcidev*, ulong*, ulong*);
void	pcicf9reset(void);
void	pcicfginit(void);
int	pcicfgr16(Pcidev*, int);
int	pcicfgr32(Pcidev*, int);
int	pcicfgr8(Pcidev*, int);
int	pcicfgrw16(int, int, int, int);
int	pcicfgrw32(int, int, int, int);
int	pcicfgrw8(int, int, int, int);
void	pcicfgw16(Pcidev*, int, int);
void	pcicfgw32(Pcidev*, int, int);
void	pcicfgw8(Pcidev*, int, int);
void	pciclrbme(Pcidev*);
int	pciclrcfgbit(Pcidev *p, int reg, ulong bit, char *offmsg);
void	pciclrioe(Pcidev*);
void	pciclrmwi(Pcidev*);
int	pcigetmsi(Pcidev *p, Msi *msi);
int	pcigetmsixcap(Pcidev *p);
int	pcigetpciecap(Pcidev *p);
int	pcigetpms(Pcidev*);
void	pcihinv(Pcidev*);
void	pciintrs(Pcidev*);
uchar	pciipin(Pcidev*, uchar);
void	pcilhinv(Pcidev* p);
int	pcilog(char *fmt, ...);
int	pcilscan(int bno, Pcidev** list);
ulong	pcimask(ulong v);
Pcidev*	pcimatch(Pcidev*, int, int);
Pcidev* pcimatch(Pcidev*, int, int);
Pcidev*	pcimatchtbdf(int);
Pcidev* pcimatchtbdf(int);
void	pcimsioff(Vctl*, Pcidev*);
void	pcinointrs(Pcidev*);
void	pciiocfirq(Pcidev *p);
void	pcireservemem(void);
void	pcireset(void);
void	pcirouting(void);
int	pciscan(int, Pcidev**);
void	pcisetbme(Pcidev*);
int	pcisetcfgbit(Pcidev *p, int reg, ulong bit, char *onmsg);
void	pcisetioe(Pcidev*);
int	pcisetmsi(Pcidev *p, Msi *msi);
void	pcisetmwi(Pcidev*);
int	pcisetpms(Pcidev*, int);
int	pciusebios(void);		/* in optional pcibios.c */
/*
 *  performance measurement ticks.  must be low overhead.
 *  doesn't have to count over a second.
 */
#define	perfticks() ((ulong)rdtsc())
void	(*pmcupdate)(void);
void	popcpu0sipi(Sipireboot *, Sipi *, void *, void *, void *, int);
void	runoncpu(int cpu);
uvlong	sampletimer(int tmrport, int *cntp);
void	screeninit(void);
int	screenprint(char*, ...);			/* debugging */
void	(*screenputs)(char*, int);
void	setsipihandler(uintmem);
void*	sigsearch(char* signature);
void*	sysexecregs(uintptr, ulong, ulong);
uintptr	sysexecstack(uintptr, int);
void	sysprocsetup(Proc*);
int	tbdffmt(Fmt* fmt);
void	trapenable(int, Intrsvcret (*)(Ureg*, void*), void*, char*);
void	trapinit(void);
void	trapreturn(Ureg*);
void	tssrsp0(uvlong);
int	userureg(Ureg*);
void*	vmap(uintmem, uintptr);
void	vmbotch(ulong, char *);
void	vsvminit(int);
void	vunmap(void*, uintptr);
int	(*waitfor)(long*, int);
void	wbinvd(void);
void	writeconf(void);
void *	zero(void *vaddr, uintptr len);

extern Mreg cr0get(void);
extern void cr0put(Mreg);
extern Mreg cr2get(void);
extern Mreg cr3get(void);
extern void cr3put(Mreg);
extern Mreg cr4get(void);
extern void cr4put(Mreg);
extern void gdtget(void*);
extern void gdtput(int, uvlong, ushort);
extern void idtput(int, uvlong);
extern uvlong rdmsr(ulong);
extern uvlong rdtsc(void);
extern void trput(uvlong);
extern void wrmsr(ulong, uvlong);

/* libc atomics */
int	cas(uint*, int, int);
int	casv(uvlong*, uvlong, uvlong);
int	casp(void**, void*, void*);
ulong	loadlinked(ulong *addr);
int	storecond(ulong *addr, ulong val);

void	touser(uintptr);
void	syscallentry(void);
void	syscallreturn(void);
void	sysrforkret(void);

#define	waserror()	(up->nerrlab++, setlabel(&up->errlab[up->nerrlab-1]))

#define PTR2UINT(p)	((uintptr)(p))
#define UINT2PTR(i)	((void*)(i))

void*	KADDR(uintptr);
uintptr	PADDR(void*);

#define BIOSSEG(a)	KADDR(((uint)(a))<<4)

/*
 * apic.c
 */
extern int apiceoi(int);
extern void apicinit(int, uintptr, int);
extern int apicisr(int);
extern int apiconline(void);
extern void apicresetothers(void);
extern void apicsipi(int, uintptr);
extern void apictimerdisable(void);
extern void apictimerenable(void);
extern Intrsvcret apictimerintr(Ureg*, void*);
extern void apictprput(int);

extern void ioapicinit(int, uintmem);
extern int  ioapicintrinit(int, int, int, int, ulong);
extern int  ioapicintrtbloff(uint vno);
extern void ioapiconline(void);

/*
 * archk10.c
 */
extern void millidelay(int);

/*
 * i8259.c
 */
extern int i8259init(int);
extern int i8259irqdisable(int);
extern int i8259isr(int);

/*
 * mp.c
 */
extern void mpsinit(void);

/*
 * sipi.c
 */
extern void sipi(void);
