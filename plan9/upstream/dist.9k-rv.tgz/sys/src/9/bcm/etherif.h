/* ethernet interface */
enum {
	Eaddrlen	= 6,
	ETHERMINTU	= 60,		/* minimum transmit size */
	ETHERMAXTU	= 1514,		/* maximum transmit size (no crc) */
	ETHERHDRSIZE	= 14,		/* size of an ethernet header */
	/* wifi (802.11) maxtu is 2304 (2346 including hdr+crc) */

	/*
	 * max. models of ether cards registered by addethercard & interfaces.
	 */
	MaxEther= 64,	/* igbe has many aliases */
	Ntypes	= 8,	/* max. ether types *and* wireless base stations seen */
};

typedef struct Ether Ether;
struct Ether {
	void	*ctlr;
	Intrcommon;
	ISAConf;			/* hardware info */

	ulong	tbdf;			/* type+busno+devno+funcno */
	char	ctlrno;
	uchar	phyaddr;		/* 9k only so far */
	uchar	ea[Eaddrlen];
	uchar	attached;

	void	(*attach)(Ether*);	/* filled in by reset routine */
	void	(*detach)(Ether*);	/* nothing actually calls this */
	void	(*transmit)(Ether*);
	Intrsvcret (*interrupt)(Ureg*, void*);
	long	(*ifstat)(Ether*, void*, long, ulong);
	long 	(*ctl)(Ether*, void*, long); /* custom ctl messages */
	void	(*power)(Ether*, int);	/* power on/off */
	void	(*shutdown)(Ether*);	/* shutdown hardware before reboot */

	Netif;				/* contains iqs and oq */

	int	nscan;		/* # of wireless base station scanners */
	int	scan[Ntypes];	/* base station scanning interval */
};

typedef struct Ethident Ethident;
struct Ethident {		/* must be first member of Ctlr, if present */
	union {
		uint	*regs;	/* memory-mapped device registers */
		void	*vregs;
	};
	Ether	*edev;
	int	type;
	char	*prtype;
	uint	*physreg;	/* regs's phys addr, for discovery & printing */
};

/* this is a packet layout */
typedef struct Etherpkt Etherpkt;
struct Etherpkt
{
	uchar	d[Eaddrlen];
	uchar	s[Eaddrlen];
	uchar	type[2];
	uchar	data[1500];
};

typedef struct Ctlr Ctlr;

/*
 * we steal %Æ for ethernet Ctlrs with Ethident as their first members.
 */
#pragma varargck type "Æ" Ctlr*

extern Block* etheriq(Ether*, Block*, int);
extern void addethercard(char*, int(*)(Ether*));
extern ulong ethercrc(uchar*, int);
extern int parseether(uchar*, char*);

#define NEXT(x, l)	(((x)+1)%(l))
#define PREV(x, l)	(((x) == 0) ? (l)-1: (x)-1)
