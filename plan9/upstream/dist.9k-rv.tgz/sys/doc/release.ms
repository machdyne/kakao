.HTML "Plan 9 — Release Notes
.TL
Plan 9 From Bell Labs
.br
Release Notes
.br
August 2026
.AU
Geoff Collyer
.LP
.sp -.4i
.nf
.ce 1000
Copyright © 2021\-2026 Plan 9 Foundation
All Rights Reserved
.sp .2i
.fi
.
.de Xx
.br
.ne 4
.LP
\(bu
..
.
.LP
This release of the Plan 9 operating system
contains many improvements and additions to the system
since the long-ago Fourth Edition release of 2002 from Bell Labs.
We now assume 21st-century hardware.
.Xx
.I fossil (4)
and
.I venti (8)
are now the production file server and block store, respectively,
and better documented.
.I Venti
has been greatly improved internally
and there is a new
.I libventi ,
which
.I fossil
now uses.
Note that
.I fossil
is currently only safe up to 32TB
due to use of 32-bit integers to hold block numbers,
as are
.I venti
index sections.
.I kfs (4)
and
.I lnfs (4)
are deprecated and
the old standalone file server
and the IL protocol are gone.
.I cwfs (4)
provides the function of the old file server as a user-mode program,
plus the ability to communicate via TCP or other non-IL/IPv4 protocols.
.
.\" booting
.
.Xx
Network booting of PCs via PXE is routine.
The smaller PC kernels
.I 9pc "" (
and
.I 9pccpu )
can now be loaded without loading
.I 9boot (8)
first.
Better compression with
.I lzip
(see
.I gzip (1))
and dynamic loading of missing
.CW /boot
executables by
.I boot (8)
allow kernels to be still smaller.
Other machines normally boot via BOOTP/DHCP and TFTP without PXE as such.
.Xx
The PC bootstrap programs are now variants of the PC kernel,
and use unmodified kernel device drivers, so they can load
from any supported device.
.
.\" kernels
.
.Xx
Multiprocessor machines no longer loop waiting for work when idle.
They now use mechanisms such as
.CW WFI ,
.CW MWAIT
instructions
and inter-processor interrupts to go into an idle state until
an interrupt or runnable processes become available.
This conserves power and heat, which helps avoid overheating.
.Xx
ARM machines such as the Raspberry Pis
are supported, including multi-core machines.
Floating point emulation includes VFP instructions in addition
to the old 7500 FPA instructions, so it should be easy to make
.CW 5l
.CW -f
the default.
.\" One MIPS machine, the Mikrotik Routerboard 450G, is supported,
.\" though the architecture has been disavowed by MIPS in favour of RISC-V.
.Xx
.I "64-bit kernels."
We are also distributing a 64-bit-capable kernel,
.CW /sys/src/9k ,
which has two ports, to the 64-bit
.CW amd64
and
.CW riscv64
architectures,
intended for use as a cpu server
or file server
.CW riscv64 ) (
or Vesa VGA terminal.
The late Jim McKie
.I jmk ) (
created
.CW 9k
from our 32-bit kernel.
It implements the same system calls, and drives some of the same devices,
with an emphasis on PCI-Express devices.
.Xx
The
.CW riscv64
port currently runs on the Microchip Polarfire Icicle,
pre-release Beagle V,
and several SiFive and Milk-V machines.
Richard Miller contributed the RISC-V compiler suites.
.Xx
The
.CW 9
and
.CW 9k
kernels have diverged somewhat, but we are attemping to minimise
source differences.
In particular, the
.CW boot
and
.CW ip
directories are shared between
.CW 9
and
.CW 9k ,
but some device drivers differ slightly between the two kernels.
ACPI is almost entirely ignored and use of MSI avoids most BIOS table
(e.g., MPS) bugs.
Note that the
.I malloc (2),
.I pool (2)
and
.I qmalloc
allocators and
.I memset
now use
.I uintptr
variables internally and in their interfaces,
and so can cope with 64-bit addresses,
permitting allocating huge tracts of memory.
.Xx
Restarting the system without a hardware reset works well;
see
.I fshalt (8).
.
.\" compilers
.
.Xx
Compilers exist for AMD64, ARM64, 32-bit and 64-bit RISC-V,
and 64-bit PowerPC processors.
The ARM compiler can now profile programs and generate ELF executables.
The MIPS loader can emit ELF64 executables.
The DEC Alpha, Sun/Oracle SPARC, and Motorola 68000 and 68020
architectures have been retired.
MIPS and SPARC have been disavowed by their owners.
.
.\" devices
.
.Xx
The PC port now assumes Pentium (1993) or newer processor(s).
386 and 486 code remains for reference, but will decay away.
Multiprocessors are also the norm now, rather than an exotic architecture.
Only ISA, PCI and PCI-Express buses are still supported;
PCMCIA and all subsequent variants are no longer supported.
.Xx
PCI message-signalled interrupts (MSI) are implemented on the PC,
which can be particularly helpful when the PC BIOS (MPS or ACPI)
tables are wrong, by bypassing most of the normal interrupt nonsense.
.Xx
Some 10 Gb/s Ethernet adapters are supported, mainly Intel ones,
notably the X540 and X550 which run 10GBASE-T over Category 6a copper cables.
Note that these cards run hot and will shut down if they overheat,
so dual-port cards such as the X540-T2 are not
necessarily a better deal than single-port cards.
.Xx
Support for PCI-E Intel Gigabit Ethernet adapters includes the i21[0189].
The i217 stubbornly refuses to transmit.
.Xx
USB support has improved and includes USB 2 (EHCI).
There are drivers for USB Ethernet dongles and the like;
see
.I usb (3)
and
.I usb (4);
performance will be bad.
USB 3 (XHCI) controllers can be recognised and disabled
to reduce their interrupt load.
.Xx
There is native support for SATA devices
(with block addresses up to 48 bits wide)
via AHCI,
and for NVMe solid-state disks.
.Xx
.I Cdfs (4)
provides access to data (not audio nor video)
on DVDs and Blu-ray discs.
.Xx
VESA video on PCs works fairly reliably, even on multiprocessors.
.Xx
ATA-over-Ethernet is supported;
see
.I aoe (3).
iSCSI is also supported.
.
.\" misc
.
.Xx
IPv6 support is better and includes tunnelling through IPv4 to reach
the wider IPv6 internet;
see
.I 6in4 (8).
Hanging bugs in ICMPv6, found through native IPv6 use, have been fixed, and
.I dial (2)
dials all addresses (v4 and v6) concurrently until it connects.
.
.Xx
The cryptographic infrastructure is being updated.
SHA2 is available; see
.I sechash (2).
Use of RC4 and SSLv2 are being deprecated but will take a while to eliminate
due to the need for backward compatibility.
In particular,
.I secstore (1)
and
.I factotum (4)
have use of SSLv2 hard-wired into their protocols.
.I ssh1 (1)
no longer uses RC4.
.I ssh2 (1)
works but needs more new algorithms
for compatibility with the rest of the world.
.I tls (2)
and
.I tls (3)
can cope with SSLv3 and TLS 1.[0-2].
.I cpu (1)
and
.I drawterm (8)
attempt TLS connections and may fall back to SSLv2.
.I import (1)
and
.I exportfs (8)
implement TLS encryption.
.I import
used to default to no encryption,
but now defaults to trying TLS, SSLv2 and then clear text,
with a warning if TLS can't be used.
Note that currently clear-text imports must be used if it is necessary to
mount an imported
.I srv (3)
channel;
this is being investigated.
.Xx
Related to the cryptographic upgrade,
support for 9P1 (the original Plan 9 file protocol) is being dropped;
everything should be converted to 9P2000 by now.
.Xx
Unicode Runes are 21 bits wide and UTF sequences may be 4 bytes long.
.Xx
.I ndb/dns
has been extended and improved in various ways but
its UDP server still has hard-to-find memory leaks and eventually corruption.
We can only recommend dedicating machines to act as UDP nameservers and
rebooting them frequently.
Third-party DNS secondaries can also relieve the load.
.
.Xx
.I Regfree
(see
.I regexp (2))
exists and should be used instead of
.I free
to free compiled regular expressions.
.LP
The Plan 9 Wiki
.CW http://plan9foundation.org/wiki/plan9 ) (
is the place to visit to learn more and stay current.
The Usenet group
.CW comp.os.plan9 ) (
used to a good place to visit,
but it has degenerated.
.LP
Good Luck!
