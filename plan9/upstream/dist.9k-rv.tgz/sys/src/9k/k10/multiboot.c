/*
 * process inbound multiboot table, including memory map and options.
 */
#include "u.h"
#include "../port/lib.h"
#include "mem.h"
#include "dat.h"
#include "fns.h"

typedef struct Mbi Mbi;
struct Mbi {
	ulong	flags;
	ulong	memlower;
	ulong	memupper;
	ulong	bootdevice;
	ulong	cmdline;
	ulong	modscount;
	ulong	modsaddr;
	ulong	syms[4];
	ulong	mmaplength;
	ulong	mmapaddr;
	ulong	driveslength;
	ulong	drivesaddr;
	ulong	configtable;
	ulong	bootloadername;
	ulong	apmtable;
	ulong	vbe[6];
};

enum {						/* flags */
	Fmem		= 0x0001,		/* mem* valid */
	Fbootdevice	= 0x0002,		/* bootdevice valid */
	Fcmdline	= 0x0004,		/* cmdline valid */
	Fmods		= 0x0008,		/* mod* valid */
	Fsyms		= 0x0010,		/* syms[] has a.out info */
	Felf		= 0x0020,		/* syms[] has ELF info */
	Fmmap		= 0x0040,		/* mmap* valid */
	Fdrives		= 0x0080,		/* drives* valid */
	Fconfigtable	= 0x0100,		/* configtable* valid */
	Fbootloadername	= 0x0200,		/* bootloadername* valid */
	Fapmtable	= 0x0400,		/* apmtable* valid */
	Fvbe		= 0x0800,		/* vbe[] valid */
};

typedef struct Mod Mod;
struct Mod {
	ulong	modstart;
	ulong	modend;
	ulong	string;
	ulong	reserved;
};

typedef struct MMap MMap;
struct MMap {
	ulong	size;
	ulong	base[2];
	ulong	length[2];
	ulong	type;
};

static void
rdmbimmap(Mbi *mbi, int vflag)
{
	int n;
	char *type;
	MMap *mmap;
	uvlong addr, len;

	for (n = 0; n < mbi->mmaplength; n += mmap->size + sizeof(mmap->size)){
		mmap = KADDR(mbi->mmapaddr + n);
		addr = (((uvlong)mmap->base[1]) <<32) | mmap->base[0];
		len = (((uvlong)mmap->length[1])<<32) | mmap->length[0];
		if (vflag) {
			type = "unknown";
			if (mmap->type < nelem(asmtypes))
				type = asmtypes[mmap->type];
			DBG("%#10.10llux %#10.10llux %15,llud %s\n",
				addr, addr+len, len, type);
			USED(type);
		} else
			switch(mmap->type){
			case AsmMEMORY:
			case AsmRESERVED:
			case AsmACPIRECLAIM:
			case AsmACPINVS:
				asmmapinit(addr, len, mmap->type);
				break;
			}
	}
	/* pmoccupied is amount, not address */
	if (sys->pmoccupied > sys->pmend) {	/* sanity cap */
		print("pmoccupied %#p > pmend %#p\n",
			sys->pmoccupied, sys->pmend);
		sys->pmoccupied = sys->pmend;
	}
}

/* if vflag, print what would be done, but don't do it. */
int
multiboot(ulong magic, ulong pmbi, int vflag)
{
	char *p;
	int i;
	Mbi *mbi;
	Mod *mod;

	DBG("magic %#lux pmbi %#lux\n", magic, pmbi);
	if(magic != MBOOTREGMAG || pmbi == 0)
		return -1;

	mbi = KADDR(pmbi);
	DBG("flags %#lux\n", mbi->flags);
	if(mbi->flags & Fcmdline){
		p = KADDR(mbi->cmdline);
		if(vflag)
			DBG("cmdline <%s>\n", p);
		else
			mboptinit(p);
	}
	if(mbi->flags & Fmods)
		for(i = 0; i < mbi->modscount; i++){
			mod = KADDR(mbi->modsaddr + i*16);
			p = (mod->string != 0? KADDR(mod->string): "");
			if(vflag)
				DBG("mod %#lux %#lux <%s>\n",
					mod->modstart, mod->modend, p);
			else
				asmmodinit(mod->modstart, mod->modend, p);
		}
	if(mbi->flags & Fmmap)
		rdmbimmap(mbi, vflag);
	if(vflag && mbi->flags & Fbootloadername)
		DBG("bootloadername <%s>\n", KADDR(mbi->bootloadername));
	return 0;
}
