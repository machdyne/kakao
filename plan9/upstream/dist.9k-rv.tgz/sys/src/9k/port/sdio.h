/*
 * mmc/sd/sdio host controller interface, 9k version.
 * not `sd' as in `storage device' (devsd).
 */
struct SDio {
	char	*name;
	int	(*init)(void);
	void	(*enable)(void);

	/* first args are unit->subno */
	int	(*inquiry)(int, char*, int);
	int	(*cmd)(int, ulong, ulong, ulong*);
	void	(*iosetup)(int, int, void*, int, int);
	void	(*io)(int, int, uchar*, int);

	void	(*disable)(void);		/* used by 9/port/sdmmc.c */
	int	(*cardintr)(int, int);		/* used by 9k/rv/sdpf.c */
};
