/* non-EFI memory map via bios call */
static int
ise820biosmap(uchar *p)		/* p points at MMap->size */
{
	return memcmp(p, "APM\0", 4) == 0 || memcmp(p, "MAP\0", 4) == 0;
}

uintptr
finde820map(void)
{
	uchar *p;
	static char e820map[] = "e820 memory map";

	p = (uchar *)BIOSTABLES;
	if(ise820biosmap(p)){
		print("%s present\n", e820map);
		return (uintptr)p;
	}
	p += 0x10;		/* compatible with some old bootstraps */
	if(ise820biosmap(p)){
		print("%s at old-style address %#p\n", e820map, p);
		return (uintptr)p;
	}
	print("no %s; wtf?\n", e820map);
	return 0;
}

/* populates mmap from e820 map */
void
readlsconf(uintptr e820)
{
	int n;
	uchar *p;
	MMap *map, *nmap;
	uvlong addr, len;

	p = (uchar*)e820;
	for(n = 0; n < nelem(mmap) && *p != 0; n++)
		if(memcmp(p, "APM\0", 4) == 0)
			p += 20;			/* ignore APM */
		else if(memcmp(p, "MAP\0", 4) == 0){
			/* translate e820 MMap with .size="MAP\0" to mmap[] */
			map = (MMap*)p;
			switch(map->type){
			default:
				DBG("type %ud", map->type);
				break;
			case 1:
				DBG("Memory");
				break;
			case 2:
				DBG("reserved");
				break;
			case 3:
				DBG("ACPI Reclaim Memory");
				break;
			case 4:
				DBG("ACPI NVS Memory");
				break;
			}
			addr = map->base;
			len = map->len;
			DBG("\t%#16.16lluX %#16.16lluX (%llud)\n",
					addr, addr+len, len);

			if(nmmap < nelem(mmap)){
				nmap = &mmap[nmmap++];
				memmove(nmap, map, sizeof *map);
				nmap->size = sizeof(MMap) - sizeof map->size;
			}
			p += sizeof(MMap);
		} else				/* not a table from bios.s */
			break;
}
