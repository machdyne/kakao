/*
 * x86 southbridge support and PCI config space access via i/o ports
 */
#include "u.h"
#include "../port/lib.h"
#include "mem.h"
#include "dat.h"
#include "fns.h"
#include "io.h"
#include "mp.h"

#pragma	varargck	type	"T"	int

enum
{					/* configuration mechanism #1 */
	PciADDR		= 0xCF8,	/* CONFIG_ADDRESS I/O port */
	PciDATA		= 0xCFC,	/* CONFIG_DATA I/O port */
};

Lock pcicfglock;
Lock pcicfginitlock;
int pcicfgmode;
int pcimaxbno;
int pcimaxdno;
int pcivga;

int nobios = 0;
int nopcirouting;

Pcidev* pciroot;
Pcidev* pcilist;
Pcidev* pcitail;

static ulong
mkaddr(int tbdf, uint rno, int type)
{
	if (rno >= (1<<12)) {
		print("pci reg %#ux of %T is out of range; sorry.\n", rno, tbdf);
		return -1;
	}
	/* the extra 4 bits of rno only work on some amd systems */
	return 1ul<<31 | (rno & (MASK(4)<<8))<<16 | BUSBDF(tbdf) |
		(rno & MASK(8) & ~3) | type;
}

int
pcicfgrw8(int tbdf, int rno, int data, int read)
{
	int o, type, x;
	ulong addr;

	if(pcicfgmode == -1)
		pcicfginit();

	x = -1;
	if(BUSDNO(tbdf) > pcimaxdno)
		return x;
	type = BUSBNO(tbdf) != 0;
	addr = mkaddr(tbdf, rno, type);
	if (addr == -1)
		return x;

	lock(&pcicfglock);
	switch(pcicfgmode){
	case 1:
		o = rno & 0x03;
		outl(PciADDR, addr);
		if(read)
			x = inb(PciDATA+o);
		else
			outb(PciDATA+o, data);
		outl(PciADDR, 0);
		break;
	}
	unlock(&pcicfglock);

	return x;
}

int
pcicfgrw16(int tbdf, int rno, int data, int read)
{
	int o, type, x;
	ulong addr;

	if(pcicfgmode == -1)
		pcicfginit();

	x = -1;
	if(BUSDNO(tbdf) > pcimaxdno)
		return x;
	type = BUSBNO(tbdf) != 0;
	addr = mkaddr(tbdf, rno, type);
	if (addr == -1)
		return x;

	lock(&pcicfglock);
	switch(pcicfgmode){
	case 1:
		o = rno & 0x02;
		outl(PciADDR, addr);
		if(read)
			x = ins(PciDATA+o);
		else
			outs(PciDATA+o, data);
		outl(PciADDR, 0);
		break;
	}
	unlock(&pcicfglock);

	return x;
}

int
pcicfgrw32(int tbdf, int rno, int data, int read)
{
	int type, x;
	ulong addr;

	if(pcicfgmode == -1)
		pcicfginit();

	x = -1;
	if(BUSDNO(tbdf) > pcimaxdno)
		return x;
	type = BUSBNO(tbdf) != 0;
	addr = mkaddr(tbdf, rno, type);
	if (addr == -1)
		return x;

	lock(&pcicfglock);
	switch(pcicfgmode){
	case 1:
		outl(PciADDR, addr);
		if(read)
			x = inl(PciDATA);
		else
			outl(PciDATA, data);
		outl(PciADDR, 0);
		break;
	}
	unlock(&pcicfglock);

	return x;
}

/* query and set irqs via various southbridge chip sets */

static uchar
pIIxget(Pcidev *router, uchar link)
{
	uchar pirq;

	/* link should be 0x60, 0x61, 0x62, 0x63 */
	pirq = pcicfgr8(router, link);
	return (pirq < 16)? pirq: 0;
}

static void
pIIxset(Pcidev *router, uchar link, uchar irq)
{
	pcicfgw8(router, link, irq);
}

static uchar
viaget(Pcidev *router, uchar link)
{
	uchar pirq;

	/* link should be 1, 2, 3, 5 */
	pirq = (link < 6)? pcicfgr8(router, 0x55 + (link>>1)): 0;

	return (link & 1)? (pirq >> 4): (pirq & 15);
}

static void
viaset(Pcidev *router, uchar link, uchar irq)
{
	uchar pirq;

	pirq = pcicfgr8(router, 0x55 + (link >> 1));
	pirq &= (link & 1)? 0x0f: 0xf0;
	pirq |= (link & 1)? (irq << 4): (irq & 15);
	pcicfgw8(router, 0x55 + (link>>1), pirq);
}

static uchar
optiget(Pcidev *router, uchar link)
{
	uchar pirq = 0;

	/* link should be 0x02, 0x12, 0x22, 0x32 */
	if ((link & 0xcf) == 0x02)
		pirq = pcicfgr8(router, 0xb8 + (link >> 5));
	return (link & 0x10)? (pirq >> 4): (pirq & 15);
}

static void
optiset(Pcidev *router, uchar link, uchar irq)
{
	uchar pirq;

	pirq = pcicfgr8(router, 0xb8 + (link >> 5));
	pirq &= (link & 0x10)? 0x0f : 0xf0;
	pirq |= (link & 0x10)? (irq << 4): (irq & 15);
	pcicfgw8(router, 0xb8 + (link >> 5), pirq);
}

static uchar
aliget(Pcidev *router, uchar link)
{
	/* No, you're not dreaming */
	static const uchar map[] = { 0, 9, 3, 10, 4, 5, 7, 6, 1, 11, 0, 12, 0, 14, 0, 15 };
	uchar pirq;

	/* link should be 0x01..0x08 */
	pirq = pcicfgr8(router, 0x48 + ((link-1)>>1));
	return (link & 1)? map[pirq&15]: map[pirq>>4];
}

static void
aliset(Pcidev *router, uchar link, uchar irq)
{
	/* Inverse of map in aliget */
	static const uchar map[] = { 0, 8, 0, 2, 4, 5, 7, 6, 0, 1, 3, 9, 11, 0, 13, 15 };
	uchar pirq;

	pirq = pcicfgr8(router, 0x48 + ((link-1)>>1));
	pirq &= (link & 1)? 0x0f: 0xf0;
	pirq |= (link & 1)? (map[irq] << 4): (map[irq] & 15);
	pcicfgw8(router, 0x48 + ((link-1)>>1), pirq);
}

static uchar
cyrixget(Pcidev *router, uchar link)
{
	uchar pirq;

	/* link should be 1, 2, 3, 4 */
	pirq = pcicfgr8(router, 0x5c + ((link-1)>>1));
	return ((link & 1)? pirq >> 4: pirq & 15);
}

static void
cyrixset(Pcidev *router, uchar link, uchar irq)
{
	uchar pirq;

	pirq = pcicfgr8(router, 0x5c + (link>>1));
	pirq &= (link & 1)? 0x0f: 0xf0;
	pirq |= (link & 1)? (irq << 4): (irq & 15);
	pcicfgw8(router, 0x5c + (link>>1), pirq);
}

typedef struct Bridge Bridge;
struct Bridge
{
	ushort	vid;
	ushort	did;
	uchar	(*get)(Pcidev *, uchar);
	void	(*set)(Pcidev *, uchar, uchar);
};

static Bridge southbridges[] = {
	{ 0x8086, 0x122e, pIIxget, pIIxset },	/* Intel 82371FB */
	{ 0x8086, 0x1234, pIIxget, pIIxset },	/* Intel 82371MX */
	{ 0x8086, 0x7000, pIIxget, pIIxset },	/* Intel 82371SB */
	{ 0x8086, 0x7110, pIIxget, pIIxset },	/* Intel 82371AB */
	{ 0x8086, 0x7198, pIIxget, pIIxset },	/* Intel 82443MX (fn 1) */
	{ 0x8086, 0x2410, pIIxget, pIIxset },	/* Intel 82801AA */
	{ 0x8086, 0x2420, pIIxget, pIIxset },	/* Intel 82801AB */
	{ 0x8086, 0x2440, pIIxget, pIIxset },	/* Intel 82801BA */
	{ 0x8086, 0x2448, pIIxget, pIIxset },	/* Intel 82801BAM/CAM/DBM */
	{ 0x8086, 0x244c, pIIxget, pIIxset },	/* Intel 82801BAM */
	{ 0x8086, 0x244e, pIIxget, pIIxset },	/* Intel 82801 */
	{ 0x8086, 0x2480, pIIxget, pIIxset },	/* Intel 82801CA */
	{ 0x8086, 0x248c, pIIxget, pIIxset },	/* Intel 82801CAM */
	{ 0x8086, 0x24c0, pIIxget, pIIxset },	/* Intel 82801DBL */
	{ 0x8086, 0x24cc, pIIxget, pIIxset },	/* Intel 82801DBM */
	{ 0x8086, 0x24d0, pIIxget, pIIxset },	/* Intel 82801EB */
	{ 0x8086, 0x25a1, pIIxget, pIIxset },	/* Intel 6300ESB */
	{ 0x8086, 0x2640, pIIxget, pIIxset },	/* Intel 82801FB */
	{ 0x8086, 0x2641, pIIxget, pIIxset },	/* Intel 82801FBM */
	{ 0x8086, 0x27b8, pIIxget, pIIxset },	/* Intel 82801GB */
	{ 0x8086, 0x27b9, pIIxget, pIIxset },	/* Intel 82801GBM */
	{ 0x8086, 0x27bd, pIIxget, pIIxset },	/* Intel 82801GB/GR */
	{ 0x8086, 0x2916, pIIxget, pIIxset },	/* Intel 82801IR */
	{ 0x8086, 0x3a16, pIIxget, pIIxset },	/* Intel 82801JIR */
	{ 0x8086, 0x3a40, pIIxget, pIIxset },	/* Intel 82801JI */
	{ 0x8086, 0x3a42, pIIxget, pIIxset },	/* Intel 82801JI */
	{ 0x8086, 0x3a48, pIIxget, pIIxset },	/* Intel 82801JI */
	{ 0x8086, 0x1c02, pIIxget, pIIxset },	/* Intel 6 Series/C200 */
	{ 0x8086, 0x1c44, pIIxget, pIIxset },	/* Intel 6 Series/Z68 Express */
	{ 0x8086, 0x1e53, pIIxget, pIIxset },	/* Intel 7 Series/C216 */
	{ 0x8086, 0x8186, pIIxget, pIIxset },	/* Intel Atom E6xx LPC */
	{ 0x8086, 0x8c56, pIIxget, pIIxset },	/* Intel C226 (H81?) LPC */
	{ 0x8086, 0x9cc3, pIIxget, pIIxset },	/* Intel NUC */
	{ 0x8086, 0xa149, pIIxget, pIIxset },	/* Intel C236 Chipset LPC/eSPI */

	{ 0x1106, 0x0586, viaget, viaset },	/* Viatech 82C586 */
	{ 0x1106, 0x0596, viaget, viaset },	/* Viatech 82C596 */
	{ 0x1106, 0x0686, viaget, viaset },	/* Viatech 82C686 */
	{ 0x1106, 0x3227, viaget, viaset },	/* Viatech VT8237 */
	{ 0x1045, 0xc700, optiget, optiset },	/* Opti 82C700 */
	{ 0x10b9, 0x1533, aliget, aliset },	/* Al M1533 */
	{ 0x1039, 0x0008, pIIxget, pIIxset },	/* SI 503 */
	{ 0x1039, 0x0496, pIIxget, pIIxset },	/* SI 496 */
	{ 0x1078, 0x0100, cyrixget, cyrixset },	/* Cyrix 5530 Legacy */

	{ 0x1022, 0x746B, nil, nil },		/* AMD 8111 */
	{ 0x1022, 0x1410, nil, nil },		/* AMD SOC (for coreboot) */
	{ 0x1022, 0x780b, nil, nil },		/* AMD FCH SMBus */

	{ 0x10DE, 0x00D1, nil, nil },		/* NVIDIA nForce 3 */
	{ 0x10DE, 0x00E0, nil, nil },		/* NVIDIA nForce 3 250 Series */
	{ 0x10DE, 0x00E1, nil, nil },		/* NVIDIA nForce 3 250 Series */
	{ 0x1166, 0x0200, nil, nil },		/* ServerWorks ServerSet III LE */

	{ 0x1002, 0x4377, nil, nil },		/* ATI Radeon Xpress 200M */
	{ 0x1002, 0x4372, nil, nil },		/* ATI SB400 */
	{ 0x1002, 0x4384, nil, nil },		/* ATI SB600 (for coreboot) */
};

typedef struct Slot Slot;
struct Slot {
	uchar	bus;		/* Pci bus number */
	uchar	dev;		/* Pci device number */
	uchar	maps[12];	/* Avoid structs!  Link and mask. */
	uchar	slot;		/* Add-in/built-in slot */
	uchar	reserved;
};

typedef struct Router Router;
struct Router {
	uchar	signature[4];	/* Routing table signature */
	uchar	version[2];	/* Version number */
	uchar	size[2];	/* Total table size */
	uchar	bus;		/* Interrupt router bus number */
	uchar	devfn;		/* Router's devfunc */
	uchar	pciirqs[2];	/* Exclusive PCI irqs */
	uchar	compat[4];	/* Compatible PCI interrupt router */
	uchar	miniport[4];	/* Miniport data */
	uchar	reserved[11];
	uchar	checksum;
};

static ushort pciirqs;		/* Exclusive PCI irqs */
static Bridge *southbridge;	/* Which southbridge to use. */

static Bridge *
pcisouthbridge(int tbdf, Pcidev *sbpci)
{
	int i;
	Bridge *sb;

	if(sbpci == nil) {
		print("pcirouting: Cannot find south bridge %T\n", tbdf);
		return nil;
	}

	for(i = 0; i < nelem(southbridges); i++)
		if (sbpci->vid == southbridges[i].vid &&
		    sbpci->did == southbridges[i].did)
			break;
	if(i >= nelem(southbridges))
		if (sbpci->vid == Vintel) {
			print("pcirouting: assuming pIIx for unknown intel "
				"south bridge %T %.4uX/%.4uX\n",
				tbdf, sbpci->vid, sbpci->did);
			i = 0;		/* pretend it's a known intel SB */
		} else {
			print("pcirouting: ignoring unknown south bridge "
				"%T %.4uX/%.4uX\n",
				tbdf, sbpci->vid, sbpci->did);
			return nil;
		}
	sb = &southbridges[i];
	if(sb->get == nil || sb->set == nil) {
		print("pcirouting: ignoring south bridge %T %.4uX/%.4uX; "
			"lacks get or set\n",
			tbdf, sbpci->vid, sbpci->did);
		return nil;
	}
	return sb;
}

static void
prrtrslot(Slot *e)
{
	int i;

	print("%.2uX/%.2uX %.2uX: ", e->bus, e->dev, e->slot);
	for (i = 0; i < 4; i++) {
		uchar *m = &e->maps[i * 3];

		print("[%d] %.2uX %.4uX ", i, m[0], (m[2] << 8)|m[1]);
	}
	print("\n");
}

/* interrupt routing will only be as good as the tables generated by the BIOS. */
void
pcirouting(void)
{
	Slot *e;
	Router *r;
	int size, fn, tbdf;
	Pcidev *sbpci, *pci;
	uchar *p, pin, irq, link, *map;

	/* Search for PCI interrupt routing table in BIOS */
	for(p = (uchar *)KADDR(0xf0000); p < (uchar *)KADDR(0xfffff); p += 16)
		if(p[0] == '$' && p[1] == 'P' && p[2] == 'I' && p[3] == 'R')
			break;

	if(p >= (uchar *)KADDR(0xfffff)) {
		// print("no PCI intr routing table found\n");
		return;
	}

	r = (Router *)p;
	DBG("PCI interrupt routing table v%d.%d at %#p\n",
		r->version[0], r->version[1], r);

	/* find our southbridge, if any */
	tbdf = (BusPCI << 24)|(r->bus << 16)|(r->devfn << 8);
	sbpci = pcimatchtbdf(tbdf);
	southbridge = pcisouthbridge(tbdf, sbpci);
	if (southbridge == nil)
		return;

	pciirqs = (r->pciirqs[1] << 8)|r->pciirqs[0];
	size = (r->size[1] << 8)|r->size[0];
	for(e = (Slot *)&r[1]; (uchar *)e < p + size; e++) {
		if (0)
			prrtrslot(e);
		for(fn = 0; fn < 8; fn++) {
			tbdf = BusPCI << 24|e->bus << 16|(e->dev | fn) << 8;
			pci = pcimatchtbdf(tbdf);
			if(pci == nil)
				continue;
			pin = pcicfgr8(pci, PciINTP);
			if(pin == 0 || pin == 0xff)
				continue;

			map = &e->maps[(pin - 1) * 3];
			link = map[0];
			irq = southbridge->get(sbpci, link);
			if(irq == 0 || irq == pci->intl)
				continue;
			if(pci->intl != 0 && pci->intl != 0xFF) {
				print("pcirouting: BIOS workaround: "
					"%T at pin %d link %d irq %d -> %d\n",
					tbdf, pin, link, irq, pci->intl);
				southbridge->set(sbpci, link, pci->intl);
				continue;
			}
			print("pcirouting: %T at pin %d link %d irq %d\n",
				tbdf, pin, link, irq);
			pcicfgw8(pci, PciINTL, irq);
			pci->intl = irq;
			if(0 && pci->intl == 0)
				print("pcirouting: warning: %T has irq 0\n",
					tbdf);
		}
	}
}

static void
pcinobiossizes(void)
{
	ulong mema, ioa;

	/*
	 * Work out how big the top bus is
	 */
	pcibussize(pciroot, &mema, &ioa);
	DBG("Sizes: mem=%8.8lux size=%8.8lux io=%8.8lux\n",
		mema, pcimask(mema), ioa);

	/*
	 * Align the windows and map it
	 */
	ioa = 0x1000;
	mema = 0x90000000;
	pcilog("Mask sizes: mem=%lux io=%lux\n", mema, ioa);

	pcibusmap(pciroot, &mema, &ioa, Write);
	DBG("Sizes2: mem=%lux io=%lux\n", mema, ioa);
}

static int
getlowerconf(char *var, int max)
{
	int val;
	char *p;

	p = getconf(var);		/* on rv now, returns nil */
	USED(var);
	if(p) {
		val = strtoul(p, 0, 0);
		if(val < max)
			return val;
	}
	return max;
}

/* walk tree of pci(-e) buses and initialize bridges and devices */
void
pcicfginit(void)
{
	Pcidev **list;
	int bno;

	lock(&pcicfginitlock);
	if(pcicfgmode != -1)		/* already configured? */
		goto out;

	if(getconf("*nobios"))
		nobios = 1;
	if(getconf("*nopcirouting"))
		nopcirouting = 1;

	/*
	 * Assume Configuration Mechanism One. Method Two was deprecated
	 * a long time ago and was only for backwards compaibility with the
	 * Intel Saturn and Mercury chip sets (1993-4). Thank you, QEMU.
	 */
	pcicfgmode = 1;

	fmtinstall('T', tbdffmt);

	/* enumerate pci buses and build data structure of their contents */
	if (pcimaxbno == 0)
		pcimaxbno = 15;
	if (pcimaxdno == 0)
		pcimaxdno = 31;
	pcimaxbno = getlowerconf("*pcimaxbno", pcimaxbno);
	pcimaxdno = getlowerconf("*pcimaxdno", pcimaxdno);

	list = &pciroot;
	for(bno = 0; bno <= pcimaxbno; bno++) {
		bno = pcilscan(bno, list);
		while(*list)			/* advance list for next bus */
			list = &(*list)->link;
	}

	if(pciroot != nil) {
		if(nobios) {
			pcinobiossizes();  /* special case for appliances */
			goto hinv;
		}
		if (!nopcirouting)
			pcirouting();
	}
	pcireservemem();
hinv:
	if(getconf("*pcihinv"))
		pcilhinv(nil);
out:
	unlock(&pcicfginitlock);
}

void
pciiocfirq(Pcidev *)
{
}

/* v may be nil */
void
pcimsioff(Vctl *v, Pcidev *pcidev)
{
	int ptr;
	Msi msi;

	memset(&msi, 0, sizeof msi);
	ptr = pcigetmsi(pcidev, &msi);
	if (ptr == -1)
		return;			/* no msi */
	if (v)
		v->ismsi = 0;
	if (!(msi.ctl & Msienable))
		return;			/* already off */
	msi.ctl &= ~Msienable;
	msi.addr = Lapicphys;
	msi.data = 0;
	pcisetmsi(pcidev, &msi);

//	print("%s: msi disabled for %T\n", (v? v->name: ""), pcidev->tbdf);
}
