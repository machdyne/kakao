#ifdef USE_BSTDIO
#include <bstdio.h>
#else
#pragma	src	"/sys/src/libstdio"
#pragma	lib	"libstdio.a"

/*
 * pANS stdio.h
 */
/*
 * According to X3J11, there is only one i/o buffer
 * and it must not be occupied by both input and output data.
 *
 * If rp<wp, we must have state==RD and
 * if wp<rp, we must have state==WR, so that getc and putc work correctly.
 * On open, rp, wp and buf are set to 0, so first getc or putc will call
 * _IO_getc or _IO_putc, which will allocate the buffer.
 *
 * If setvbuf(., ., _IONBF, .) is called, bufl is set to 0 and
 * buf, rp and wp are pointed at unbuf.
 * If setvbuf(., ., _IOLBF, .) is called, _IO_putc leaves wp and rp pointed at
 * the end of the buffer so that it can be called on each putc to check whether
 * it's got a newline.  This nonsense is in order to avoid impacting performance
 * of the other buffering modes more than necessary -- putting the test in putc
 * adds many instructions that are wasted in non-_IOLBF mode:
 *
 * #define putc(c, f) (_IO_ctmp=(c),\
 * 		(f)->wp>=(f)->rp || (f)->flags&LINEBUF && _IO_ctmp=='\n'?\
 * 		_IO_putc(_IO_ctmp, f): *(f)->wp++=_IO_ctmp)
 */
typedef struct{		/* rearranged for compactness on 64-bit systems */
	int fd;		/* UNIX file pointer */
	char flags;	/* bits for must free buffer on close, line-buffered */
	char state;	/* last operation was read, write, position, error, eof */
	char junk;
	uchar unbuf[1];	/* tiny buffer for unbuffered io */
	uchar *buf;	/* pointer to i/o buffer */
	uchar *rp;	/* read pointer (or write end-of-buffer) */
	uchar *wp;	/* write pointer (or read end-of-buffer) */
	uchar *lp;	/* actual write pointer used when line-buffering */
	long bufl;	/* actual length of buffer */
}FILE;

typedef long long fpos_t;

#ifndef NULL
#define	NULL	((void*)0)
#endif

/*
 * Third arg of setvbuf
 */
#define	_IOFBF	1			/* block-buffered */
#define	_IOLBF	2			/* line-buffered */
#define	_IONBF	3			/* unbuffered */

#define	BUFSIZ	8192			/* size of setbuf buffer */
#define	EOF	(-1)			/* returned on end of file */
#define	FOPEN_MAX	128		/* max files open */
#define	FILENAME_MAX	BUFSIZ		/* silly filename length */
#define	L_tmpnam	20		/* sizeof "/tmp/abcdefghij9999 */
#define	SEEK_CUR	1
#define	SEEK_END	2
#define	SEEK_SET	0
#define	TMP_MAX		64		/* very hard to set correctly */

#define	stderr	(&_IO_stream[2])
#define	stdin	(&_IO_stream[0])
#define	stdout	(&_IO_stream[1])

extern FILE _IO_stream[FOPEN_MAX];

int	_IO_getc(FILE *f);
int	_IO_putc(int, FILE *);
void	clearerr(FILE *);
int	fclose(FILE *);
FILE	*fdopen(const int, const char *);
int	feof(FILE *);
int	ferror(FILE *);
int	fflush(FILE *);
int	fgetc(FILE *);
int	fgetpos(FILE *, fpos_t *);
char	*fgets(char *, int, FILE *);
int	fileno(FILE *);
FILE	*fopen(const char *, const char *);
int	fprintf(FILE *, const char *, ...);
int	fputc(int, FILE *);
int	fputs(const char *, FILE *);
long	fread(void *, long, long, FILE *);
FILE	*freopen(const char *, const char *, FILE *);
int	fscanf(FILE *, const char *, ...);
int	fseek(FILE *, long, int);
int	fseeko(FILE *, long long, int);
int	fsetpos(FILE *, const fpos_t *);
long	ftell(FILE *);
long long ftello(FILE *);
long	fwrite(const void *, long, long, FILE *);
int	getc(FILE *);
#define	getc(f)	((f)->rp>=(f)->wp?_IO_getc(f):*(f)->rp++)
int	getchar(void);
#define	getchar()	getc(stdin)
char	*gets(char *);
void	perror(const char *);
int	printf(const char *, ...);
int	putc(int, FILE *);
/*	assignment to f->junk eliminates warnings about unused result of operation */
#define	putc(c, f) ((f)->junk = ((f)->wp>=(f)->rp? \
	_IO_putc(c, f): (*(f)->wp++ = (c))))
int	putchar(int);
#define	putchar(c)	putc(c, stdout)
int	puts(const char *);
void	rewind(FILE *);
int	scanf(const char *, ...);
char	*sclose(FILE *);
void	setbuf(FILE *, void *);
int	setvbuf(FILE *, void *, int, long);
int	snprintf(char *, int, const char *, ...);
FILE	*sopenr(const char *);
FILE	*sopenw(void);
int	sprintf(char *, const char *, ...);
int	sscanf(const char *, const char *, ...);
FILE	*tmpfile(void);
char	*tmpnam(char *);
int	ungetc(int, FILE *);
int	vfprintf(FILE *, const char *, va_list);
int	vfscanf(FILE *, const char *, va_list);
int	vprintf(const char *, va_list);
int 	vsnprintf(char *, int, const char *, va_list);
int	vsprintf(char *, const char *, va_list);
#endif
