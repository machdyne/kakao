/*
 * (i)(un)lock, canlock - spinlocks with test-and-set, for short-lived locks
 *
 * recently added more coherence calls to push changes to other cpus sooner.
 * all of (i)(un)lock are guaranteed to call coherence.
 *
 * Somehow in the inner lock-contention loops of lock and ilock, we can get
 * rescheduled on to another cpu, and the cycle counters are not guaranteed to
 * be synchronised on all architectures (though they are on x86), so don't use
 * them to detect lock loops.  I don't know how this is possible, maybe clock
 * interrupts triggering scheduling.
 */
#include "u.h"
#include "../port/lib.h"
#include "mem.h"
#include "dat.h"
#include "fns.h"

#include "../port/edf.h"

enum {
	Notilock,
	Isilock,

	Lockdebug = 0,
	LOCKCYCLES = 0,
};

/*
 * there are races updating all of these, so they are only approximate on MPs
 * because we use ++ not ainc().
 */
uvlong maxlockcycles;
uvlong maxilockcycles;
uvlong cumlockcycles;
uvlong cumilockcycles;
uintptr maxlockpc;
uintptr maxilockpc;

struct
{
	ulong	locks;
	ulong	glare;
	ulong	inglare;
} lockstats;

static int
deccnt(long *refs, char *who, uintptr caller)
{
	int x, old;

	x = old = *refs; USED(x);
	/* imperfect attempt to avoid decrementing a zero ref count */
	if (old <= 0 || (x = adec(refs)) < 0)
		panic("deccnt: ref %d <= 0; %s callerpc=%#p",
			old, who, caller);
	return x;
}

static void
lockloop(Lock *l, uintptr pc)
{
	Proc *p;

	p = l->p;
	iprint("lock %#p loop key %#lux pc %#p held by pc %#p proc %lud\n",
		l, (ulong)l->key, pc, l->pc, p? (ulong)p->pid: 0);
	dumpaproc(up);
	if(p != nil)
		dumpaproc(p);
}

static void
userlock(Lock *lck, char *func, uintptr pc)
{
	panic("%s: nil or user-space Lock* %#p; called from %#p", func, lck, pc);
}

/*
 * Priority inversion, yield on a uniprocessor;
 * on a multiprocessor, another processor will unlock.
 * Not a common code path.
 */
static void
edfunipriinversion(Lock *l, uintptr pc)
{
	print("lock: inversion %#p pc %#p proc %lud held by pc %#p proc %lud\n",
		l, pc, up? (ulong)up->pid: 0, l->pc, l->p? (ulong)l->p->pid: 0);
	up->edf->d = todget(nil, nil);		/* yield to process with lock */
}

/* on success, return 0 with nlocks>0, else return -1 with nlocks unchanged */
static int
grablock(Lock *l, char *who, uintptr caller, int isilock)
{
	if (up)
		ainc(&up->nlocks);  /* prevent being scheded until nlocks==0*/
	if(_tas(&l->key) != 0) {	/* failed to acquire lock? */
		if (up)
			/* restore nlocks; may allow scheding again */
			deccnt(&up->nlocks, who, caller);
		return -1;
	}

	/* acquired the lock, update it */
	if (up)
		up->lastlock = l;
	l->pc = caller;
	l->p = up;
	l->m = MACHP(m->machno);
	l->isilock = isilock;
	if (LOCKCYCLES)
		cycles(&l->lockcycles);
	coherence();
	return 0;
}

static long
decnlocks(char *fn, uintptr pc)
{
	int x;

	x = 0;
	if (up && (x = adec(&up->nlocks)) < 0) /* may allow being scheded */
		panic("%s: ref %d < 0 after adec; callerpc=%#p", fn, x, pc);
	return x;
}

static void
lockdebug(Lock *l, uintptr pc)
{
	/* we can be called from low addresses before the mmu is on. */
	if (l == nil)
		userlock(l, "lock", pc);
	if (l->noninit)
		panic("lock: lock %#p is not a lock, from %#p", l, pc);
}

/*
 * returns with Lock l held and, if up is non-nil, up->nlocks non-zero.
 * leaves PL alone, especially when waiting for the lock.
 * calls coherence before return.
 *
 * if waitfor, watchforchange or waitchange use monitor/mwait or lr/wrsnto for
 * l->key, an interrupt could ilock and change the single per-cpu monitor
 * address used by lock, for example, causing a single failed attempt to acquire
 * the lock, which shouldn't be a problem.
 */
int
lock(register Lock *l)
{
	uint val;
	uintptr i;			/* use native word size for speed */
	uintptr pc;
	register int *keyp;
	Edf *edf;

	pc = getcallerpc(&l);
	if (Lockdebug)
		lockdebug(l, pc);
	lockstats.locks++;
	if (grablock(l, "lock", pc, Notilock) >= 0)
		return 0;			/* got it on the first try */

	lockstats.glare++;
	keyp = &l->key;
	edf = !MPSRUNNING() && up? up->edf: nil;
	while (grablock(l, "lock", pc, Notilock) < 0) {
		/* didn't grab the lock? wait on key & try again */
		if(up && l->p == up)
			panic("lock: deadlock acquiring lock held by same proc,"
				" from %#p", pc);
		lockstats.inglare++;
		// watchforchange(keyp);
		for (i = 2LL*GHZ; (val = *keyp) != 0; i--) {
			if(edf && edf->flags & Admitted)
				edfunipriinversion(l, pc);
			if(i == 0) {		/* are we stuck? */
				lockloop(l, pc);
				i = 2LL*GHZ;
			}
			/*
			 * waitfor idles to intr, if possible. it tends to take
			 * more system time & always takes more elapsed time,
			 * at least on pc & k10.
			 */
			// waitfor((long *)keyp, val);
			USED(val);
		}
		/* the lock looks free; try to acquire again */
	}
	return 1;				/* took more than one try */
}

static void
ilockdebug(Lock *l, uintptr pc)
{
	if (l == nil)
		userlock(l, "ilock", pc);
	if (l->noninit)
		panic("ilock: lock %#p is not a lock (noninit = %#ux),"
			" from %#p", l, (uint)l->noninit, pc);
}

/*
 * waits for the lock at entry PL, returns at high PL.
 *
 * if called splhi on a uniprocessor, the loop on l->key!=0
 * below will run at splhi, and thus cannot succeed as
 * nothing can change l->key, unless another cpu is spinning
 * up concurrently, or dma changes l->key, or iunlock writing
 * 0 to l->key has been vastly delayed in a write buffer, so
 * there is no way out.
 */
void
ilock(register Lock *al)
{
	int waslo;
	uintptr i;			/* use native word size for speed */
	uintptr pc;
	register int *keyp;
	Mpl s;

	pc = getcallerpc(&al);
	if (Lockdebug)
		ilockdebug(al, pc);
	lockstats.locks++;

	keyp = &al->key;
	waslo = islo();
	s = splhi();
	if(_tas(keyp) != 0){		/* failed to acquire lock? */
		lockstats.glare++;
		if(!waslo && !MPCAPABLE() && !MPSRUNNING())
			iprint("ilock: lock %#p: no way out on uniprocessor, "
				"from %#p splhi\n", al, pc);
		/*
		 * Have to wait for al to be released.
		 * Cannot also check al->pc, al->m, or al->isilock here
		 * because they might just not be set yet, or
		 * (for pc and m) the lock might have just been unlocked.
		 */
		do {
			lockstats.inglare++;
			splx(s);
			for (i = 2LL*GHZ; *keyp != 0; i--)
				if(i == 0) {		/* are we stuck? */
					lockloop(al, pc);
					i = 2LL*GHZ;
				}
			splhi();
			/* lock looks free, grab it quick */
		} while (_tas(keyp) != 0);
	}

	/* we have the lock (l->key), update other fields to reflect that */
	{
		register Lock *l = al;

		if (up)
			up->lastlock = l;
		l->pc = pc;
		l->p = up;
		l->m = MACHP(m->machno);
		l->isilock = Isilock;
		if (LOCKCYCLES)
			cycles(&l->lockcycles);
		coherence();		/* make changes visible to other cpus */
		l->sr = s;
	}
	m->ilockpc = pc;
	m->ilockdepth++;	/* increment after acquiring lock */
}

/* try to acquire lock once; return success boolean */
int
canlock(Lock *l)
{
	uintptr pc;

	pc = getcallerpc(&l);
	if (Lockdebug && l == nil)
		userlock(l, "canlock", pc);
	if (grablock(l, "canlock", pc, Notilock) < 0)
		return 0;
	return 1;
}

static void
givelockback(Lock *l)
{
	l->m = nil;
	l->p = nil;
	coherence();
	/*
	 * actual release; data protected by this Lock and the Lock itself
	 * must be current before release.
	 */
	l->key = 0;
	coherence();
}

static void
unlockdebug(Lock *l, uintptr pc)
{
	if (l == nil)
		userlock(l, "unlock", pc);
	if(l->key == 0)
		iprint("unlock: not locked: pc %#p\n", pc);
	if(l->isilock)
		iprint("unlock of ilock: pc %#p, held by %#p\n", pc, l->pc);
}

static void
countcycles(Lock *l, uvlong *maxcycp, uintptr *maxpcp)
{
	uvlong cyc;

	cycles(&cyc);
	l->lockcycles = cyc - l->lockcycles;
	if(l->lockcycles > *maxcycp){
		*maxcycp = l->lockcycles;
		*maxpcp = l->pc;
	}
}

/* may trigger rescheduling */
void
unlock(Lock *l)
{
	uintptr pc;

	pc = getcallerpc(&l);
	if (LOCKCYCLES)
		countcycles(l, &maxlockcycles, &maxlockpc);
	if (Lockdebug)
		unlockdebug(l, pc);
	USED(pc);

	/*
	 * only the Lock-holding process should release it.  otherwise,
	 * the wrong up->nlocks will be decremented.  a Lock may have been
	 * acquired when up was nil and is being released after setting it,
	 * but Locks are not supposed to be held for long (in particular,
	 * across sleeps or sched calls).
	 *
	 * if l->p is nil, up->nlocks should not have been incremented when
	 * locking, thus should not be decremented here.
	 * l->p == up should always be true.
	 */
	if (l->p != up)
		iprint("unlock: l->p changed: pc %#p, acquired at pc %#p, "
			"lock p %#p != unlock up %#p\n", pc, l->pc, l->p, up);
	givelockback(l);
	if (up == nil)
		return;		/* no process context, can't do the rest */

	/*
	 * Call sched if the need arose while locks were held, but
	 * don't do it from interrupt routines, hence the islo() test.
	 */
	if(decnlocks("unlock", pc) == 0 &&	/* may allow scheding */
	    up->delaysched && islo())
		sched();
	/*
	 * contenders for this lock will be spinning or watching l->key, no need
	 * to wake them.
	 */
}

uintptr ilockpcs[0x100] = { [0xff] = 1 };
static int ilockpc;

static void
iunlockdebug(Lock *l, uintptr pc)
{
	if (l == nil)
		userlock(l, "iunlock", pc);
	if(l->key == 0)
		print("iunlock: not locked: pc %#p\n", pc);
	if(!l->isilock)
		print("iunlock of lock: pc %#p, held by %#p\n", pc, l->pc);
	if(l->m != m)
		print("iunlock by cpu%d, locked by cpu%d: pc %#p, held by %#p\n",
			(m? m->machno: -1), (l && l->m? l->m->machno: -1),
			pc, l->pc);
}

void
iunlock(Lock *l)
{
	uintptr pc;
	Mpl s;

	pc = getcallerpc(&l);
	if (LOCKCYCLES) {
		countcycles(l, &maxilockcycles, &maxilockpc);
		if(l->lockcycles > 2400)
			ilockpcs[ilockpc++ & 0xff] = l->pc;
	}
	if (Lockdebug)
		iunlockdebug(l, pc);
	if(islo())
		print("iunlock while lo: pc %#p, held by %#p\n", pc, l->pc);

	if(up)
		up->lastilock = nil;
	m->ilockdepth--;	/* decrement before lock release */
	s = l->sr;
	givelockback(l);
	splx(s);
	/*
	 * contenders for this lock will be spinning or watching l->key, no need
	 * to wake them.
	 */
}

static void
profiling_after_iunlock(void)
{
	profiling_after_iunlock();
	profiling_after_iunlock();
}
