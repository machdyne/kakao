/*
 * amd k10 (x86-64-v1 a.k.a. AMD64-v1) architecture-specific stuff: cpu
 * identification, idling, delays, clz.  cpuid features guaranteed: fpu, cx8,
 * cmov, mmx, fxsr, sse, sse2, osfxsr, sce, lm.
 *
 * sorry about the magic numbers.  i've been removing them.
 */
#include "u.h"
#include "../port/lib.h"
#include "mem.h"
#include "dat.h"
#include "fns.h"

#include "amd64.h"

enum {
	/*
	 * we have our own monitor/mwait machinery.
	 */
	Lockwake = 1,	/* flag: use 9's lockwake & locknote monitor & mwait */
};

typedef struct Inmodels Inmodels;
struct Inmodels {
	ushort	num;
	char	*name;
};

int (*waitfor)(long *, int) = portwaitfor;

int cputemp;
char intelidswiz[] = "GenuntelineI";	/* swizzled id from cpuid */

static int
cpuidinit(void)
{
	ulong eax, info[Ncpuidregs];

	/*
	 * Standard CPUID functions.
	 * Functions 0 and 1 will be needed multiple times
	 * so cache the info now.
	 */
	if((m->ncpuinfos = cpuid(Highstdfunc, 0, m->cpuinfo[Highstdfunc])) == 0)
		return 0;
	m->ncpuinfos++;

	if(memcmp(&m->cpuinfo[Highstdfunc][Bx], intelidswiz, 12) == 0)
		m->isintelcpu = 1;
	cpuid(Procsig, 0, m->cpuinfo[Procsig]);

	/*
	 * Extended CPUID functions.
	 */
	if((eax = cpuid(Highextfunc, 0, info)) >= Highextfunc)
		m->ncpuinfoe = (eax & ~Highextfunc) + 1;

	if (m->machno != 0)
		return 1;	/* remaining features are system-wide */

	/*
	 * Is MONITOR/MWAIT supported?
	 * All actual k10 and later hardware has them.
	 * AMD added them in 2007, Intel in 2004.
	 */
	if(m->cpuinfo[Procsig][Cx] & Monitor) {
		waitfor = k10waitfor;
		if(cpuidinfo(Procmon, 0, info) && info[Cx] & Alwaysbreak)
			sys->haveintrbreaks = 1;
	} else				/* pre-2007 pc or emulation */
		vmbotch(0, "monitor & mwait instructions disabled; "
			"adjust your bios settings");
	return 1;
}

void
cpuidcaps(void)
{
	int vabits, cores, turbo;
	ulong info[Ncpuidregs];

	if (m->isintelcpu && cpuidinfo(Proctype, 0, info))
		m->intelcputype = info[Ax] >> 24;

	if (m->machno != 0)
		return;

	cores = (m->cpuinfo[Procsig][Bx]>>16) & MASK(8);
	if (m->cpuinfo[Procsig][Dx] & Htt && cores > 1)
		print("hyperthreading supported, %d cores/processor max\n",
			cores);

	if(cpuidinfo(Extfeature, 0, info) && (info[Dx] & Nx) == 0)
		print("no no-execute bit support!\n");

	if (m->isintelcpu) {
		turbo = (rdmsr(Msrperfctl) & Turbooff) == 0;
		/* real amd64 and intel64 systems have had this since 2008 */
		if (cpuidinfo(Extmiscfeat, 0, info) && info[Dx] & Invartsc) {
			if (!turbo)
				print("invariant time-stamp counter; "
					"OK to enable Turbo Boost in BIOS\n");
		} else
			if (turbo) {
				print("* Broken hardware or BIOS settings!  "
					"time-stamp counter NOT invariant; "
					"disable Turbo Boost in BIOS\n");
				delay(10000);
			}
	}

	if(cpuidinfo(Extcap, 0, info)) {
		vabits = (info[Ax]>>8) & MASK(8);
		if (vabits != 48)		/* 48 is standard */
			print("%d-bit virtual addresses available\n", vabits);
	}
	if(cpuidinfo(Procid7, 0, info) && info[Cx] & L5pt)
		print("cpu supports 5-level page tables; not used\n");
}

int
cpuidinfo(ulong eax, ulong ecx, ulong info[Ncpuidregs])
{
	if(m->ncpuinfos == 0 && cpuidinit() == 0)
		return 0;

	if(!(eax & Highextfunc)){
		if(eax >= m->ncpuinfos)
			return 0;
	} else if(eax >= (Highextfunc|m->ncpuinfoe))
		return 0;

	cpuid(eax, ecx, info);
	return 1;
}

enum {
	Monitorsz = 64,			/* typical, but much bigger in VMs */
};

static long mwords[(Monitorsz/BY2WD + 1)*2];	/* isolated cache line */
static long *mwaitwd = mwords;			/* make safe from the start */
static int mwdaligned;

void
nop(void)
{
}

void
mwdalign(void)
{
	uint min, max;
	ulong info[Ncpuidregs];

	if (mwdaligned || m == nil || m->machno != 0)
		return;

	/* not yet aligned, and on cpu0 */
	if (!mallocok || m->ncpuinfos == 0 || Procmon >= m->ncpuinfos) {
		mwaitwd = (long *)ROUNDUP((uintptr)mwords, Monitorsz);
		if (m->ncpuinfos > 0 && Procmon >= m->ncpuinfos)
			mwdaligned = 1;	/* Procmon too big; will never work */
		return;
	}

	/* ok to malloc, and can get monitor min & max sizes */
	memset(info, 0, sizeof info);
	max = min = Monitorsz;			/* defaults */
	if(cpuidinfo(Procmon, 0, info)) {
		min = info[Ax] & MASK(16);	/* wakeup-write region size */
		max = info[Bx] & MASK(16);	/* avoid-false-wakeup size */
		if (min == 0 || max == 0 || max < min)
			max = min = Monitorsz;	/* garbled results, default */
	}
	mwdaligned = 1;
	if (max > Monitorsz && up && islo())
		mwaitwd = mallocalign(max, min, 0, 0);
}

void
watchforchange(int *lp)
{
	if (waitfor == k10waitfor)
		monitor(lp, 0, 0);
}

/* watchforchange(lp) must have been previously called. */
void
waitchange(int *)
{
	if (waitfor == k10waitfor)
		mwait(0, 0);
}

void	(*idlehandsfn)(void) = nop;

/*
 *  put the processor in the halt state if we've no processes to run.
 *  an interrupt or change to *mwaitwd will get us going again.
 *  called at spllo from proc.c.
 */
void
idlehands(void)
{
	if (!mwdaligned)
		mwdalign();
//	waitfor(mwaitwd, *mwaitwd);		// TODO
	idlehandsfn();
}

/*
 * wake any cpus in mwait state.  an interrupt will make one cpu break
 * out of mwait, but a qunlock probably should wake any idlers too.
 */
void
idlewake(void)
{
	if (!mwdaligned)
		mwdalign();
	ainc(mwaitwd);
	coherence();
}


/*
 * plan 9 pc wait/idle/lockwake/locknote machinery, for reference.
 */

enum {
	Measure = 0,
};

/* also used by ../port/taslock.c */
void (*locknote)(void) = nop;
void (*lockwake)(void) = nop;

static char *monitorme;
static long dummymonitor;
static long *monitorwd = &dummymonitor;		/* ensure safe deref. always */

static void
mwaitopt(int opts)
{
	uvlong stcyc, endcyc;

	if (Measure)
		cycles(&stcyc);
	mwait(opts, 0);
	m->mword = *monitorwd;
	SET(stcyc, endcyc);
	if (Measure) {
		cycles(&endcyc);
		m->mwaitcycles += endcyc - stcyc;
	}
	USED(stcyc, endcyc);
}

/*
 * it's safe to mwait at splhi on this cpu, we assert.
 * for more accurate cycle counts, mask intrs and only then count
 * the idle cycles.  this will undercount on older (pre-2014?) machines.
 */
static void
mwaitalways(void)
{
	int s;

	s = splhi();
	if (m->mword == *monitorwd)
		mwaitopt(Mwaitintrbreakshi);
	splx(s);
}

/*
 * we assert that this is an older cpu on which it is unsafe to mwait at splhi
 * as an interrupt can't break us out.
 */
static void
mwaitiflo(void)
{
	if (islo() && m->mword == *monitorwd)
		mwaitopt(0);
}

void
mwaitwatch(void)
{
	m->mword = *monitorwd;
	monitor(monitorwd, 0, 0);
}

/* harmless on systems without monitor & mwait */
static void
wakemwait(void)
{
	m->mword = ainc(monitorwd);
	coherence();
}

static int monmax = 64;

static void
allocmword(void)
{
	if (monitorme == nil && monmax != 0) {
		monitorme = xspanalloc(2*monmax, monmax, monmax);
		if (monitorme == nil)
			panic("allocmword: no memory");
		monitorwd = (long *)(monitorme + monmax);
	}
}

/*
 * figure out how to best wait for interrupt or unlock, while consuming
 * the least power (and generating the least heat), within reason.
 * we don't use specific C states or other extreme measures.
 */
void
chooseidler(void)
{
	int s;
	ulong info[Ncpuidregs];

	if (!Lockwake) {
		if (m->machno == 0)
			iprint("chooseidler: not using 9's lockwake/locknote\n");
		return;
	}
	if (m->machno != 0) {
		if ((m->cpuinfo[Procsig][Cx] & Monitor) == 0) {
			idlehandsfn = nop;  /* we burn more power on old MPs */
			iprint("chooseidler: spinning when idle\n");
		}
		return;
	}

	s = splhi();
	if (TODO && sys->vm) {			/* TODO: tune coherence */
		// coherence =
		idlehandsfn = nop;		/* coherence nop ok on vmware */
		iprint("chooseidler: spinning when idle (in a vm)\n");
	} else if (m->cpuinfo[Procsig][Cx] & Monitor) {
		lockwake = wakemwait;
		locknote = mwaitwatch;
		memset(info, 0, sizeof info);
		cpuidinfo(Procmon, 0, info);
		idlehandsfn = info[Cx] & Mwaitintrhi? mwaitalways: mwaitiflo;
		wakemwait();
		iprint("chooseidler: using 9's mwait lockwake/locknote; mwait %s\n",
			info[Cx] & Mwaitintrhi? "always": "at low PL");
	} else {				/* pre-2014 cpu? */
		idlehandsfn = halt;
		iprint("chooseidler: halting when idle\n");
	}
	splx(s);
}


static vlong intelhz[] = {
	266666666666ll, 133333333333ll, 200000000000ll,
	166666666666ll, 333333333333ll, 100000000000ll,
	400000000000ll,
};

/* Xeons implement ECC memory; almost no other Intel models do. */
static Inmodels in6models[] = {
	0x1e, "xeon/core i5/i7",	/* 2009 */
	0x1f, "xeon/core i7",
	0x22, "core i7",
	0x25, "xeon 3000/core i3/i5/i7",
	0x26, "atom e6xx",
	0x2a, "xeon e3/core i3/i5/i7",
	0x2c, "xeon 3000/core i7",
	0x2d, "xeon e5/core i7",
	0x2e, "xeon 6000 mp",
	0x2f, "xeon e7 mp",
	0x36, "atom n2000/d2000",
	0x3a, "xeon e3/core i3/i5/i7",	/* ~2012 ivy bridge */
	0x3c, "xeon/core i7",		/* haswell */
	0x3d, "core (i7|m)-5557u nuc",	/* broadwell */
	0x3e, "core i7",		/* ivy bridge */
	0x3f, "core i7",		/* haswell */
	0x45, "core i5-4302y",		/* haswell */
	0x46, "core i5/i7",		/* haswell */
	0x4a, "edison",			/* silvermont */
	0x4c, "atom x5/x7",		/* 2015 braswell */
	0x4d, "atom c2xxx",		/* silvermont */
	0x9e, "xeon e3-1275 v6",	/* ~2017 coffee lake */
};

static vlong
intelfamfhz(int fammod, int mod)
{
	int r;
	vlong hz;
	uvlong msr;

	hz = 0;
	switch(mod){
	default:
		print("unknown family F cpu model; id %#ux\n", fammod);
		break;
	case 3:		/* Xeon (MP), Pentium [4D] */
	case 4:		/* Xeon (MP), Pentium [4D] */
	case 6:		/* Xeon 7100, 5000 or above */
		print("family F: xeon or pentium [4D]");
		msr = rdmsr(Fsbfreqr);
		r = (msr>>16) & MASK(3);
		if ((uint)r >= nelem(intelhz)) {
			print(" unknown cpu speed, msr %#x = %#llux\n",
				Fsbfreqr, msr);
			break;
		}

		/*
		 * intelhz[r] is *1000 at this point.
		 * Do the scaling then round it.
		 * The manual is conflicting about
		 * the size of the msr field.
		 */
		hz = ((intelhz[r]*(msr>>24))/100 + 5)/10;
		/* is hz actual or nominal? */
		DBG("cpuidhz: %#x: %#llux, hz %lld\n", Fsbfreqr, msr, hz);
		break;
	}
	return hz;
}

static vlong
intelfam6hz(int fammod, int mod, ulong info[2][4])
{
	int r, f;
	vlong hz;
	uvlong msr;
	Inmodels *im, *imend;

	hz = 0;
	switch(mod){
	case 0x09:		/* Pentium M, Celeron M */
	case 0x0d:		/* Pentium M, Celeron M */
		print("pentium M or celeron M");
		hz = ((rdmsr(Pwroncfg)>>22) & MASK(5))*100 * 1000000ll;
		/* is hz actual or nominal? */
		break;
	case 0x0e:		/* Core Duo */
	case 0x0f:		/* Core 2 Duo/Quad/Extreme */
	case 0x17:		/* Core 2 Extreme */
		print("core");
		/*
		 * Get the FSB frequemcy.
		 * If processor has Enhanced Intel Speedstep Technology
		 * then non-integer bus frequency ratios are possible.
		 */
		if(info[Procsig][Cx] & Eist){
			msr = rdmsr(0x198);
			r = msr>>40;
		} else {
			msr = 0;
			r = rdmsr(Pwroncfg);
		}
		r &= MASK(5);
		f = rdmsr(0xcd) & MASK(3);
		if ((uint)r >= nelem(intelhz)) {
			print("unknown cpu speed, msr 0xcd %#ux\n", f);
			break;
		}
		hz = intelhz[r];

		/*
		 * Hz is *1000 at this point.
		 * Do the scaling then round it.
		 */
		hz = hz*r + ((msr & (1ull << 46))? hz/2: 0);
		hz = (hz/100 + 5)/10;
		/* is hz actual or nominal? */
		DBG("cpuidhz: %#x: %#llux hz %lld\n",
			Pwroncfg, rdmsr(Pwroncfg), hz);
		break;
	default:
		/* a cpu we don't know msrs for.  do we know its name? */
		imend = in6models + nelem(in6models);
		for (im = in6models; im < imend; im++)
			if (im->num == mod)
				break;
		if (im < imend)
			print("%s", im->name);
		else
			print("unknown family 6 cpu model %d; id %#ux\n",
				mod, fammod);
		break;
	}
	return hz;
}

/*
 * return value of 0 means we couldn't figure out speed from msrs,
 * typically because we don't know which msrs are available for a given model.
 */
static vlong
intelcpuhz(ulong info[2][4])
{
	int fammod, fam, mod;
	uvlong hz;

	fammod = info[Procsig][Ax] & 0x0fff3ff0;	/* ignore stepping */
	fam = X86FAMILY(fammod);
	mod = X86MODEL(fammod);
	if (fam != 6 && fam != 0xf) {
		print("unknown Intel cpu family %#ux\n", fam);
		return 0;
	}
	print("cpu%d: intel ", m->machno);
	if (fam == 0xf)			/* some MP xeons, misc. Pentia */
		hz = intelfamfhz(fammod, mod);
	else
		hz = intelfam6hz(fammod, mod, info);	/* common case */
	if (hz != 0)
		print(" %,lld MHz nominal;", (hz + 500000) / 1000000);
	return hz;
}

static vlong
amdcpuhz(ulong info[2][4])
{
	int r, fammod, mhz;
	vlong hz;
	uvlong msr;
	char *model;

	model = nil;
	fammod = info[Procsig][Ax] & 0x0fff0ff0;
	switch(fammod){
	default:
		print("unknown AMD cpu family & model %#ux\n", fammod);
		return 0;
	case 0x00000f50:		/* K8 */
		if (model == nil)
			model = "k8";
		msr = rdmsr(0xc0010042);
		if(msr == 0) {
			print("AMD K8 zero msr 0xc0010042\n");
			return 0;
		}
		hz = (800 + 200*((msr>>1) & 0x1f)) * 1000000ll;
		break;
	case 0x00100f90:		/* K10 */
		if (model == nil)
			model = "k10";
	case 0x00730f00:		/* Jaguar */
		if (model == nil)
			model = "jaguar";
	case 0x00000620:		/* QEMU64 */
		if (model == nil) {
			sys->vm |= Qemuhyp;
			model = "emulated qemu64";
		}
		msr = rdmsr(0xc0010064);
		r = (msr>>6) & 0x07;
		hz = (((msr & 0x3f)+0x10)*100000000ll)/(1<<r);
		break;
	}
	DBG("cpuidhz: %#llux hz %lld\n", msr, hz);
	mhz = (hz + 500000) / 1000000;
	print("cpu%d: amd %s cpu(s) at %,d MHz nominal;",
		m->machno, (model? model: ""), mhz);
	return hz;
}

static vlong
cpuidhz(ulong info[2][4])
{
	if(memcmp(&info[Highstdfunc][Bx], intelidswiz, 12) == 0)
		return intelcpuhz(info);
	else if(memcmp(&info[Highstdfunc][Bx], "AuthcAMDenti", 12) == 0)
		return amdcpuhz(info);
	else {
		print("unknown cpu manufacturer\n");
		return 0;
	}
}

void
cpuiddump(void)
{
	int i;
	ulong info[Ncpuidregs];

	if(!DBGFLG)
		return;

	if(m->ncpuinfos == 0 && cpuidinit() == 0)
		return;

	for(i = 0; i < m->ncpuinfos; i++){
		cpuid(i, 0, info);
		DBG("eax = %#8.8ux: %8.8lux %8.8lux %8.8lux %8.8lux\n",
			i, info[0], info[1], info[2], info[3]);
	}
	for(i = 0; i < m->ncpuinfoe; i++){
		cpuid(Highextfunc|i, 0, info);
		DBG("eax = %#8.8ux: %8.8lux %8.8lux %8.8lux %8.8lux\n",
			Highextfunc|i, info[0], info[1], info[2], info[3]);
	}
}

/* crude measure of xeon heating; not general-purpose */
void
readcputemp(void)
{
	vlong temp;
	static int gotmsr = 1;

	if (m->isintelcpu && gotmsr) {
		temp = rdmsr(0x19c);
		if (temp == 0) {	/* msr faulted? */
			gotmsr = 0;
			return;
		}
		if (temp & (1ull<<31))
			/* cpu temp below maximum (100 or 105 C) */
			cputemp = (temp>>16) & MASK(7);
	}
}

vlong
archhz(void)
{
	vlong nomhz, acthz;
	ulong info[Procsig+1][Dx+1];

	if(DBGFLG && m->machno == 0)
		cpuiddump();
	if(!cpuidinfo(Highstdfunc, 0, info[Highstdfunc]) ||
	   !cpuidinfo(Procsig, 0, info[Procsig]))
		return 0;

	if(m->machno != 0)
		return sys->machptr[0]->cpuhz;	/* cpus have to be identical */
	nomhz = cpuidhz(info);
	acthz = i8254hz(info);
	chooseidler();
	return acthz? acthz: nomhz;
}

static void
addpgsz(int lg2)
{
	int npg;

	assert(m->npgsz < NPGSZ);
	npg = m->npgsz++;
	m->pgszlg2[npg] = lg2;
	m->pgszmask[npg] = VMASK(lg2);
}

int
archmmu(void)
{
	ulong info[Ncpuidregs];

	/*
	 * Should the check for m->machno != 0 be here
	 * or in the caller (mmuinit)?
	 *
	 * Pge and Pae in Cr4 were set in _lme().
	 */

	/*
	 * How many page sizes are there?
	 * Always have 4K, but need to check
	 * configured correctly.
	 */
	CTASSERT(PGSZ == 4*KB, PGSZ_4K);
	addpgsz(12);

	/*
	 * Check the Psep bit in function 1 DX for 2MB support;
	 * if false, only 4K is available.
	 */
	if(m->ncpuinfos == 0 && cpuidinit() == 0)
		return 1;
	if(!(m->cpuinfo[Procsig][Dx] & Psep))
		return 1;
	addpgsz(21);

	if(cpuidinfo(Extfeature, 0, info) && (info[Dx] & Page1gb))
		addpgsz(30);
	return m->npgsz;
}

static int
fmtP(Fmt* f)
{
	uintmem pa;

	pa = va_arg(f->args, uintmem);

	if(f->flags & FmtSharp)
		return fmtprint(f, "%#16.16llux", pa);

	return fmtprint(f, "%llud", pa);
}

static int
fmtL(Fmt* f)
{
	return fmtprint(f, "%#16.16llux", va_arg(f->args, Mpl));
}

static int
fmtR(Fmt* f)
{
	return fmtprint(f, "%#16.16llux", va_arg(f->args, uvlong));
}

void
archfmtinstall(void)
{
	/*
	 * Architecture-specific formatting. Not as neat as they
	 * could be (e.g. there's no defined type for a 'register':
	 *	L - Mpl, mach priority level
	 *	P - uintmem, physical address
	 *	R - register
	 * With a little effort these routines could be written
	 * in a fairly architecturally-independent manner, relying
	 * on the compiler to optimise-away impossible conditions,
	 * and/or by exploiting the innards of the fmt library.
	 */
	fmtinstall('P', fmtP);

	fmtinstall('L', fmtL);
	fmtinstall('R', fmtR);
}

/* delay for at least microsecs, avoiding the watchdog if necessary */
void
microdelay(vlong microsecs)
{
	uvlong t, now, nxtdog, dogincr;

	if (microsecs <= 0)
		return;
	now = rdtsc();
	t = now + microsecs*m->cpumhz;
	dogincr = Wdogms * 1000ll * m->cpumhz;
	/* when islo(), clock interrupts will restart the dog */
	if (watchdogon && m->machno == 0 && !islo()) {
		nxtdog = 0;
		while ((now = rdtsc()) < t) {
			if (now > nxtdog) {
				watchdog->restart();
				nxtdog = now + dogincr;
			}
			pause();
		}
	} else
		while (rdtsc() < t)
			pause();
}

void
millidelay(int millisecs)
{
	microdelay(1000ll * millisecs);
}

int
clz(Clzuint n)			/* count leading zeroes */
{
	if (n == 0)
		return Clzbits;
	return Clzbits - 1 - bsr(n);
}

void *
zero(void *vaddr, uintptr len)
{
	return memset(vaddr, 0, len);
}
