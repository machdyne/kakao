/*
 * I/O APIC support.  Largely interrupt routing (redirection).
 *
 * This code has evolved over a long time and it shows.
 * The main strategy now is to use MSI routing if possible;
 * it's simple and avoids most reliance on MPS and ACPI tables.
 * Failing that, we use I/O APIC redirection.
 */
#include "u.h"
#include "../port/lib.h"
#include "mem.h"
#include "dat.h"
#include "fns.h"

#include "apic.h"
#include "io.h"

typedef struct Rdt Rdt;
struct Rdt {
	Apic*	apic;
	int	devno;
	int	intin;
	ulong	lo;

	Rdt*	next;				/* on this bus */
};

enum {						/* IOAPIC registers */
	/* register indices of apic->addr[] */
	Ioregsel	= 0x00,			/* indirect register address */
	Iowin		= 0x04,			/* indirect register data */
	Ioipa		= 0x08,			/* IRQ Pin Assertion */
	Ioeoi		= 0x10,			/* EOI */

	/* register addresses for apic->addr[Ioregsel] */
	Ioapicid	= 0x00,			/* Identification */
	Ioapicver	= 0x01,			/* Version */
	Ioapicarb	= 0x02,			/* Arbitration */
	Ioabcfg		= 0x03,			/* Boot Coniguration */
	Ioredtbl	= 0x10,			/* Redirection Table */
};

extern int mpisabusno;

static Rdt rdtarray[Nrdt];
static int nrdtarray;
static int gsib;
static Rdt* rdtbus[Nbus];
static Rdt* rdtvecno[IdtMAX+1];

static Lock idtnolock;
static uint idtno = IdtIOAPIC;

static ulong
rtblr(ulong *addr, int sel, ulong *valp)
{
	ulong r;

	*(addr+Ioregsel) = sel;
	coherence();
	r = *(addr+Iowin);
	if(valp)
		*valp = r;
	coherence();
	return r;
}

static void
rtblget(Apic* apic, int sel, ulong* hi, ulong* lo)
{
	sel = Ioredtbl + 2*sel;
	rtblr(apic->addr, sel+1, hi);
	rtblr(apic->addr, sel, lo);
}

static void
rtblw(ulong *addr, int sel, ulong val)
{
	assert(addr);
	*(addr+Ioregsel) = sel;
	coherence();
	*(addr+Iowin) = val;
	coherence();
}

/* sel is irq */
static void
rtblput(Apic* apic, int sel, ulong hi, ulong lo)
{
	assert(apic);
	sel = Ioredtbl + 2*sel;
	rtblw(apic->addr, sel+1, hi);
	rtblw(apic->addr, sel, lo);
}

/* called from mp.c/mpparse with data from MPS table */
int
ioapicintrinit(int busno, int apicno, int intin, int devno, ulong lo)
{
	Rdt *rdt;
	Apic *apic;

	if(busno >= Nbus || apicno >= Napic)
		return -1;
	apic = &ioapic[apicno];
	if(!apic->useable) {
		iprint("ioapicintrinit: apic %d not usable\n", apicno);
		return -1;
	}
	if(intin >= apic->nrdt) {
		iprint("ioapicintrinit: intin %d too big for apic nrdt %d\n",
			intin, apic->nrdt);
		return -1;
	}
	if(nrdtarray >= Nrdt) {
		iprint("ioapicintrinit: out of rdtarray entries\n");
		return -1;
	}

	/* allocate a new Rdt and insert it at head of rdtbus[busno] list */
	rdt = &rdtarray[nrdtarray++];
	rdt->apic = apic;
	rdt->devno = devno;
	rdt->intin = intin;
	rdt->lo = lo;
	rdt->next = rdtbus[busno];
	rdtbus[busno] = rdt;
	return 0;
}

void
ioapicinit(int id, uintmem pa)
{
	int i;
	ulong r;
	Apic *apic;

	/*
	 * Mark the IOAPIC useable if it has a good ID
	 * and the registers can be mapped.
	 */
	if((uint)id >= Napic)
		return;

	apic = &ioapic[id];
	if(apic->useable || (apic->addr = vmap(pa, 1024)) == nil)
		return;
	apic->useable = 1;

	/*
	 * Initialise the IOAPIC.
	 * The MultiProcessor Specification says it is the
	 * responsibility of the O/S to set the APIC ID.
	 */
	ilock(apic);
	r = rtblr(apic->addr, Ioapicver, &r);
	apic->nrdt = ((r>>16) & 0xff) + 1;
	apic->gsib = gsib;
	gsib += apic->nrdt;
	coherence();
	rtblw(apic->addr, Ioapicid, id<<Ioapicnoshft);

	/* clear apic's redirection table */
	for(i = 0; i < apic->nrdt; i++)
		rtblput(apic, i, 0, Im);
	iunlock(apic);
}

void
ioapicdump(void)
{
	int i, n;
	Rdt *rdt;
	Apic *apic;
	ulong hi, lo;

	if(!DBGFLG)
		return;

	for(i = 0; i < Napic; i++){
		apic = &ioapic[i];
		if(!apic->useable || apic->addr == 0)
			continue;
		DBG("ioapic %d addr %#p nrdt %d gsib %d\n",
			i, apic->addr, apic->nrdt, apic->gsib);
		for(n = 0; n < apic->nrdt; n++){
			ilock(apic);
			rtblget(apic, n, &hi, &lo);
			iunlock(apic);
			DBG(" rdt %2.2d %#8.8lux %#8.8lux\n", n, hi, lo);
		}
	}
	for(i = 0; i < Nbus; i++){
		if((rdt = rdtbus[i]) == nil)
			continue;
		DBG("iointr bus %d:\n", i);
		while(rdt != nil){
			DBG(" apic %lld devno %#ux (%d %d) intin %d lo %#lux\n",
				(vlong)(rdt->apic - ioapic), rdt->devno,
				rdt->devno>>2, rdt->devno & 0x03, rdt->intin,
				rdt->lo);
			rdt = rdt->next;
		}
	}
}

/* clear all ioapic interrupt redirections */
void
ioapiconline(void)
{
	int i;
	Apic *apic;

	for(apic = ioapic; apic < &ioapic[Napic]; apic++){
		if(!apic->useable || apic->addr == nil)
			continue;
		ilock(apic);
		for(i = 0; i < apic->nrdt; i++)
			rtblput(apic, i, 0, Im);
		iunlock(apic);
	}
	if(DBGFLG)
		ioapicdump();
}

/*
 * return cpu's apicno and set v->cpu.
 * cpu0 is assumed to be always up and usable.
 * we need xapic for this cpu already set up.
 */
static int
usecpu(Vctl *v, uint cpu)
{
	int apicno;
	Apic *apic;
	extern int cpu0apicno;

	for (apicno = 0; apicno <= Napic; apicno++) {
		apic = &xapic[apicno];
		if (apic->machno != cpu)
			continue;
		if (apicavail(apic)) {
			v->cpu = cpu;
			DBG("usecpu: cpu%d is apic %d\n", cpu, apicno);
			return apicno;
		} else {
			DBG("usecpu: cpu%d: useable %d addr %#p\n",
				cpu, apic->useable, apic->addr);
		}
	}
	if (cpu0apicno >= 0) {
		/* doesn't suffice if we have hyperthreading on */
		v->cpu = 0;
		return cpu0apicno;
	}
	panic("usecpu: cpu%d: no useable apic found", cpu);
}

enum {
	Noisecore,
	Roundrobin,

	Dfpolicy = Roundrobin,
};

int usbpresent;

/*
 * Assign each interrupt to a different CPU on a round-robin.
 * Some idea of the packages/cores/thread topology would be
 * useful here, e.g. to not assign interrupts to more than one
 * thread in a core. But, as usual, Intel make that an onerous task.
 *
 * don't invoke this for usb devices.
 */
int
pickrrcpu(Vctl *v, uint noise)
{
	int cpu, trips;
	Mach *mp;
	static uint df;
	static Lock dflock;

	if (v->cpu >= 0)
		return v->cpu;
	trips = 0;
	DBG("%s %T nmach %d: ", v->name, v->tbdf, sys->nmach);
	lock(&dflock);
	for(;;){
		mp = sys->machptr[df];
		cpu = df++;
		df %= MACHMAX;
		if (++trips > MACHMAX) {
			DBG("looping...");
			cpu = 0;
			break;
		}
		/* this is non-usb, so skip the noise core used for usb */
		if(usbpresent && cpu == noise)
			continue;
		/* don't allow pci devs on cpu0 normally on mp */
		if(sys->nmach > 2 && cpu == 0 && BUSTYPE(v->tbdf) == BusPCI) {
			DBG("skip cpu 0 for pci...");
			continue;
		}
		if (mp == nil)
			DBG("cpu %d off-line so far...", cpu);
		break;			/* all cpus will be on soon */
//		if (mp->online && apicavail(&xapic[mp->apicno])) // TODO
//			break;			/* got a live one */
	}
	DBG(" => cpu %d\n", cpu);
	unlock(&dflock);
	return cpu;
}

/*
 * Set apic delivery mode (lo) and destination field (hi), including cpu choice,
 * according to interrupt routing policy, sets v->lapic.
 *
 * The bulk of this code was written ~1995, when there was
 * one architecture and one generation of hardware, the number
 * of CPUs was up to 4(8) and the choices for interrupt routing
 * were physical, or flat logical (optionally with lowest
 * priority interrupt). Logical mode hasn't scaled well with
 * the increasing number of packages/cores/threads, so the
 * fall-back is to physical mode, which works across all processor
 * generations, both AMD and Intel, using the APIC and xAPIC.
 */
void
pickintrcpu(ulong* hi, ulong* lo, Vctl *v)
{
	int cpu;
	char *name;

	cpu = 0;
	name = v->name;
	switch(Dfpolicy){
	default:
	case Noisecore:
		/* noise core 0 */
		break;
	case Roundrobin:
		/* put COMs & ether0 on cpu0 to simplify rebooting. */
		/* on mp, assign all noisy intr sources (usb) to a noise core */
		if(!MPCAPABLE() || strcmp(name, "COM1") == 0 ||
		    strcmp(name, "ether0") == 0)
			cpu = 0;
		else if (usbpresent && MPCAPABLE() &&
		    strncmp(name, "usb", 3) == 0)
			cpu = sys->nmach - 1;
		else
			cpu = pickrrcpu(v, sys->nmach - 1);
		DBG("%s nmach %d mpcapable %d => cpu %d\n", name, sys->nmach,
			MPCAPABLE(), cpu);
		break;
	}
	*hi = usecpu(v, cpu) << Ioapicnoshft;
	*lo |= Pm | MTf;
	coherence();
}

static Rdt *
getrdtbus(int busno, int devno)
{
	Rdt *rdt;

	for(rdt = rdtbus[busno]; rdt != nil; rdt = rdt->next)
		if(rdt->devno == devno)
			return rdt;
	return nil;
}

int vecinuse(uint);	/* trap.c */

/* return a unique vector number; we don't share vectors in 9k */
static int
newvecno(void)
{
	int vecno, firstvec, first;

	lock(&idtnolock);
	firstvec = idtno;
	first = 1;
	do {
		vecno = idtno;
		if (vecno != firstvec)
			first = 0;
		idtno = (idtno+8) % IdtMAX;
		if(idtno < IdtIOAPIC)
			idtno += IdtIOAPIC;
	} while (vecinuse(vecno) && (first || firstvec != vecno));
	unlock(&idtnolock);

	if (!first && firstvec == vecno)
		panic("newvecno: all vectors in use");
	return vecno;
}

/* return a unique vector number and update rdt */
static int
newvecrdtno(Rdt *rdt)
{
	int vecno;

	if(rdt->lo & 0xff)
		return -1;	/* assume rdt->lo is already set to vector */
	vecno = newvecno();
	rdt->lo |= vecno;
	rdtvecno[vecno] = rdt;
	return vecno;
}

static int
isrbusdev(Vctl *v, int *busnop, int *devnop)
{
	int irq;

	irq = v->irq;
	if(irq >= IdtLINT0 && irq <= IdtSPURIOUS){	/* lapic interrupt? */
		if(irq != IdtSPURIOUS)
			v->isr = apiceoi;
		return 0;
	} else {
		/*
		 * Legacy ISA.  Make a busno and devno using the
		 * ISA bus number and the irq.
		 */
		if(mpisabusno == -1)
			panic("no ISA bus allocated");
		*busnop = mpisabusno;
		*devnop = irq<<2;
		return -1;
	}
}

/*
 * Make busno & devno from BUSDNO(tbdf) and pcidev->intp.
 */
static Pcidev *
pcibusdev(Vctl *v, int *busnop, int *devnop)
{
	int busno, devno;
	Pcidev *pcidev;

	busno = BUSBNO(v->tbdf);
	if((pcidev = pcimatchtbdf(v->tbdf)) == nil)
		panic("no PCI dev for tbdf %#8.8ux", v->tbdf);
	if((devno = pcicfgr8(pcidev, PciINTP)) == 0)
		panic("no INTP for tbdf %#8.8ux", v->tbdf);
	devno = BUSDNO(v->tbdf)<<2 | (devno-1);
	DBG("ioapicintrenable: tbdf %#8.8ux busno %d devno %d\n",
		v->tbdf, busno, devno);
	*busnop = busno;
	*devnop = devno;
	return pcidev;
}

static Rdt *
ioapicrdtbusdev(Vctl *v, int *busnop, int *devnop)
{
	int busno, devno;
	Rdt *rdt;

	busno = *busnop;
	devno = *devnop;
	rdt = getrdtbus(busno, devno);
	if(rdt)
		return rdt;
	/*
	 * First crack in the smooth exterior of the new code:
	 * some BIOS make an MPS table where the PCI devices are
	 * just defaulted to ISA.
	 * Rewrite this to be cleaner.
	 */
	if((busno = mpisabusno) >= 0) {
		devno = v->irq<<2;
		rdt = getrdtbus(busno, devno);
		DBG("isa: tbdf %#8.8ux busno %d devno %d rdt %#p\n",
			v->tbdf, busno, devno, rdt);
		if (rdt == nil)
			print("ioapicrdtbusdev: nil getrdtbus bus %d dev %d\n",
				busno, devno);
	}
	*busnop = busno;
	*devnop = devno;
	return rdt;
}

static int
in8259range(int irq)
{
	/* exclude 0, which probably indicates a missing value, not a timer */
	return irq > 0 && irq <= 15;
}

/* updates rdt->lo */
static int
rdt2vecno(Rdt *rdt)
{
	int vecno;

	vecno = newvecrdtno(rdt);	/* if rdt->lo is 0, update with vecno */
	if (vecno < 0 && rdt->lo & 0xff) {
		/*
		 * ugh.  the vector was probably in use, so try
		 * assigning a new one, overriding rdt->lo.
		 */
		rdt->lo &= ~0xff;
		vecno = newvecrdtno(rdt);
	}
	return vecno;
}

/*
 * configure pcidev for msi mostly without an rdt, if possible, else use i/o
 * apic redirect table
 */
static int
msiorrdt(Vctl *v, Pcidev *pcidev, Rdt *rdt, int vecno)
{
	ulong hi, lo;

	/* we trust that vecno & rdt->lo&0xff are a valid vector or -1 */
	lo = rdt->lo & ~Im;
	if (msinordt(v, pcidev, &hi, &lo, vecno) >= 0)
		return vecno;

	/* no msi: redirect intr to this i/o apic */
	rtblput(rdt->apic, rdt->intin, hi, lo);		/**/
	if (pcidev) {
		pcimsioff(v, pcidev);  /* make sure msi is really off */
		pciintrs(pcidev);
	}
	return lo & 0xff;
}

/*
 * Second crack:
 * what to do about devices that intrenable/intrdisable frequently?
 * doctor: don't do that.
 * 1) there is no ioapicdisable yet;
 * 2) it would be good to reuse freed vectors.
 * Oh bugger.
 *
 * This is a low-frequency event so just lock
 * the whole IOAPIC to initialise the RDT entry
 * rather than putting a Lock in each entry.
 */
static int
msirdtenable(Vctl *v, Pcidev *pcidev, Rdt *rdt)
{
	int vecno;

	lock(rdt->apic);
	vecno = rdt2vecno(rdt);
	if (vecno < 0)
		print("ioapicintrenable: newvecno failed to assign vector for "
			"%s %T\n", v->name, v->tbdf);
	else
		vecno = msiorrdt(v, pcidev, rdt, vecno);
	unlock(rdt->apic);
	return vecno;
}

static int
ioapicisaintron(Vctl *v, int *busnop, int *devnop)
{
	Rdt *rdt;

	if (isrbusdev(v, busnop, devnop) == 0) {
		if (vecinuse(v->irq))
			print("isrbusdev vecno %d in use for %s %T\n",
				v->irq, v->name, v->tbdf);
		return v->irq;		/* we will share the irq */
	}
	rdt = ioapicrdtbusdev(v, busnop, devnop);
	if (rdt == nil) {
		print("ioapicintrenable: %s %T: no pcidev, no rdt\n",
			v->name, v->tbdf);
		return -1;
	}
	return msirdtenable(v, nil, rdt);
}

static int
ioapicpciintron(Vctl *v, Pcidev *pcidev, int *busnop, int *devnop)
{
	Rdt *rdt;
	int vecno;
	ulong hi, lo;

	/* first, try to config pcidev for msi with no rdt */
	lo = newvecno();
	vecno = msinordt(v, pcidev, &hi, &lo, lo);
	if (vecno >= 0)
		return vecno;

	/* no luck with msi, fall back to using rdt */
	rdt = ioapicrdtbusdev(v, busnop, devnop);
	if (rdt == nil)
		return -1;
	return msirdtenable(v, pcidev, rdt);
}

/* may set v->irq */
int
ioapicintrenable(Vctl* v)
{
	int busno, devno, vecno;
	Pcidev *pcidev = nil;

	/* busno and devno are printed when debugging but otherwise unused */
	busno = devno = -1;
	if(v->tbdf == BUSUNKNOWN)		/* includes ISA */
		vecno = ioapicisaintron(v, &busno, &devno);
	else if(BUSTYPE(v->tbdf) == BusPCI) {
		pcidev = pcibusdev(v, &busno, &devno);
		vecno = ioapicpciintron(v, pcidev, &busno, &devno);
	} else
		panic("ioapicintrenable: unknown tbdf %#8.8ux", v->tbdf);
	DBG("busno %d devno %d vecno %d\n", busno, devno, vecno);
	if (vecno < 0)
		return -1;		/* isr and eoi default to a nop */

	v->isr = apicisr;
	v->eoi = apiceoi;
	v->vno = vecno;
	if (!in8259range(v->irq))
		v->irq = vecno;
	if (pcidev && !in8259range(pcidev->intl))
		pcidev->intl = vecno;
	return vecno;
}

/* run through the active ioapics and disable redirections to vector vno */
void
ioapicrtbloff(uint vno)
{
	int i;
	ulong hi, lo;
	Apic *apic;

	for(apic = ioapic; apic < &ioapic[Napic]; apic++)
		if(apic->useable && apic->addr != nil) {
			ilock(apic);
			for(i = 0; i < apic->nrdt; i++) {
				rtblget(apic, i, &hi, &lo);
				if ((lo & MASK(8)) == vno) {
					iprint("apic %#p vector %d was "
						"redirected to %d\n",
						apic, i, vno);
					rtblput(apic, i, 0, 0|Im);
				}
			}
			iunlock(apic);
		}
}

int
ioapicintrtbloff(uint vecno)
{
	Apic *apic;
	Rdt *rdt;

	if(vecno > IdtMAX)
		return -1;
	if((rdt = rdtvecno[vecno]) == nil){
		ioapicrtbloff(vecno);
	} else {
		apic = rdt->apic;
		ilock(apic);
		rtblput(apic, rdt->intin, 0, rdt->lo|Im);
		iunlock(apic);
	}
	return 0;
}

int
ioapicintrdisable(uint vecno)
{
	Apic *apic;
	Rdt *rdt;

	/*
	 * FOV. Oh dear. This isn't very good.
	 * Fortunately rdtvecno[vecno] is static
	 * once assigned.
	 * Must do better.
	 *
	 * What about any pending interrupts?
	 */
	if(vecno > IdtMAX){
		panic("ioapicintrdisable: vecno %d out of range", vecno);
		// return -1;
	}
	if((rdt = rdtvecno[vecno]) == nil){
		panic("ioapicintrdisable: vecno %d has no rdt", vecno);
		// return -1;
	}
	apic = rdt->apic;
	ilock(apic);
	rtblput(apic, rdt->intin, 0, rdt->lo|Im);
	iunlock(apic);

	return 0;
}
