/*
 * process scheduling, including sleep and wakeup
 */
#include	<u.h>
#include	"../port/lib.h"
#include	"mem.h"
#include	"dat.h"
#include	"fns.h"
#include	"../port/error.h"
#include	"../port/edf.h"
#include	"errstr.h"		/* define error strings */
#include	<trace.h>

#define anyready() runvec

enum {
	Measurestack = 1,			/* flag: note max. stack use */
};

int	nrdy;
Ref	noteidalloc;

ulong delayedscheds;	/* statistics */
long skipscheds;
long preempts;

static Ref pidalloc;

struct Procalloc procalloc;

/* ps.c */
extern Proc* psalloc(void);
extern void pshash(Proc*);
extern void psrelease(Proc*);
extern void psunhash(Proc*);

enum
{
	Scaling=2,
};

static void rebalance(void);
static int reprioritize(Proc*);
static void updatecpu(Proc*);

static int schedgain = 30;	/* units in seconds */
static ulong balancetime;

static Lock stkuselock;
static uintptr maxkstackuse;
static uintptr maxmstackuse;

Schedq	runq[Nrq];
ulong	runvec;

char *statename[] =
{	/* BUG: generate automatically */
	"Dead",
	"Moribund",
	"Ready",
	"Scheding",
	"Running",
	"Queueing",
	"QueueingR",
	"QueueingW",
	"Wakeme",
	"Broken",
	"Stopped",
	"Rendez",
	"Waitrelease",
};

/*
 * Always splhi()'ed.
 */
void
schedinit(void)		/* never returns */
{
	Edf *e;

	setlabel(&m->sched);
	if(up) {
		if((e = up->edf) && (e->flags & Admitted))
			edfrecord(up);
		updatecpu(up);
		m->proc = 0;
		switch(up->state) {
		case Running:
			ready(up);
			break;
		case Moribund:
			up->state = Dead;

			/*
			 * Holding locks from pexit:
			 * 	procalloc
			 *	palloc
			 */
			mmurelease(up);
			unlock(&palloc);

			psrelease(up);
			unlock(&procalloc);
			break;
		}
		up->mach = nil;
		up = nil;
	}
	sched();
}

/*
 *  If changing this routine, look also at sleep().  It
 *  contains a copy of the guts of sched().
 */
void
sched(void)
{
	Proc *p;

	if(m->ilockdepth)
		panic("cpu%d: ilockdepth %d, last lock %#p at %#p, sched called from %#p",
			m->machno, m->ilockdepth, up? up->lastilock: nil,
			(up && up->lastilock)? up->lastilock->pc: m->ilockpc,
			getcallerpc(&p+2));

	/* if we are a user process, give up the cpu */
	if(up){
		/*
		 * Delay the sched until the process gives up the locks
		 * it is holding.  This avoids dumb lock loops.
		 * But don't delay if the process is Moribund:
		 * it called sched to die.
		 * But do sched eventually.  This avoids a missing unlock
		 * from hanging the entire kernel.
		 * But don't reschedule procs holding palloc or procalloc.
		 * Those are far too important to be holding while asleep.
		 *
		 * This test is not exact.  There can still be a few
		 * instructions in the middle of taslock when a process
		 * holds a lock but Lock.p has not yet been initialized.
		 */
		coherence();	/* make changes from other cpus visible */
		if(up->nlocks && up->state != Moribund)
		if(up->delaysched < 20 || palloc.Lock.p == up ||
		    procalloc.Lock.p == up){
			up->delaysched++;
			delayedscheds++;
			return;
		}
		up->delaysched = 0;

		splhi();

		/* statistics */
		m->cs++;

		procsave(up);
		if(setlabel(&up->sched)){
			/*
			 *  here when the process is awakened
			 */
			procrestore(up);
			spllo();
			return;
		}
		/*
		 *  here to go to sleep (i.e. stop Running)
		 */
		gotolabel(&m->sched);
		notreached();
	}

	/* not a user process: pick a runnable process and switch to it */
	p = runproc();
	if(!p->edf){
		updatecpu(p);
		p->priority = reprioritize(p);
	}
	/* unless preempted, get to run for at least 100ms */
	if(p != m->readied)
		m->schedticks = m->ticks + HZ/10;
	m->readied = 0;
	up = p;
	up->state = Running;
	up->mach = m;
	m->proc = up;
	mmuswitch(up);
	gotolabel(&up->sched);
	notreached();
}

int
anyhigher(void)
{
	return runvec & ~((1<<(up->priority+1))-1);
}

/*
 *  here once per clock tick to see if we should resched
 */
void
hzsched(void)
{
	/* once a second, rebalance will reprioritize ready procs */
	if(m->machno == 0)
		rebalance();

	/* unless preempted, get to run for at least 100ms */
	if(anyhigher()
	|| (!up->fixedpri && m->ticks > m->schedticks && anyready())){
		m->readied = nil;	/* avoid cooperative scheduling */
		up->delaysched++;
	}
}

/*
 *  here at the end of non-clock interrupts to see if we should preempt the
 *  current process.  Returns 1 if preempted, 0 otherwise.
 */
int
preempted(void)
{
	if(up && up->state == Running && !up->preempted && anyhigher() &&
	    !active.exiting){
		m->readied = nil;	/* avoid cooperative scheduling */
		up->preempted = 1;
		sched();
		splhi();
		up->preempted = 0;
		return 1;
	}
	return 0;
}

/*
 * Update the cpu time average for this particular process,
 * which is about to change from up -> not up or vice versa.
 * p->lastupdate is the last time an updatecpu happened.
 *
 * The cpu time average is a decaying average that lasts
 * about D clock ticks.  D is chosen to be approximately
 * the cpu time of a cpu-intensive "quick job".  A job has to run
 * for approximately D clock ticks before we home in on its
 * actual cpu usage.  Thus if you manage to get in and get out
 * quickly, you won't be penalized during your burst.  Once you
 * start using your share of the cpu for more than about D
 * clock ticks though, your p->cpu hits 1000 (1.0) and you end up
 * below all the other quick jobs.  Interactive tasks, because
 * they basically always use less than their fair share of cpu,
 * will be rewarded.
 *
 * If the process has not been running, then we want to
 * apply the filter
 *
 *	cpu = cpu * (D-1)/D
 *
 * n times, yielding
 *
 *	cpu = cpu * ((D-1)/D)^n
 *
 * but D is big enough that this is approximately
 *
 * 	cpu = cpu * (D-n)/D
 *
 * so we use that instead.
 *
 * If the process has been running, we apply the filter to
 * 1 - cpu, yielding a similar equation.  Note that cpu is
 * stored in fixed point (* 1000).
 *
 * Updatecpu must be called before changing up, in order
 * to maintain accurate cpu usage statistics.  It can be called
 * at any time to bring the stats for a given proc up-to-date.
 */
static void
updatecpu(Proc *p)
{
	int D, n, t, ocpu;

	if(p->edf)
		return;

	t = sys->ticks*Scaling + Scaling/2;
	n = t - p->lastupdate;
	p->lastupdate = t;

	if(n == 0)
		return;
	D = schedgain*HZ*Scaling;
	if(n > D)
		n = D;

	ocpu = p->cpu;
	if(p != up)
		p->cpu = (ocpu*(D-n))/D;
	else{
		t = 1000 - ocpu;
		p->cpu = 1000 - (t*(D-n))/D;
	}

//	iprint("pid %d %s for %d cpu %d -> %d\n", p->pid,
//		p==up? "active": "inactive", n, ocpu, p->cpu);
}

/*
 * On average, p has used p->cpu of a cpu recently.
 * Its fair share is sys->nonline/m->load of a cpu.  If it has been getting
 * too much, penalize it.  If it has been getting not enough, reward it.
 * I don't think you can get much more than your fair share that
 * often, so most of the queues are for using less.  Having a priority
 * of 3 means you're just right.  Having a higher priority (up to p->basepri)
 * means you're not using as much as you could.
 */
static int
reprioritize(Proc *p)
{
	int fairshare, load, ratio;
	uint n;

	load = sys->machptr[0]->load;
	if(load == 0)
		return p->basepri;

	/*
	 *  fairshare = 1.000 * sys->nonline * 1.000/load,
	 * except the decimal point is moved three places
	 * on both load and fairshare.
	 */
	fairshare = (sys->nonline*1000*1000)/load;
	n = p->cpu;
	if(n == 0)
		n = 1;
	ratio = (fairshare+n/2) / n;
	if(ratio > p->basepri)
		ratio = p->basepri;
	if(ratio < 0)
		panic("reprioritize");
//	iprint("pid %d cpu %d load %d fair %d pri %d\n", p->pid, p->cpu, load,
//		fairshare, ratio);
	return ratio;
}

/*
 * add a process to a scheduling queue
 */
void
queueproc(Schedq *rq, Proc *p)
{
	int pri;
	Proc *rqtl;

	pri = rq - runq;
	lock(runq);			/* locks runq[0] */
	p->priority = pri;
	p->rnext = 0;
	rqtl = rq->tail;
	if(rqtl)
		rqtl->rnext = p;
	else
		rq->head = p;
	rq->tail = p;
	rq->n++;
	nrdy++;
	runvec |= 1<<pri;
	unlock(runq);
}

/*
 *  try to remove a process from a scheduling queue (called splhi)
 */
Proc*
dequeueproc(Schedq *rq, Proc *tp)
{
	Proc *l, *p;

	if(!canlock(runq))
		return nil;

	/*
	 *  the queue may have changed before we locked runq,
	 *  refind the target process.
	 */
	l = 0;
	for(p = rq->head; p; p = p->rnext){
		if(p == tp)
			break;
		l = p;
	}

	/*
	 *  p->mach==0 only when process state is saved
	 */
	if(p == 0 || p->mach){
		unlock(runq);
		return nil;
	}
	if(p->rnext == 0)
		rq->tail = l;
	if(l)
		l->rnext = p->rnext;
	else
		rq->head = p->rnext;
	if(rq->head == nil)
		runvec &= ~(1 << (rq - runq));
	rq->n--;
	nrdy--;
	if(p->state != Ready)
		print("dequeueproc %s %d %s\n", p->text, p->pid, statename[p->state]);

	unlock(runq);
	return p;
}

/*
 *  ready(p) picks a new priority for a process and sticks it in the
 *  runq for that priority.
 */
void
ready(Proc *p)
{
	Mreg s;
	int pri;
	void (*pt)(Proc*, int, vlong);

	s = splhi();
	if(edfready(p)){
		splx(s);
		/* calling idlewake here costs system & real time */
		return;
	}

	/* m must be MACHP(m->machno) instead on 386 */
	if(up != p && (p->wired == nil || p->wired == m))
		m->readied = p;		/* group scheduling */

	updatecpu(p);
	p->priority = pri = reprioritize(p);
	p->state = Ready;
	queueproc(&runq[pri], p);

	pt = proctrace;
	if(pt)
		pt(p, SReady, 0);
	splx(s);
	/* calling idlewake here costs system & real time */
}

/*
 *  yield the processor and drop our priority
 */
void
yield(void)
{
	if(anyready()){
		/* pretend we just used 1/2 tick */
		up->lastupdate -= Scaling/2;
		sched();
	}
}

/*
 *  recalculate priorities once a second.  We need to do this
 *  since priorities will otherwise only be recalculated when
 *  the running process blocks.
 *  only called on cpu0.
 */
static void
rebalance(void)
{
	Mreg s;
	int pri, npri, t;
	Schedq *rq;
	Proc *p;

	t = m->ticks;
	if(t - balancetime < HZ)
		return;
	balancetime = t;

	coherence();	/* make changes from other cpus visible */
	for(pri=0, rq=runq; pri<Npriq; pri++, rq++){
another:
		p = rq->head;
		if(p == nil)
			continue;
		/* don't do this; we'd only rebalance cpu0 procs */
#ifdef bad_idea
		if(p->mp != MACHP(m->machno))
			continue;
#endif
		if(pri == p->basepri)
			continue;
		updatecpu(p);
		npri = reprioritize(p);
		if(npri != pri){
			s = splhi();
			p = dequeueproc(rq, p);
			if(p)
				queueproc(&runq[npri], p);
			splx(s);
			goto another;
		}
	}
}


/*
 * these assume that active.Lock is held when needed.
 * we never activate more than MACHMAX cpus, so we needn't check
 * active.machsmap's bounds.
 */

void
cpuactive(uint cpu)
{
	ulong bit, wd;

	bit = 1UL << (cpu % BI2WD);
	wd = cpu / BI2WD;
	if ((active.machsmap[wd] & bit) == 0) {
		active.machsmap[wd] |= bit;
		sys->nonline++;
	}
}

void
cpuinactive(uint cpu)
{
	ulong bit, wd;

	bit = 1UL << (cpu % BI2WD);
	wd = cpu / BI2WD;
	if (active.machsmap[wd] & bit) {
		active.machsmap[wd] &= ~bit;
		if (sys->nonline > 0)
			sys->nonline--;
	}
}

int
iscpuactive(uint cpu)
{
	return (active.machsmap[cpu / BI2WD] & (1UL << (cpu % BI2WD))) != 0;
}


/*
 *  pick a process to run
 */
Proc*
runproc(void)
{
	Schedq *rq;
	Proc *p;
	ulong start, now;
	int i;
	void (*pt)(Proc*, int, vlong);

	start = perfticks();

	/* cooperative scheduling until the clock ticks */
	coherence();	/* make changes from other cpus visible */
	if((p = m->readied) && p->mach==0 && p->state==Ready
	&& (p->wired == nil || p->wired == m)
	&& runq[Nrq-1].head == nil && runq[Nrq-2].head == nil){
		skipscheds++;
		rq = &runq[p->priority];
		goto found;
	}
	preempts++;

loop:
	/*
	 *  find a process that last ran on this processor (affinity),
	 *  or one that hasn't moved in a while (load balancing).  Every
	 *  time around the loop affinity goes down.
	 */
	spllo();
	for(i = 0;; i++){
		/*
		 *  find the highest priority target process that this
		 *  processor can run given affinity constraints.
		 */
		locknote();	/* watch monitored word; TODO: keep on 9k? */
		for(rq = &runq[Nrq-1]; rq >= runq; rq--)
			for(p = rq->head; p; p = p->rnext)
				if(p->mp == nil || p->mp == m
				|| (!p->wired && i > 0))
					goto found;

		/* waste time or halt the CPU */
		idlehands();

		/* remember how much time we're here */
		now = perfticks();
		m->perf.inidle += now-start;
		start = now;
	}

found:
	splhi();
	p = dequeueproc(rq, p);
	if(p == nil)
		goto loop;

	p->state = Scheding;
	p->mp = m;

	if(edflock(p)){
		edfrun(p, rq == &runq[PriEdf]);	/* start deadline timer, do admin */
		edfunlock();
	}
	pt = proctrace;
	if(pt)
		pt(p, SRun, 0);
	return p;
}

#ifdef unused
int
canpage(Proc *p)			/* unused; dreg from swapping */
{
	int ok;

	ilock(runq);
	/* Only reliable way to see if we are not Running */
	ok = p->mach == 0;
	if(ok)
		p->newtlb = 1;
	iunlock(runq);
	return ok;
}
#endif

Proc*
newproc(void)
{
	Proc *p;

	p = psalloc();

	p->state = Scheding;
	p->psstate = "New";
	p->mach = 0;
	p->qnext = 0;
	p->nchild = 0;
	p->nwait = 0;
	p->waitq = 0;
	p->parent = 0;
	p->pgrp = 0;
	p->egrp = 0;
	p->fgrp = 0;
	p->rgrp = 0;
	p->pdbg = 0;
	p->kp = 0;
	if(up != nil && up->procctl == Proc_tracesyscall)
		p->procctl = Proc_tracesyscall;
	else
		p->procctl = 0;
	p->syscalltrace = nil;
	p->notepending = 0;
	p->ureg = 0;
	p->privatemem = 0;
	p->errstr = p->errbuf0;
	p->syserrstr = p->errbuf1;
	p->errbuf0[0] = '\0';
	p->errbuf1[0] = '\0';
	p->nlocks = 0;
	p->delaysched = 0;
	p->trace = 0;
	kstrdup(&p->user, "*nouser");
	kstrdup(&p->text, "*notext");
	kstrdup(&p->args, "");
	p->nargs = 0;
	p->setargs = 0;
	memset(p->seg, 0, sizeof p->seg);
	p->pid = incref(&pidalloc);
	pshash(p);
	p->noteid = incref(&noteidalloc);
	if(p->pid <= 0 || p->noteid <= 0)
		panic("pidalloc");
	if(p->kstack == 0)
		p->kstack = smalloc(KSTACK);

	/* sched params */
	p->mp = 0;
	p->wired = 0;
	procpriority(p, PriNormal, 0);
	p->cpu = 0;
	p->lastupdate = sys->ticks*Scaling;
	p->edf = nil;

	return p;
}

/*
 * wire this proc to a machine
 */
void
procwired(Proc *p, int bm)
{
	Proc *pp;
	int i;
	char nwired[MACHMAX];
	Mach *wm, *mp;

	if(bm < 0){
		/* pick a machine to wire to */
		memset(nwired, 0, sizeof(nwired));
		p->wired = 0;
		for(i=0; (pp = psincref(i)) != nil; i++){
			wm = pp->wired;
			if(wm && pp->pid)
				nwired[wm->machno]++;
			psdecref(pp);
		}
		bm = 0;
		for(i=0; i< sys->nonline; i++)
			if((mp = sys->machptr[i]) != nil && mp->online &&
			    nwired[i] < nwired[bm])
				bm = i;
	} else
		/* use the cpu requested, if available */
		bm %= sys->nonline;
	mp = sys->machptr[bm];
	if (mp == nil || !mp->online)
		bm = 0;			/* don't really expect this to happen */
	p->mp = p->wired = sys->machptr[bm];
}

void
procpriority(Proc *p, int pri, int fixed)
{
	if(pri >= Npriq)
		pri = Npriq - 1;
	else if(pri < 0)
		pri = 0;
	p->basepri = p->priority = pri;
	p->fixedpri = (fixed != 0);
}

/*
 * Note carefully these words from /sys/doc/sleep.ms:
 *
 * We assume that a particular call to sleep corresponds to a particular
 * call to wakeup, that is, at most one process is asleep waiting for a
 * particular event.  This can be guaranteed in the code that calls sleep
 * and wakeup by appropriate interlocks.
 */

/*
 *  sleep if a condition, (*f)(arg), is not true.  Another process will
 *  awaken us after it sets the condition.  When we awaken
 *  the condition may no longer be true.
 *
 *  we lock both the process and the rendezvous to keep r->p
 *  and p->r synchronized.
 */
void
sleep(Rendez *r, int (*f)(void*), void *arg)
{
	Mreg s;
	void (*pt)(Proc*, int, vlong);

	s = splhi();

	if(up->nlocks)
		print("process %d sleeps with %d locks held, last lock %#p "
			"locked at pc %#p, sleep called from %#p\n",
			up->pid, (int)up->nlocks, up->lastlock, up->lastlock->pc,
			getcallerpc(&r));
	lock(r);
	lock(&up->rlock);
	if(r->p){
		print("double sleep called from %#p, %d %d\n",
			getcallerpc(&r), r->p->pid, up->pid);
		dumpstack();
	}

	/*
	 *  Wakeup only knows there may be something to do by testing
	 *  r->p in order to get something to lock on.
	 *  Flush that information out to memory in case the sleep is
	 *  committed.
	 */
	r->p = up;

	/* f must not sleep; we're holding Locks */
	if((*f)(arg) || up->notepending){
		/*
		 *  if condition happened or a note is pending
		 *  never mind
		 */
		r->p = nil;
		unlock(&up->rlock);
		unlock(r);
	} else {
		/*
		 *  now we are committed to
		 *  change state and call scheduler
		 */
		pt = proctrace;
		if(pt)
			pt(up, SSleep, 0);
		up->state = Wakeme;
		up->r = r;

		/* statistics */
		m->cs++;

		procsave(up);
		if(setlabel(&up->sched)) {
			/*
			 *  here when the process is awakened,
			 *  holding no Locks.
			 */
			procrestore(up);
			spllo();
		} else {
			/*
			 *  here to go to sleep (i.e. stop Running)
			 *  after releasing Locks.
			 */
			unlock(&up->rlock);
			unlock(r);
			gotolabel(&m->sched);
			notreached();
		}
	}

	if(up->notepending) {
		up->notepending = 0;
		splx(s);
		if(up->procctl == Proc_exitme && up->closingfgrp)
			forceclosefgrp();
		error(Eintr);
	}

	splx(s);
}

static int
tfn(void *arg)
{
	return up->trend == nil || up->tfn(arg);
}

void
twakeup(Ureg*, Timer *t)
{
	Proc *p;
	Rendez *trend;

	p = t->ta;
	trend = p->trend;
	p->trend = 0;
	if(trend)
		wakeup(trend);
}

void
tsleep(Rendez *r, int (*fn)(void*), void *arg, long ms)
{
	if (up->tt){
		print("tsleep: timer active: mode %d, tf %#p\n",
			up->tmode, up->tf);
		timerdel(up);
	}
	up->tns = MS2NS(ms);
	up->tf = twakeup;
	up->tmode = Trelative;
	up->ta = up;
	up->trend = r;
	up->tfn = fn;
	timeradd(up);

	if(waserror()){
		timerdel(up);
		nexterror();
	}
	sleep(r, tfn, arg);
	if (up->tt)
		timerdel(up);
	up->twhen = 0;
	poperror();
}

/*
 *  Expects that only one process can call wakeup for any given Rendez.
 *  We hold both locks to ensure that r->p and p->r remain consistent.
 *  Richard Miller has a better solution that doesn't require both to
 *  be held simultaneously, but I'm a paranoid - presotto.
 */
Proc*
wakeup(Rendez *r)
{
	Mreg s;
	Proc *p;

	s = splhi();

	lock(r);
	p = r->p;

	if(p == nil)
		unlock(r);
	else {
		lock(&p->rlock);
		if(p->state != Wakeme || p->r != r)
			panic("wakeup: %#p %#p state %d", p->r, r, p->state);
		r->p = nil;
		p->r = nil;
		unlock(r);
		ready(p);		/* just change p's state, don't sleep */
		unlock(&p->rlock);
	}

	splx(s);

	return p;
}

/*
 *  if waking a sleeping process, this routine must hold both
 *  p->rlock and r->lock.  However, it can't hold them in
 *  the same order as wakeup, causing a possible lock ordering
 *  deadlock.  We break the deadlock by giving up the p->rlock
 *  lock if we can't get the r->lock and retrying.
 */
int
postnote(Proc *p, int dolock, char *n, int flag)
{
	Mreg s;
	int ret;
	Rendez *r;
	Proc *d, **l;

	if(dolock) {
		if(m->ilockdepth != 0)
			panic("postnote: caller %#p: ilockdepth %d note %s",
				getcallerpc(&p), m->ilockdepth, n);
		qlock(&p->debug);
	}

	if(flag != NUser && (p->notify == 0 || p->notified))
		p->nnote = 0;

	ret = 0;
	if(p->nnote < NNOTE) {
		strncpy(p->note[p->nnote].msg, n, ERRMAX);
		p->note[p->nnote++].flag = flag;
		ret = 1;
	}
	p->notepending = 1;
	if(dolock)
		qunlock(&p->debug);

	/* this loop is to avoid lock ordering problems. */
	for(;;){
		s = splhi();
		lock(&p->rlock);
		r = p->r;

		/* waiting for a wakeup? */
		if(r == nil)
			break;	/* no */

		/* try for the second lock */
		if(canlock(r)){
			if(p->state != Wakeme || r->p != p)
				panic("postnote: state %d %d %d",
					r->p != p, p->r != r, p->state);
			p->r = nil;
			r->p = nil;
			/*
			 * The unlock must precede ready(p), in case the readied
			 * process immediately deallocates the Rendez.  This can
			 * happen with semacquire, where the Rendez is on the
			 * stack.  (A Rendez in a user stack segment is a bad
			 * idea, of course, since it can't be shared by multiple
			 * processes.)
			 */
			unlock(r);
			ready(p);
			break;
		}

		/* give other process time to get out of critical section and try again */
		unlock(&p->rlock);
		splx(s);
		sched();
	}
	unlock(&p->rlock);
	splx(s);

	if(p->state != Rendezvous)
		return ret;

	/* Try and pull out of a rendezvous */
	lock(p->rgrp);
	if(p->state == Rendezvous) {
		p->rendval = ~0ull;
		l = &REND(p->rgrp, p->rendtag);
		for(d = *l; d; d = d->rendhash) {
			if(d == p) {
				*l = p->rendhash;
				break;
			}
			l = &d->rendhash;
		}
		ready(p);
	}
	unlock(p->rgrp);
	return ret;
}

/*
 * weird thing: keep at most NBROKEN around
 */
#define	NBROKEN 4
struct
{
	QLock;
	int	n;
	Proc	*p[NBROKEN];
}broken;

void
addbroken(Proc *p)
{
	qlock(&broken);
	if(broken.n == NBROKEN) {
		ready(broken.p[0]);
		memmove(&broken.p[0], &broken.p[1], sizeof(Proc*)*(NBROKEN-1));
		--broken.n;
	}
	broken.p[broken.n++] = p;
	qunlock(&broken);

	edfstop(up);
	p->state = Broken;
	p->psstate = 0;
	sched();
}

void
unbreak(Proc *p)
{
	int b;

	qlock(&broken);
	for(b=0; b < broken.n; b++)
		if(broken.p[b] == p) {
			broken.n--;
			memmove(&broken.p[b], &broken.p[b+1],
				sizeof(Proc*) * (NBROKEN-(b+1)));
			ready(p);
			break;
		}
	qunlock(&broken);
}

int
freebroken(void)
{
	int i, n;

	qlock(&broken);
	n = broken.n;
	for(i=0; i<n; i++) {
		ready(broken.p[i]);
		broken.p[i] = 0;
	}
	broken.n = 0;
	qunlock(&broken);
	return n;
}

static void
pexitfree(void)
{
	Fgrp *fgrp;
	Egrp *egrp;
	Rgrp *rgrp;
	Pgrp *pgrp;
	Chan *dot;

	/* nil out all the proc's resources under lock (free later) */
	/* NB: does not free up->kstack; reuse it later */
	qlock(&up->debug);
	fgrp = up->fgrp;
	up->fgrp = nil;
	egrp = up->egrp;
	up->egrp = nil;
	rgrp = up->rgrp;
	up->rgrp = nil;
	pgrp = up->pgrp;
	up->pgrp = nil;
	dot = up->dot;
	up->dot = nil;
	qunlock(&up->debug);

	if(fgrp)
		closefgrp(fgrp);
	if(egrp)
		closeegrp(egrp);
	if(rgrp)
		closergrp(rgrp);
	if(dot)
		cclose(dot);
	if(pgrp)
		closepgrp(pgrp);
}

static void
pexituser(char *exitstr)
{
	Proc *p;
	long utime, stime;
	Waitq *wq;

	p = up->parent;
	if(p == 0) {			/* must be init (process 1) */
		if(exitstr == 0)
			exitstr = "unknown";
		panic("boot process died: %s", exitstr);
	}

	while(waserror())
		;

	wq = smalloc(sizeof(Waitq));
	poperror();

	wq->w.pid = up->pid;
	utime = up->time[TUser] + up->time[TCUser];
	stime = up->time[TSys] + up->time[TCSys];
	wq->w.time[TUser] = tk2ms(utime);
	wq->w.time[TSys] = tk2ms(stime);
	wq->w.time[TReal] = tk2ms(sys->ticks - up->time[TReal]);
	if(exitstr && exitstr[0])
		snprint(wq->w.msg, sizeof(wq->w.msg), "%s %d: %s",
			up->text, up->pid, exitstr);
	else
		wq->w.msg[0] = '\0';

	lock(&p->exl);
	/*
	 * Check that parent is still alive.
	 */
	if(p->pid == up->parentpid && p->state != Broken) {
		p->nchild--;
		p->time[TCUser] += utime;
		p->time[TCSys] += stime;
		/*
		 * If there would be more than 128 wait records
		 * processes for my parent, then don't leave a wait
		 * record behind.  This helps prevent badly written
		 * daemon processes from accumulating lots of wait
		 * records.
	 	 */
		if(p->nwait < 128) {
			wq->next = p->waitq;
			p->waitq = wq;
			p->nwait++;
			wq = nil;
			wakeup(&p->waitr);
		}
	}
	unlock(&p->exl);
	if(wq)
		free(wq);
}

static void
pexitprstkmax(void)
{
	print("max Proc stack use %lld Mach stack use %lld\n",
		(uvlong)maxkstackuse, (uvlong)maxmstackuse);
}

void	(*prstackmax)(void) = pexitprstkmax;

uintptr
stackuse(char *stkbot, char *stktop)
{
	uvlong *bot;

	bot = (uvlong *)ROUNDUP((uintptr)stkbot, BY2V);
	for (; bot < (uvlong *)stktop && *bot == 0; ++bot)
		;
	/* bot is lowest uvlong used in the stack */
	return stktop - (char *)bot;
}

static void
pexitrecstk(void)
{
	uvlong cpu;
	uintptr kused, mused, used;
	Mach *mp;

	kused = stackuse(up->kstack, up->kstack + KSTACK);

	/* find biggest Mach stack on all cpus */
	mp = sys->machptr[0];
	mused = stackuse((char *)mp->stack, (char *)mp->stack + MACHSTKSZ);
	for (cpu = 1; cpu < MACHMAX; cpu++) {
		mp = sys->machptr[cpu];
		if (mp == nil || !mp->online)
			continue;
		used = stackuse((char *)mp->stack, (char *)mp->stack + MACHSTKSZ);
		if (used > mused)
			mused = used;
	}

	lock(&stkuselock);
	if (kused > maxkstackuse)
		maxkstackuse = kused;
	if (mused > maxmstackuse)
		maxmstackuse = mused;
	unlock(&stkuselock);
}

void
pexit(char *exitstr, int freemem)
{
	Segment **s, **es;
	Waitq *f, *next;
	void (*pt)(Proc*, int, vlong);

	if(up->syscalltrace != nil)
		free(up->syscalltrace);
	up->syscalltrace = nil;
	up->alarm = 0;
	if (up->tt)
		timerdel(up);
	pt = proctrace;
	if(pt)
		pt(up, SDead, 0);

	if (Measurestack)
		pexitrecstk();
	pexitfree();

	/*
	 * if not a kernel process and have a parent,
	 * do some housekeeping.
	 */
	if(up->kp == 0 && up->parentpid != 0)
		pexituser(exitstr);

	if(!freemem)
		addbroken(up);

	qlock(&up->seglock);
	es = &up->seg[NSEG];
	for(s = up->seg; s < es; s++)
		if(*s) {
			putseg(*s);
			*s = 0;
		}
	qunlock(&up->seglock);

	lock(&up->exl);		/* Prevent my children from leaving waits */
	psunhash(up);
	up->pid = 0;
	wakeup(&up->waitr);
	unlock(&up->exl);

	for(f = up->waitq; f; f = next) {
		next = f->next;
		free(f);
	}

	/* release debuggers */
	qlock(&up->debug);
	if(up->pdbg) {
		wakeup(&up->pdbg->sleep);
		up->pdbg = 0;
	}
	qunlock(&up->debug);

	edfstop(up);
	if(up->edf){
		free(up->edf);
		up->edf = nil;
	}

	/* Sched must not loop for these locks */
	lock(&procalloc);
	lock(&palloc);

	up->state = Moribund;
	sched();
	panic("pexit");
}

int
haswaitq(void *x)
{
	Proc *p;

	p = (Proc *)x;
	return p->waitq != 0;
}

int
pwait(Waitmsg *w)
{
	int cpid;
	Waitq *wq;

	if(!canqlock(&up->qwaitr))
		error(Einuse);

	if(waserror()) {
		qunlock(&up->qwaitr);
		nexterror();
	}

	lock(&up->exl);
	if(up->nchild == 0 && up->waitq == 0) {
		unlock(&up->exl);
		error(Enochild);
	}
	unlock(&up->exl);

	sleep(&up->waitr, haswaitq, up);

	lock(&up->exl);
	wq = up->waitq;
	up->waitq = wq->next;
	up->nwait--;
	unlock(&up->exl);

	qunlock(&up->qwaitr);
	poperror();

	if(w)
		memmove(w, &wq->w, sizeof(Waitmsg));
	cpid = wq->w.pid;
	free(wq);

	return cpid;
}

void
dumpaproc(Proc *p)
{
	uintptr bss;
	char *s;

	if(p == 0)
		return;

	bss = 0;
	if(p->seg[BSEG])
		bss = p->seg[BSEG]->top;

	s = p->psstate;
	if(s == 0)
		s = statename[p->state];
	print("%3d:%10s pc %#p dbgpc %#p  %8s (%s) ut %ld st %ld bss %#p "
		"qpc %#p nl %d nd %lud lpc %#p pri %lud\n",
		p->pid, p->text, p->pc, dbgpc(p), s, statename[p->state],
		p->time[0], p->time[1], bss, p->qpc, (int)p->nlocks,
		p->delaysched, p->lastlock ? p->lastlock->pc : 0, p->priority);
}

void
procdump(void)
{
	int i;
	Proc *p;

	if(up)
		print("up %d\n", up->pid);
	else
		print("no current process\n");
	for(i=0; (p = psincref(i)) != nil; i++) {
		if(p->state != Dead)
			dumpaproc(p);
		psdecref(p);
	}
}

/*
 *  wait till all processes have flushed their mmu
 *  state about segment s
 */
void
procflushseg(Segment *s)
{
	int i, ns, nm, nwait;
	Proc *p;
	Mach *mp;

	/*
	 *  tell all processes with this
	 *  segment to flush their processor's mmus
	 */
	nwait = 0;
	for(i=0; (p = psincref(i)) != nil; i++) {
		if(p->state == Dead){
			psdecref(p);
			continue;
		}
		for(ns = 0; ns < NSEG; ns++)
			if(p->seg[ns] == s){
				p->newtlb = 1;
				for(nm = 0; nm < sys->nonline; nm++)
					if((mp = sys->machptr[nm]) != nil &&
					    mp->online && mp->proc == p){
						mp->mmuflush = 1;
						nwait++;
					}
				break;
			}
		psdecref(p);
	}
	if(nwait == 0)
		return;

	/*
	 *  wait for all other processors to take a clock interrupt
	 *  and flush their mmus
	 */

	/* alternate scheme: remember this cpu's # or m, scan the others */
again:
	/* could be shutting down, so use MACHMAX not sys->nonline */
	for(i = 0; i < MACHMAX; i++)
		if((mp = sys->machptr[i]) != nil && mp->online && mp != m &&
		    mp->mmuflush) {
			sched();
			/* we may be running on a different cpu now */
			goto again;
		}
		/*
		 * we've reverted to essentially the 9 code, because previous
		 * 9k code did this, but sched may change cpu, thus m, so
		 * could miss a cpu because it doesn't start over at again:
		 *	while(mp->mmuflush)
		 *		sched();
		 */
}

void
scheddump(void)
{
	Proc *p;
	Schedq *rq;

	for(rq = &runq[Nrq-1]; rq >= runq; rq--){
		if(rq->head == 0)
			continue;
		print("rq%lld:", (vlong)(rq - runq));
		for(p = rq->head; p; p = p->rnext)
			print(" %d(%lud)", p->pid, m->ticks - p->readytime);
		print("\n");
		delay(150);
	}
	print("nrdy %d\n", nrdy);
}

void
kproc(char *name, void (*func)(void *), void *arg)
{
	Proc *p;
	static Pgrp *kpgrp;

	p = newproc();
	p->psstate = 0;
	p->procmode = 0640;
	p->kp = 1;

	p->scallnr = up->scallnr;
	memmove(p->arg.arg, up->arg.arg, sizeof(up->arg.arg));
	p->nerrlab = 0;
	p->slash = up->slash;
	p->dot = up->dot;
	if(p->dot)
		incref(p->dot);

	memmove(p->note, up->note, sizeof(p->note));
	p->nnote = up->nnote;
	p->notified = 0;
	p->lastnote = up->lastnote;
	p->notify = up->notify;
	p->ureg = 0;
	p->dbgreg = 0;

	/* ether kproc? */
	if (strncmp(name, "#l", 2) == 0 || strncmp(name, "ether", 5) == 0)
		procpriority(p, PriKproc+2, 0);	/* give extra zing */
	else
		procpriority(p, PriKproc, 0);

	kprocchild(p, func, arg);

	kstrdup(&p->user, eve);
	kstrdup(&p->text, name);
	if(kpgrp == 0)
		kpgrp = newpgrp();
	p->pgrp = kpgrp;
	incref(kpgrp);

	memset(p->time, 0, sizeof(p->time));
	p->time[TReal] = sys->ticks;
	/*
	 *  since the bss/data segments are now shareable,
	 *  any mmu info about this process is now stale
	 *  and has to be discarded.
	 */
	p->newtlb = 1;
	mmuflush();
	ready(p);
}

/*
 *  called splhi() by notify().  See comment in notify for the
 *  reasoning.
 */
void
procctl(Proc *p)
{
	Mreg s;
	char *state;

	switch(p->procctl) {
	case Proc_exitbig:
		spllo();
		pexit("Killed: Insufficient physical memory", 1);

	case Proc_exitme:
		spllo();		/* pexit has locks in it */
		pexit("Killed", 1);

	case Proc_traceme:
		if(p->nnote == 0)
			return;
		/* No break */

	case Proc_stopme:
		p->procctl = 0;
		state = p->psstate;
		p->psstate = "Stopped";
		/* free a waiting debugger */
		s = spllo();
		qlock(&p->debug);
		if(p->pdbg) {
			wakeup(&p->pdbg->sleep);
			p->pdbg = 0;
		}
		qunlock(&p->debug);
		splhi();
		p->state = Stopped;
		sched();
		p->psstate = state;
		splx(s);
		return;
	}
}

void
error(char *err)
{
	spllo();

	if (up == nil)
		panic("error: called from %#p with nil up for: %s",
			getcallerpc(&err), err);
	assert(up->nerrlab < NERR);
	kstrcpy(up->errstr, err, ERRMAX);
	setlabel(&up->errlab[NERR-1]);
	nexterror();
}

void
nexterror(void)
{
	gotolabel(&up->errlab[--up->nerrlab]);
}

void
exhausted(char *resource)
{
	char buf[ERRMAX];

	snprint(buf, sizeof buf, "no free %s", resource);
	iprint("%s\n", buf);
	error(buf);
}

void
killbig(char *why)
{
	int i, x;
	Segment *s;
	ulong l, max;
	Proc *p, *kp;

	max = 0;
	kp = nil;
	for(x = 0; (p = psincref(x)) != nil; x++) {
		if(p->state == Dead || p->kp){
			psdecref(p);
			continue;
		}
		l = 0;
		for(i=1; i<NSEG; i++) {
			s = p->seg[i];
			if(s != nil)
				l += s->top - s->base;
		}
		if(l > max && ((p->procmode&0222) || strcmp(eve, p->user)!=0)) {
			if(kp != nil)
				psdecref(kp);
			kp = p;
			max = l;
		}
		else
			psdecref(p);
	}
	if(kp == nil)
		return;

	print("%d: %s killed: %s\n", kp->pid, kp->text, why);
	for(x = 0; (p = psincref(x)) != nil; x++) {
		if(p->state == Dead || p->kp){
			psdecref(p);
			continue;
		}
		if(p != kp && p->seg[BSEG] && p->seg[BSEG] == kp->seg[BSEG])
			p->procctl = Proc_exitbig;
		psdecref(p);
	}

	kp->procctl = Proc_exitbig;
	for(i = 0; i < NSEG; i++) {
		s = kp->seg[i];
		if(s != nil && canqlock(&s->lk)) {
			mfreeseg(s, s->base, s->top);
			qunlock(&s->lk);
		}
	}
	psdecref(kp);
}

/*
 *  change ownership to 'new' of all processes owned by 'old'.  Used when
 *  eve changes.
 */
void
renameuser(char *old, char *new)
{
	int i;
	Proc *p;

	for(i = 0; (p = psincref(i)) != nil; i++){
		if(p->user!=nil && strcmp(old, p->user)==0)
			kstrdup(&p->user, new);
		psdecref(p);
	}
}

#define HZDECAY(avg, new) ((avg) = ((avg)*(HZ-1LL) + (new)) / HZ)

/*
 *  time accounting called by hzclock() splhi'd
 */
void
accounttime(void)
{
	Proc *p;
	ulong n, per;
	static ulong nrun;

	p = m->proc;
	if(p) {
		nrun++;
		p->time[p->insyscall]++;
	}

	/* calculate decaying duty cycles */
	n = perfticks();
	per = n - m->perf.last;
	m->perf.last = n;
	per = (m->perf.period*(HZ-1) + per)/HZ;
	if(per != 0)
		m->perf.period = per;

	m->perf.avg_inidle = ((uvlong)m->perf.avg_inidle*(HZ-1)+m->perf.inidle)
		/ HZ;
	m->perf.inidle = 0;

	m->perf.avg_inintr = ((uvlong)m->perf.avg_inintr*(HZ-1)+m->perf.inintr)
		/ HZ;
	m->perf.inintr = 0;

	/* only one processor gets to compute system load averages */
	if(m->machno != 0)
		return;

	/*
	 * calculate decaying load average.
	 * if we decay by (n-1)/n then it takes
	 * n clock ticks to go from load L to .36 L once
	 * things quiet down.  it takes about 5 n clock
	 * ticks to go to zero.  so using HZ means this is
	 * approximately the load over the last second,
	 * with a tail lasting about 5 seconds.
	 */
	n = nrun;
	nrun = 0;
	n = (nrdy+n)*1000;
	m->load = (m->load*(HZ-1)+n)/HZ;
}

/*
 * wait for *vp to change from val, or for an interrupt, on machines
 * that lack monitor & mwait instructions.
 * shouldn't be needed on hardware; VMs might need it.
 */
int
portwaitfor(long *vp, int val)
{
	int i;
	Proc *restpl;
	Mpl s;

	if (!MPSRUNNING())
		halt();
	else {
		s = 0;
		restpl = up;
		if (up)	/* this cpu is scheduling, thus done initialising? */
			s = spllo();
		/*
		 * How many times round this loop?
		 */
		for(i = 10000; *vp == val && i > 0; i--)
			pause();
		if (restpl)
			splx(s);
	}
	return *vp;
}
