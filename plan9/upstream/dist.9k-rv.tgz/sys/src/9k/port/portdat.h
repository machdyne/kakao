/*
 * 9k (64-bit) data structures
 */
#define PLAN9K 	1			/* use sparingly */
#define flushmmu	mmuflush	/* use 9k name */

typedef struct Alarms	Alarms;
typedef struct Block	Block;
typedef struct Chan	Chan;
typedef struct Chantypes Chantypes;
typedef uvlong Clzuint;
typedef struct Cmdbuf	Cmdbuf;
typedef struct Cmdtab	Cmdtab;
typedef struct Confmem	Confmem;
typedef struct Dev	Dev;
typedef struct DevConf	DevConf;
typedef struct Dirtab	Dirtab;
typedef struct Edf	Edf;
typedef struct Egrp	Egrp;
typedef struct Evalue	Evalue;
typedef struct Execvals	Execvals;
typedef struct Fgrp	Fgrp;
typedef struct Hci	Hci;
typedef struct Image	Image;
typedef struct Intrcommon Intrcommon;
typedef struct Log	Log;
typedef struct Logflag	Logflag;
typedef struct Mhead	Mhead;
typedef struct Mnt	Mnt;
typedef struct Mntcache Mntcache;
typedef struct Mntrpc	Mntrpc;
typedef struct Mntwalk	Mntwalk;
typedef struct Mount	Mount;
typedef struct Note	Note;
typedef struct Page	Page;
typedef struct Palloc	Palloc;
typedef struct Pallocmem	Pallocmem;
typedef struct Path	Path;
typedef struct Perf	Perf;
typedef struct Pgrp	Pgrp;
typedef struct PhysUart	PhysUart;
typedef struct Physseg	Physseg;
typedef struct Proc	Proc;
typedef struct Procalloc	Procalloc;
typedef struct Pte	Pte;
typedef struct QLock	QLock;
typedef struct Queue	Queue;
typedef struct RWlock	RWlock;
typedef struct Ref	Ref;
typedef struct Rendez	Rendez;
typedef struct Rgrp	Rgrp;
typedef struct Schedq	Schedq;
typedef struct Segment	Segment;
typedef struct Sysargs	Sysargs;
typedef struct Systab	Systab;
typedef struct Sema	Sema;
typedef struct Timer	Timer;
typedef struct Timers	Timers;
typedef struct Uart	Uart;
typedef struct Waitq	Waitq;
typedef struct Walkqid	Walkqid;
typedef struct Watchdog	Watchdog;
typedef struct Watermark	Watermark;
typedef int    Devgen(Chan*, char*, Dirtab*, int, int, Dir*);

#pragma incomplete DevConf
#pragma incomplete Edf
#pragma incomplete Intrcommon
#pragma incomplete Mntcache
#pragma incomplete Mntrpc
#pragma incomplete Queue
#pragma incomplete Timers

#include <fcall.h>

#ifndef PCICONSSIZE
#define PCICONSSIZE (16*1024)
#endif
#ifndef noprint			/* old or uniprocessor ports */
#define noprint _noprint
#endif

/* 9/9k compatibility */
#define MPCAPABLE()	(sys->nmach > 1)
#define MPSRUNNING()	(sys->nonline > 1)
#define MACHP(n)	(sys->machptr[n])

struct Ref
{
	Lock;
	long	ref;
};

struct Rendez
{
	Lock;
	Proc	*p;
};

struct QLock
{
	Lock	use;		/* to access Qlock structure */
	Proc	*head;		/* next process waiting for object */
	Proc	*tail;		/* last process waiting for object */
	int	locked;		/* flag */
	uintptr	qpc;		/* pc of the holder */
};

struct RWlock
{
	Lock	use;
	Proc	*head;		/* list of waiting processes */
	Proc	*tail;
	uintptr	wpc;		/* pc of writer */
	Proc	*wproc;		/* writing proc */
	int	readers;	/* number of readers */
	int	writer;		/* number of writers */
};

struct Alarms
{
	QLock;
	Proc	*head;
};

/*
 * Access types in namec & channel flags
 */
enum
{
	Aaccess,			/* as in stat, wstat */
	Abind,				/* for left-hand-side of bind */
	Atodir,				/* as in chdir */
	Aopen,				/* for i/o */
	Amount,				/* to be mounted or mounted upon */
	Acreate,			/* is to be created */
	Aremove,			/* will be removed by caller */

	COPEN	= 0x0001,		/* for i/o */
	CMSG	= 0x0002,		/* the message channel for a mount */
/*rsc	CCREATE	= 0x0004,		/* permits creation if c->mnt */
	CCEXEC	= 0x0008,		/* close on exec */
	CFREE	= 0x0010,		/* not in use */
	CRCLOSE	= 0x0020,		/* remove on close */
	CCACHE	= 0x0080,		/* client cache */
};

/* flag values */
enum
{
	BINTR	=	(1<<0),		/* allocated at interrupt time */

	Bipck	=	(1<<2),		/* ip checksum known good */
	Budpck	=	(1<<3),		/* udp checksum known good */
	Btcpck	=	(1<<4),		/* tcp checksum known good */
	Bpktck	=	(1<<5),		/* packet checksum (crc?) known good */
};

struct Block
{
	Block*	next;
	Block*	list;
	uchar*	rp;			/* first unconsumed byte */
	uchar*	wp;			/* first empty byte */
	uchar*	lim;			/* 1 past the end of the buffer */
	uchar*	base;			/* start of the buffer */
	void	(*free)(Block*);
	ushort	flag;
	ushort	checksum; /* IP checksum of complete packet (minus media header) */
//	long	ref;			/* just for 9/ip/gre.c */
};
#define BLEN(s)	((s)->wp - (s)->rp)
#define BALLOC(s) ((s)->lim - (s)->base)

/* 9/9k Chan compatibility; see cache.c Mntcache too */
#define CHANDEV(c)		((c)->devp)
#define SAMEDEVTYPE(c1, c2)	(CHANDEV(c1) == CHANDEV(c2))
#define COPYDEVTYPE(c1, c2)	(CHANDEV(c1) =  CHANDEV(c2))
/* pgsize is in units of pages (BY2PG) */
#define NEWSEGMENT(attr, addr, top, pgsize) newsegtop(attr, addr, top)

struct Chantypes {
	Dev*	devp;	/* devtab entry from Dir server type; new 9k name */
};
struct Chan
{
	Ref;				/* the Lock in this Ref is also Chan's lock */
	Chan*	next;			/* allocation */
	Chan*	link;
	vlong	offset;			/* in fd */
	vlong	devoffset;		/* in underlying device; see read */
	Chantypes;
	uint	devno;			/* Dir server subtype (devp) instance */
	ushort	mode;			/* read/write */
	ushort	flag;
	Qid	qid;
	int	fid;			/* for devmnt */
	ulong	iounit;			/* chunk size for i/o; 0==default */
	Mhead*	umh;			/* mount point that derived Chan; used in unionread */
	Chan*	umc;			/* channel in union; held for union read */
	QLock	umqlock;		/* serialize unionreads */
	int	uri;			/* union read index */
	int	dri;			/* devdirread index */
	uchar*	dirrock;		/* directory entry rock for translations */
	uintptr	nrock;			/* holds ptr. diff. */
	int	mrock;
	QLock	rockqlock;
	int	ismtpt;
	Mntcache*mc;			/* 9k name for Mount cache pointer */
	Mnt*	mux;			/* Mnt for clients using me for messages */
	union {
		void*	aux;
		Qid	pgrpid;		/* for #p/notepg */
		ulong	mid;		/* for ns in devproc */
	};
	Chan*	mchan;			/* channel to mounted server */
	Qid	mqid;			/* qid of root of mount point */
	Path*	path;
};

struct Path
{
	Ref;
	char*	s;
	Chan**	mtpt;			/* mtpt history */
	int	len;			/* strlen(s) */
	int	alen;			/* allocated length of s */
	int	mlen;			/* number of path elements */
	int	malen;			/* allocated length of mtpt */
};

/* 9/9k compatibility */
typedef int	Createperm;
typedef long	Sysstatlen;
typedef vlong	Brwlen;

struct Dev
{
	Rune	dc;
	char*	name;

	void	(*reset)(void);
	void	(*init)(void);
	void	(*shutdown)(void);
	Chan*	(*attach)(char*);
	Walkqid*(*walk)(Chan*, Chan*, char**, int);
	Sysstatlen (*stat)(Chan*, uchar*, Sysstatlen);
	Chan*	(*open)(Chan*, int);
	void	(*create)(Chan*, char*, int, Createperm);
	void	(*close)(Chan*);
	long	(*read)(Chan*, void*, long, vlong);
	Block*	(*bread)(Chan*, long, Brwlen);
	long	(*write)(Chan*, void*, long, vlong);
	long	(*bwrite)(Chan*, Block*, Brwlen);
	void	(*remove)(Chan*);
	Sysstatlen (*wstat)(Chan*, uchar*, Sysstatlen);
	void	(*power)(int);	/* power mgt: power(1) => on, power (0) => off */
	int	(*config)(int, char*, DevConf*);	/* returns 0 on error */

	/* not explicitly initialised */
	int	attached;				/* debugging */
};

struct Dirtab
{
	char	name[KNAMELEN];
	Qid	qid;
	vlong	length;
	long	perm;
};

struct Walkqid
{
	Chan	*clone;
	int	nqid;
	Qid	qid[1];
};

enum
{
	NSMAX	=	1000,
	NSLOG	=	7,
	NSCACHE	=	(1<<NSLOG),
};

struct Mntwalk				/* state for /proc/#/ns */
{
	int	cddone;
	Mhead*	mh;
	Mount*	cm;
};

struct Mount
{
	int	mountid;
	Mount*	next;
	Mhead*	head;
	Mount*	copy;
	Mount*	order;
	Chan*	to;			/* channel replacing channel */
	int	mflag;
	char	*spec;
};

struct Mhead
{
	Ref;
	RWlock	lock;
	Chan*	from;			/* channel mounted upon */
	Mount*	mount;			/* what's mounted upon it */
	Mhead*	hash;			/* Hash chain */
};

struct Mnt
{
	Lock;
	/* references are counted using c->ref; channels on this mount point incref(c->mchan) == Mnt.c */
	Chan	*c;		/* Channel to file service */
	Proc	*rip;		/* Reader in progress */
	Mntrpc	*queue;		/* Queue of pending requests on this channel */
	uint	id;		/* Multiplexer id for channel check */
	Mnt	*list;		/* Free list */
	int	flags;		/* cache */
	int	msize;		/* data + IOHDRSZ */
	char	*version;	/* 9P version */
	Queue	*q;		/* input queue */
};

enum
{
	NUser,				/* note provided externally */
	NExit,				/* deliver note quietly */
	NDebug,				/* print debug message */
};

struct Note
{
	char	msg[ERRMAX];
	int	flag;			/* whether system posted it */
};

enum
{
	PG_NOFLUSH	= 0,
	PG_TXTFLUSH	= 1,		/* flush dcache and invalidate icache */
	PG_DATFLUSH	= 2,		/* flush both i & d caches (UNUSED) */
	PG_NEWCOL	= 3,		/* page has been recolored */
	PG_NOCACHE	= 4,		/* riscv experiment */

	PG_MOD		= 0x01,		/* software modified bit */
	PG_REF		= 0x02,		/* software referenced bit */

	Nozeropage	= 0,		/* "clear" arg. to newpage() */
	Zeropage	= 1,
};

struct Page
{
	Lock;
	uvlong	pa;			/* Physical address in memory */
	uvlong	va;			/* Virtual address for user */
	/* Disc address in file, or # of user mappings or index in top-level PT */
	ulong	daddr;
	int	ref;			/* Reference count */
	uchar	modref;			/* Simulated modify/reference bits */
	uchar	color;			/* Cache coloring; make numa cluster */
	uchar	lg2size;		/* log2(pagesize) */
	/* we really only need 2 bits per cpu */
	char	cachectl[MACHMAX];	/* Cache flushing control for mmuput */
	Image	*image;			/* Associated image (text) */
	Page	*next;			/* Lru free list */
	Page	*prev;
	Page	*hash;			/* Image hash chains */
};

struct Image
{
	Ref;
	Chan	*c;			/* channel to text file */
	Qid 	qid;			/* Qid for page cache coherence */
	Qid	mqid;
	Chan	*mchan;
	Rune	dc;			/* Device type of owning channel */
	Segment *s;			/* TEXT segment for image if running */
	Image	*hash;			/* Qid hash chains */
	Image	*next;			/* Free list */
	int	notext;			/* no file associated */
};

struct Pte
{
	Page	*pages[PTEPERTAB];	/* Page map for this chunk of pte */
	Page	**first;		/* First used entry */
	Page	**last;			/* Last used entry */
};

/* Segment types */
enum
{
	SG_TYPE		= 07,		/* Mask type of segment */
	SG_TEXT		= 00,
	SG_DATA		= 01,
	SG_BSS		= 02,
	SG_STACK	= 03,
	SG_SHARED	= 04,
	SG_PHYSICAL	= 05,

	SG_RONLY	= 0040,		/* Segment is read only */
	SG_CEXEC	= 0100,		/* Detach at exec */
};
#define pagedout(s)	((s) == nil)	/* only on demand, no swap */

#define SEGMAXSIZE	((uvlong)SEGMAPSIZE*PTEMAPMEM)

struct Physseg
{
	ulong	attr;			/* Segment attributes */
	char	*name;			/* Attach name */
	uintptr	pa;			/* Physical address */
	uintptr	size;			/* Maximum segment size in pages */
	Page	*(*pgalloc)(Segment*, uintptr);	/* Allocation if we need it */
	void	(*pgfree)(Page*);
	uchar	lg2pgsize;		/* log2(size of pages in segment) */
};

struct Sema
{
	Rendez;
	int*	addr;
	int	waiting;
	Sema*	next;
	Sema*	prev;
};

struct Segment
{
	Ref;
	QLock	lk;
	ushort	steal;		/* Page stealer lock for 9's pageout(); obs. */
	ushort	type;		/* segment type */
	uintptr	base;		/* virtual base */
	uintptr	top;		/* virtual top */
	uintptr	size;		/* size in pages */
	/* fstart & flen are limited in width by a.out format */
	ulong	fstart;		/* start address in file for demand load */
	ulong	flen;		/* length of segment in file */
	uchar	lg2pgsize;	/* log2(size of pages in segment) */
	int	flushme;	/* maintain icache for this segment */
	Image	*image;		/* text in file attached to this segment */
	Physseg *pseg;
	ulong*	profile;	/* Tick profile area */
	uintptr	ptemapmem;	/* space mapped by one Pte in this segment */
	Pte	**map;
	uintptr	mapsize;
	Pte	*ssegmap[SSEGMAPSIZE];
	Lock	semalock;
	Sema	sema;
};

enum
{
	RENDLOG	=	5,
	RENDHASH =	1<<RENDLOG,	/* Hash to lookup rendezvous tags */
	MNTLOG	=	5,
	MNTHASH =	1<<MNTLOG,	/* Hash to walk mount table */
	PGHLOG  =	12,		/* was 9 in 9/pc; k10s are bigger */
	PGHSIZE	=	1<<PGHLOG,	/* Page hash for image lookup */
};
#define REND(p,s)	((p)->rendhash[(s)&((1<<RENDLOG)-1)])
#define MOUNTH(p,qid)	((p)->mnthash[(qid).path&((1<<MNTLOG)-1)])

struct Pgrp
{
	Ref;				/* also used as a lock when mounting */
	int	noattach;
	ulong	pgrpid;
	QLock	debug;			/* single access via devproc.c */
	RWlock	ns;			/* Namespace n read/one write lock */
	Mhead	*mnthash[MNTHASH];
};

struct Rgrp
{
	Ref;				/* the Ref's lock is also the Rgrp's lock */
	Proc	*rendhash[RENDHASH];	/* Rendezvous tag hash */
};

struct Egrp
{
	Ref;
	RWlock;
	Evalue	**ent;
	int	nent;
	int	ment;
	ulong	path;	/* qid.path of next Evalue to be allocated */
	ulong	vers;	/* of Egrp */
};

struct Evalue
{
	char	*name;
	char	*value;
	int	len;
	Evalue	*link;
	Qid	qid;
};

struct Fgrp
{
	Ref;
	Chan	**fd;
	uint	nfd;			/* number allocated */
	uint	maxfd;			/* highest fd in use */
	int	exceed;			/* debugging */
};

enum
{
	DELTAFD	= 16		/* incremental increase in Fgrp.fd's */
};

struct Pallocmem
{
	uintmem	base;
	uintmem	limit;
	int	color;			/* memory cluster for numa */
};

struct Palloc
{
	Lock;
	Pallocmem mem[32];		/* banks (ranges) of memory */
	Page	*head;			/* most recently used */
	Page	*tail;			/* least recently used */
	uintptr	freecount;		/* how many pages on free list now */
	Page	*pages;			/* array of all pages */
	uintptr	user;			/* how many user pages */
	Page	*hash[PGHSIZE];
	Lock	hashlock;
	Rendez	r;			/* Sleep for free mem */
	QLock	pwait;			/* Queue of procs waiting for memory */
};

struct Waitq
{
	Waitmsg	w;
	Waitq	*next;
};

/*
 * fasttick timer interrupts
 */
enum {
	/* Mode */
	Trelative,	/* timer programmed in ns from now */
	Tperiodic,	/* periodic timer, period in ns */
};

struct Timer
{
	/* Public interface */
	int	tmode;		/* See above */
	vlong	tns;		/* meaning defined by mode */
	void	(*tf)(Ureg*, Timer*);
	void	*ta;
	/* Internal */
	Lock;
	Timers	*tt;		/* Timers queue this timer runs on */
	vlong	twhen;		/* ns represented in fastticks */
	Timer	*tnext;
};

enum
{
	RFNAMEG		= (1<<0),
	RFENVG		= (1<<1),
	RFFDG		= (1<<2),
	RFNOTEG		= (1<<3),
	RFPROC		= (1<<4),
	RFMEM		= (1<<5),
	RFNOWAIT	= (1<<6),
	RFCNAMEG	= (1<<10),
	RFCENVG		= (1<<11),
	RFCFDG		= (1<<12),
	RFREND		= (1<<13),
	RFNOMNT		= (1<<14),
};

/*
 *  process memory segments - NSEG always last !
 */
enum
{
	SSEG, TSEG, DSEG, BSEG, ESEG, LSEG, NSEG = LSEG + 1 + 4,
};

enum
{
	Dead = 0,		/* Process states */
	Moribund,
	Ready,
	Scheding,
	Running,
	Queueing,
	QueueingR,
	QueueingW,
	Wakeme,
	Broken,
	Stopped,
	Rendezvous,
	Waitrelease,

	Proc_stopme = 1, 	/* devproc requests */
	Proc_exitme,
	Proc_traceme,
	Proc_exitbig,
	Proc_tracesyscall,

	TUser = 0, 		/* Proc.time */
	TSys,
	TReal,
	TCUser,
	TCSys,
	TCReal,

	NERR = 64,		/* maximum nesting of waserror calls */
	NNOTE = 5,

	/* larger number is higher (more urgent) process scheduling priority */
	Npriq		= 20,		/* # of scheduler priority levels */
	Nrq		= Npriq+2,	/* 3 of priority levels including real time */
	PriExtra	= Npriq-1,	/* edf proc.s at high best-effort pri */
	PriRelease	= Npriq,	/* released edf proc.s */
	PriEdf		= Npriq+1,	/* active edf proc.s */
	PriNormal	= 10,		/* base priority for normal proc.s */
	PriKproc	= 13,		/* base priority for kernel proc.s */
	PriRoot		= 13,		/* base priority for root (#/) proc.s */
};

struct Schedq
{
	Lock;
	Proc*	head;
	Proc*	tail;
	int	n;
};

/*
 * almost all return values go into the return register (e.g., ureg->ret or
 * ureg->arg) but nsec's vlong goes into the next register too, on 32-bit
 * systems.  on at least riscv64, we also have to sign-extend the return
 * register.
 */
typedef union Ar0 Ar0;
union Ar0 {			/* possible types of syscall return values */
#ifdef _BITS64
	/* notably for riscv64 */
	vlong	i;
	vlong	l;
	vlong	u;
#else
	int	i;
	long	l;
	uintptr	u;		/* uintptr doesn't allow -1 on error */
#endif
	uintptr	p;
	void*	v;
	vlong	vl;
};

struct Proc
{
	Label	sched;		/* known to l.s; c.f. Mach->sched */
	char	*kstack;	/* offset known to l.s */
	Mach	*mach;		/* machine running this proc */

	char	*text;
	char	*user;
	char	*args;		/* exec arguments */
	int	nargs;		/* number of bytes of args */
	Proc	*rnext;		/* next process in run queue */
	Proc	*qnext;		/* next process on queue for a QLock */
	QLock	*qlock;		/* addr of qlock being queued for DEBUG */
	int	state;
	char	*psstate;	/* What /proc/#/status reports */
	Segment	*seg[NSEG];
	QLock	seglock;	/* locked whenever seg[] changes */
	int	pid;
	int	index;		/* index (slot) in proc array */
	int	ref;		/* indirect reference */
	int	noteid;		/* Equivalent of note group */
	Proc	*pidhash;	/* next proc in pid hash */

	Lock	exl;		/* Lock count and waitq */
	Waitq	*waitq;		/* Exited processes wait children */
	int	nchild;		/* Number of living children */
	int	nwait;		/* Number of uncollected wait records */
	QLock	qwaitr;
	Rendez	waitr;		/* Place to hang out in wait */
	Proc	*parent;

	Pgrp	*pgrp;		/* Process group for namespace */
	Egrp 	*egrp;		/* Environment group */
	Fgrp	*fgrp;		/* File descriptor group */
	Rgrp	*rgrp;		/* Rendez group */

	Fgrp	*closingfgrp;	/* used during teardown */

	int	parentpid;
	ulong	time[6];	/* TUser, TSys, TReal; child U, S, R */

	uvlong	kentry;		/* Kernel entry time stamp (for profiling) */
	/*
	 * pcycles: cycles spent in this process (updated on procsave/restore)
	 * when this is the current proc and we're in the kernel
	 * (procrestores outnumber procsaves by one).
	 * the number of cycles spent in the proc is pcycles + cycles().
	 * when this is not the current process or we're in user mode
	 * (procrestores and procsaves balance), it is pcycles.
	 */
	vlong	pcycles;

	int	insyscall;	/* flag; also subscript of w.time[] */

	QLock	debug;		/* to access debugging elements of User */
	Proc	*pdbg;		/* the debugging process */
	ulong	procmode;	/* proc device default file mode */
	ulong	privatemem;	/* proc does not let anyone read mem */
	int	hang;		/* hang at next exec for debug */
	int	procctl;	/* Control for /proc debugging */
	uintptr	pc;		/* DEBUG only */

	Lock	rlock;		/* sync sleep/wakeup with postnote */
	Rendez	*r;		/* rendezvous point slept on */
	Rendez	sleep;		/* place for syssleep/debug */
	int	notepending;	/* note issued but not acted on */
	int	kp;		/* true if a kernel process */
	Proc	*palarm;	/* Next alarm time */
	ulong	alarm;		/* Time of call */
	int	newtlb;		/* Pager has changed my pte's, I must flush */

	uintptr	rendtag;	/* Tag for rendezvous */
	uintptr	rendval;	/* Value for rendezvous */
	Proc	*rendhash;	/* Hash list for tag values */

	Timer;			/* For tsleep and real-time */
	Rendez	*trend;
	int	(*tfn)(void*);
	void	(*kpfun)(void*);
	void	*kparg;

	int	scallnr;	/* system call number */
	/*
	 * arg needs to be aligned as the original copy on the stack is.
	 * this is needed for va_arg(args, vlong) on riscv, at least.
	 */
	struct Sysargs {
		void	*linksave;
		uintptr	arg[MAXSYSARG];	/* system call arguments */
	} arg;
	int	nerrlab;
	Label	errlab[NERR];
	/* syserrstr and errstr point at either errbuf[01] */
	char	*syserrstr;	/* last error from a system call */
	char	*errstr;	/* reason we're unwinding the error stack */
	char	errbuf0[ERRMAX];
	char	errbuf1[ERRMAX];
	/* increased genbuf to 256 bytes, per fossil limit */
	char	genbuf[KCOMPLEN]; /* buffer used e.g. for last name element from namec */
	Chan	*slash;
	Chan	*dot;

	Note	note[NNOTE];
	short	nnote;		/* # of notes not yet delivered */
	short	notified;	/* sysnoted is due */
	Note	lastnote;
	void	(*notify)(void*, char*);

	Lock	*lockwait;
	Lock	*lastlock;	/* debugging */
	Lock	*lastilock;	/* debugging */

	Mach	*wired;
	Mach	*mp;		/* machine this process last ran on */
	long	nlocks;		/* number of locks held by proc */
	ulong	delaysched;
	ulong	priority;	/* priority level */
	ulong	basepri;	/* base priority level */
	int	fixedpri;	/* priority level does not change */
	ulong	cpu;		/* cpu average */
	ulong	lastupdate;
	ulong	readytime;	/* time process came ready */
	ulong	movetime;	/* last time process switched processors */
	int	preempted;	/* true if this process hasn't finished the
				 *  interrupt that last preempted it
				 */
	Edf	*edf;		/* if non-null, real-time proc, edf contains scheduling params */
	int	trace;		/* process being traced? */

	uintptr	qpc;		/* pc calling last blocking qlock */

	int	setargs;	/* flag */

	void	*ureg;		/* User registers for notes */
	void	*dbgreg;	/* User registers for devproc */

	char*	syscalltrace;

	/*
	 *  machine specific fpu, mmu and notify
	 */
	PFPU;
	PFPU notefpu;		/* holds FP regs during handler execution */
	PMMU;
	PNOTIFY;
	double	_align1;
};

enum
{
	PROCMAX	= 3000,		/* maximum number of processes; see procinit */
};

struct Procalloc
{
	Lock;
	Proc*	ht[128];
	Proc*	arena;
	Proc*	free;
};

enum
{
	Read, Write,		/* common flag values */
	KSEGM = KZERO,
	MAXMACH = MACHMAX,	/* 9 name compatibility */

	PRINTSIZE =	256,
	NUMSIZE	=	12,		/* size of formatted number */
	/* READSTR was 1000, which is way too small for usb's ctl file */
	READSTR =	4000,		/* temporary buffer size for device reads */
};

struct Execvals {
	uvlong	entry;
	ulong	textsize;
	ulong	datasize;
};

struct Systab {
	char*	n;			/* syscall name, for ps, etc. */
	void	(*f)(Ar0*, va_list);	/* implementation */
	Ar0	r;			/* error return value */
};

	int	bootkernel;
extern 	char	cant[];
extern	char*	conffile;
extern	char	configfile[];
/* flag: set service=cpu, scale net chans, recognise ^p on console */
extern	int	cpuserver;
extern	char*	eve;
extern	char	hostdomain[];
extern	uchar	initcode[];
extern	int	_noprint;	/* flag: locks or uart aren't enabled */
extern	Ref	noteidalloc;
/* typically 8 (2 in use), see $CONF.c from ../mk/parse */
extern	int	nphysseg;
extern	int	nsyscall;
extern	Palloc	palloc;
	int	(*parseboothdr)(Chan *, ulong, Execvals *);
extern	Physseg	physseg[];
extern	Procalloc	procalloc;
extern	uint	qiomaxatomic;
extern	char*	statename[];
extern	char*	sysname;
extern 	Systab	systab[];

	char	cputype[];
	int	early;	/* flag: not ready for traps yet, also print w/ prf */
	uintptr	pgmem;
	int	polledprint;
	void	(*prfaults)(void);
	int	prmsdelay;
	uintptr	uart0regs;
	Watchdog*watchdog;
	int	watchdogon;

enum
{
	LRESPROF	= 3,
};

/*
 *  action log
 */
struct Log {
	Lock;
	int	opens;
	char*	buf;
	char	*end;
	char	*rptr;
	uintptr	len;
	uintptr	nlog;
	int	minread;

	int	logmask;	/* mask of things to debug */

	QLock	readq;
	Rendez	readr;
};

struct Logflag {
	char*	name;
	int	mask;
};

enum
{
	NCMDFIELD = 128
};

struct Cmdbuf
{
	char	*buf;
	char	**f;
	int	nf;
};

struct Cmdtab
{
	int	index;	/* used by client to switch on result */
	char	*cmd;	/* command name */
	int	narg;	/* expected #args; 0 ==> variadic */
};

/*
 *  routines to access UART hardware
 */
struct PhysUart
{
	char*	name;
	Uart*	(*pnp)(void);
	void	(*enable)(Uart*, int);
	void	(*disable)(Uart*);
	void	(*kick)(Uart*);
	void	(*dobreak)(Uart*, int);
	int	(*baud)(Uart*, int);
	int	(*bits)(Uart*, int);
	int	(*stop)(Uart*, int);
	int	(*parity)(Uart*, int);
	void	(*modemctl)(Uart*, int);
	void	(*rts)(Uart*, int);
	void	(*dtr)(Uart*, int);
	long	(*status)(Uart*, void*, long, long);
	void	(*fifo)(Uart*, int);
	void	(*power)(Uart*, int);		/* unused */
	int	(*getc)(Uart*);			/* polling version for rdb */
	void	(*putc)(Uart*, int);		/* polling version for iprint */
	void	(*poll)(Uart*);			/* polled interrupt routine */
};

enum {
	Stagesize=	2048
};

/*
 *  software UART
 */
struct Uart
{
	void*	regs;			/* hardware stuff or Ctlr */
//	void*	saveregs;		/* place to put registers on power down */
	char*	name;			/* internal name */
	ulong	freq;			/* clock frequency */
	int	bits;			/* bits per character */
	int	stop;			/* stop bits */
	int	parity;			/* even, odd or no parity */
	int	baud;			/* baud rate */
	PhysUart*phys;
	int	console;		/* used as a serial console */
	int	special;		/* internal kernel device */
	Uart*	next;			/* list of allocated uarts */

	QLock;
	int	type;			/* ?? */
	int	dev;
	int	opens;

	int	enabled;
	Uart	*elist;			/* next enabled interface */

	int	perr;			/* parity errors */
	int	ferr;			/* framing errors */
	int	oerr;			/* rcvr overruns */
	int	berr;			/* no input buffers */
	int	serr;			/* input queue overflow */

	/* buffers */
	int	(*putc)(Queue*, int);
	Queue	*iq;
	Queue	*oq;

	Lock	rlock;
	uchar	istage[Stagesize];
	uchar	*iw;
	uchar	*ir;
	uchar	*ie;

	Lock	tlock;			/* transmit */
	uchar	ostage[Stagesize];
	uchar	*op;
	uchar	*oe;
	int	drain;

	int	modem;			/* hardware flow control on */
	int	xonoff;			/* software flow control on */
	int	blocked;
	int	cts, dsr, dcd;		/* keep track of modem status */
	int	ctsbackoff;
	int	hup_dsr, hup_dcd;	/* send hangup upstream? */
	int	dohup;

	Rendez	r;
};

extern	Uart*	consuart;

/*
 *  performance timers, all units in perfticks
 */
struct Perf
{
	ulong	intrts;		/* time of last interrupt */
	ulong	inintr;		/* time since last clock tick in interrupt handlers */
	ulong	avg_inintr;	/* avg time per clock tick in interrupt handlers */
	ulong	inidle;		/* time since last clock tick in idle loop */
	ulong	avg_inidle;	/* avg time per clock tick in idle loop */
	ulong	last;		/* value of perfticks() at last clock tick */
	ulong	period;		/* perfticks() per clock tick */
};

struct Watchdog
{
	void	(*enable)(void);	/* watchdog enable */
	void	(*disable)(void);	/* watchdog disable */
	void	(*restart)(void);	/* watchdog restart */
	void	(*stat)(char*, char*);	/* watchdog statistics */
};

struct Watermark
{
	Lock;
	int	highwater;
	int	curr;
	int	max;
	int	hitmax;		/* count: how many times hit max? */
	char	*name;
};

/*
 * synonyms for 0 with tags for meaning, as in "if (TODO)"
 */

enum {
	TODO = 0,
	FUTURE = 0,
	BROKEN = 0,
	CRASH_OK = 0,

	TOREMOVE = 1,
};

/*
 * interrupts
 */

enum {					/* interrupt service return values */
	Intrnotforme,
	Intrforme,
	Intrtrap,
	Intrunconverted,
};

struct Intrcommon {
	Pcidev	*pcidev;
	void	*vector;		/* for 9k */
	short	irq;
	uchar	intrenabled;		/* flag */
};

enum {					/* arguments to exit, shutdown */
	Shutreboot,
	Shutpanic,
};

/* queue state bits,  Qmsg, Qcoalesce, and Qkick can be set in qopen */
enum
{
	/* Queue.state */
	Qstarve		= (1<<0),	/* consumer starved */
	Qmsg		= (1<<1),	/* message stream */
	Qclosed		= (1<<2),	/* queue has been closed/hungup */
	Qflow		= (1<<3),	/* producer flow controlled */
	Qcoalesce	= (1<<4),	/* coalesce packets on read */
	Qkick		= (1<<5),	/* always call the kick routine after qwrite */
};

enum {
	Couldmalloc,
	Mustmalloc,

	Clzbits		= BI2BY * sizeof(Clzuint),
};

#define DEVDOTDOT (-1)

#pragma	varargck	type	"I"	uchar*
#pragma	varargck	type	"V"	uchar*
#pragma	varargck	type	"E"	uchar*
#pragma	varargck	type	"M"	uchar*

#pragma	varargck	type	"m"	Mreg

#pragma	varargck	type	"N"	uvlong
