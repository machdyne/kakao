/*
 * ethernet driver framework
 */
#include "u.h"
#include "../port/lib.h"
#include "mem.h"
#include "dat.h"
#include "fns.h"
#include "../port/error.h"
#include "../port/netif.h"
#include "etherif.h"
#include "io.h"			/* for Pcidev */
#include <ip.h>			/* for eipfmt */

static Ether *etherxx[MaxEther];

enum { Debug = 1, };

extern Dev etherdevtab;

Chan*
etherattach(char* spec)
{
	ulong ctlrno;
	char *p;
	Chan *chan;
	Ether *ether;

	ctlrno = 0;
	if(spec && *spec){
		ctlrno = strtoul(spec, &p, 0);
		if((ctlrno == 0 && p == spec) || *p != 0 || ctlrno >= MaxEther)
			error(Ebadarg);
	}
	ether = etherxx[ctlrno];
	if(ether == nil)
		error(Enodev);

	chan = devattach(etherdevtab.dc, spec);
	if(waserror()){
		chanfree(chan);
		nexterror();
	}
	chan->devno = ctlrno;
	if(ether->attach)
		ether->attach(ether);
	poperror();
	return chan;
}

static Walkqid*
etherwalk(Chan* chan, Chan* nchan, char** name, int nname)
{
	return netifwalk(etherxx[chan->devno], chan, nchan, name, nname);
}

static Sysstatlen
etherstat(Chan* chan, uchar* dp, Sysstatlen n)
{
	return netifstat(etherxx[chan->devno], chan, dp, n);
}

static Chan*
etheropen(Chan* chan, int omode)
{
	return netifopen(etherxx[chan->devno], chan, omode);
}

static void
ethercreate(Chan*, char*, int, Createperm)
{
}

static void
etherclose(Chan* chan)
{
	netifclose(etherxx[chan->devno], chan);
}

static long
etherread(Chan* chan, void* buf, long n, vlong off)
{
	Ether *ether;
	ulong offset = off;

	ether = etherxx[chan->devno];
	if((chan->qid.type & QTDIR) == 0 && ether->ifstat)
		/*
		 * With some controllers it is necessary to reach
		 * into the chip to extract statistics.
		 */
		if(NETTYPE(chan->qid.path) == Nifstatqid)
			return ether->ifstat(ether, buf, n, offset);
		else if(NETTYPE(chan->qid.path) == Nstatqid)
			ether->ifstat(ether, buf, 0, offset);
	return netifread(ether, chan, buf, n, offset);
}

static Block*
etherbread(Chan* chan, long n, Brwlen offset)
{
	return netifbread(etherxx[chan->devno], chan, n, offset);
}

static Sysstatlen
etherwstat(Chan* chan, uchar* dp, Sysstatlen n)
{
	return netifwstat(etherxx[chan->devno], chan, dp, n);
}

static void
etherrtrace(Netfile* f, Etherpkt* pkt, int len)
{
	Block *bp;

	if(qwindow(f->iq) <= 0)
		return;
	bp = iallocb(64);
	if(bp == nil)
		return;
	memmove(bp->wp, pkt->d, MIN(len, 58));
	bp->wp[58] = len>>8;
	bp->wp[59] = len;
	bp->wp = beputl(&bp->wp[60], TK2MS(sys->ticks));
	qpass(f->iq, bp);
}

static void
softovflow(Ether *ether, char *context)
{
	if (Debug)
		iprint("#l%d: etheriq: soverflow for %s\n", ether->ctlrno,
			context);
	ether->soverflows++;
}

/* qpass or freeb bp if fromwire */
Block*
etheriq(Ether* ether, Block* bp, int fromwire)
{
	Etherpkt *pkt;
	ushort type;
	int len, multi, tome, fromme;
	Netfile *f, *fx;
	Netfile **ep, **fp;
	Block *xbp;

	ether->inpackets++;

	pkt = (Etherpkt*)bp->rp;
	len = BLEN(bp);
	type = (pkt->type[0]<<8)|pkt->type[1];
	fx = 0;
	ep = &ether->f[Ntypes];

	/* check for valid multicast addresses */
	multi = pkt->d[0] & 1;
	if(multi && memcmp(pkt->d, ether->bcast, sizeof(pkt->d)) != 0 &&
	    ether->prom == 0 && !activemulti(ether, pkt->d, sizeof(pkt->d))){
		if(fromwire){
			freeb(bp);
			bp = nil;
		}
		return bp;
	}

	/* is it for me? */
	tome   = memcmp(pkt->d, ether->ea, sizeof(pkt->d)) == 0;
	fromme = memcmp(pkt->s, ether->ea, sizeof(pkt->s)) == 0;
	/*
	 * Multiplex the packet to all the connections which want it.
	 * If the packet is not to be used subsequently (fromwire != 0),
	 * attempt to simply pass it into one of the connections, thereby
	 * saving a copy of the data (usual case hopefully).
	 */
	for(fp = ether->f; fp < ep; fp++)
		if((f = *fp) != nil && (f->type == type || f->type < 0) &&
		    (tome || multi || f->prom))
			/* Don't want to hear bridged packets */
			if(f->bridge && !fromwire && !fromme)
				continue;
			else if(f->headersonly)
				etherrtrace(f, pkt, len);
			else if(fromwire && fx == nil)
				fx = f;
			else if((xbp = iallocb(len)) == nil)
				softovflow(ether, "iallocb");
			else {
				/* pass a copy up f->iq */
				memmove(xbp->wp, pkt, len);
				xbp->wp += len;
				if(qpass(f->iq, xbp) < 0)
					/* this is bad but don't log it */
					// softovflow(ether, "f->iq copy");
					ether->soverflows++;
			}

	if(fx){
		if(qpass(fx->iq, bp) < 0)
			softovflow(ether, "fx->iq normal");
		return nil;
	}
	if(fromwire){
		freeb(bp);
		return nil;
	}
	return bp;
}

static int
etheroq(Ether* ether, Block* bp)
{
	int len, loopback;
	Etherpkt *pkt;
	Mpl s;

	ether->outpackets++;
	/*
	 * Check if the packet has to be placed back onto the input queue,
	 * i.e., if it's a loopback or broadcast packet or the interface is
	 * in promiscuous mode.
	 * If it's a loopback packet indicate to etheriq that the data isn't
	 * needed and return, etheriq will pass-on or free the block.
	 * To enable bridging to work, only packets that were originated
	 * by this interface are fed back.
	 */
	pkt = (Etherpkt*)bp->rp;
	len = BLEN(bp);
	loopback = memcmp(pkt->d, ether->ea, sizeof(pkt->d)) == 0;
	if(loopback || memcmp(pkt->d, ether->bcast, sizeof(pkt->d)) == 0 ||
	    ether->prom){
		s = splhi();
		etheriq(ether, bp, 0);
		/* bp is still valid */
		splx(s);
	}

	if(!loopback){
		if(qfull(ether->oq))
			print("etheroq: WARNING: ether->oq full!\n");
		qbwrite(ether->oq, bp);
		if(ether->transmit != nil)
			ether->transmit(ether);
	} else
		freeb(bp);

	return len;
}

static long
etherwrite(Chan* chan, void* buf, long n, vlong)
{
	Ether *ether;
	Block *bp;
	int nn, onoff;
	Cmdbuf *cb;

	ether = etherxx[chan->devno];
	if(NETTYPE(chan->qid.path) != Ndataqid) {
		nn = netifwrite(ether, chan, buf, n);
		if(nn >= 0)
			return nn;
		cb = parsecmd(buf, n);
		if(cb->f[0] && strcmp(cb->f[0], "nonblocking") == 0){
			if(cb->nf <= 1)
				onoff = 1;
			else
				onoff = atoi(cb->f[1]);
			qnoblock(ether->oq, onoff);
			free(cb);
			return n;
		}
		free(cb);
		if(ether->ctl!=nil)
			return ether->ctl(ether,buf,n);

		error(Ebadctl);
	}

	if(n > ETHERMAXTU)
		error(Etoobig);
	if(n < ETHERMINTU)
		error(Etoosmall);

	bp = allocb(n);
	if(waserror()){
		freeb(bp);
		nexterror();
	}
	memmove(bp->rp, buf, n);
	memmove(bp->rp+Eaddrlen, ether->ea, Eaddrlen);
	poperror();
	bp->wp += n;

	return etheroq(ether, bp);
}

static long
etherbwrite(Chan* chan, Block* bp, Brwlen)
{
	long n;

	n = BLEN(bp);
	if(waserror()) {
		freeb(bp);
		nexterror();
	}
	if(NETTYPE(chan->qid.path) != Ndataqid){
		n = etherwrite(chan, bp->rp, n, 0);
		poperror();
		freeb(bp);
		return n;
	}
	if(n > ETHERMAXTU)
		error(Etoobig);
	if(n < ETHERMINTU)
		error(Etoosmall);
	poperror();

	return etheroq(etherxx[chan->devno], bp);
}

/* array of interface model names and corresponding registration function */
static struct {
	char*	type;
	int	(*reset)(Ether*);
} cards[MaxEther+1];

/* adds a model of ethernet card, not a specific instance */
void
addethercard(char* t, int (*r)(Ether*))
{
	static uint ncard;

	if(ncard >= MaxEther)
		panic("addethercard: too many ether card types (%d)", ncard);
	cards[ncard].type = t;
	cards[ncard].reset = r;
	ncard++;
}

int
parseether(uchar *to, char *from)
{
	char nip[4];
	char *p;
	int i;

	p = from;
	for(i = 0; i < Eaddrlen; i++){
		if(*p == 0)
			return -1;
		nip[0] = *p++;
		if(*p == 0)
			return -1;
		nip[1] = *p++;
		nip[2] = 0;
		to[i] = strtoul(nip, 0, 16);
		if(*p == ':')
			p++;
	}
	return 0;
}

static Ether *
newether(int ctlrno)
{
	Ether *ether;

	ether = smalloc(sizeof(Ether));
	ether->ctlrno = ctlrno;
	ether->tbdf = BUSUNKNOWN;
	ether->mbps = 1000;
	return ether;
}

static int
ethercardno(Ether *ether)
{
	int i, cardno;

	USED(ether);
	if(isaconfig("ether", ether->ctlrno, ether) == 0)
		return -1;
	for(cardno = 0; cards[cardno].type; cardno++)
		if(cistrcmp(cards[cardno].type, ether->type) == 0) {
			/* nothing sets nopt nor opt any more */
			for(i = 0; i < ether->nopt; i++)
				if(strncmp(ether->opt[i], "ea=", 3) == 0 &&
				    parseether(ether->ea, &ether->opt[i][3]))
					memset(ether->ea, 0, Eaddrlen);
			break;
		}
	return cardno;
}

static char *
etherconffmt(char *p, char *e, Ether *ether, int cardno)
{
	p = seprint(p, e, "#l%d: %s: ", ether->ctlrno, cards[cardno].type);
	if (ether->pcidev)
		p = seprint(p, e, "%#ux/%#ux ",
			ether->pcidev->vid, ether->pcidev->did);
	if(ether->mbps >= 1000)
		p = seprint(p, e, "%dGbps", ether->mbps/1000);
	else
		p = seprint(p, e, "%dMbps", ether->mbps);
	p = seprint(p, e, " regs %#p", ether->port);
	if (ether->irq)
		p = seprint(p, e, " irq %d",
			(ushort)(ether->irq & ~Attachenable));
	if(ether->mem)
		p = seprint(p, e, " addr %#p", ether->mem);
	if(ether->size)
		p = seprint(p, e, " size %lld", (vlong)ether->size);
	return seprint(p, e, ": %2.2ux%2.2ux%2.2ux%2.2ux%2.2ux%2.2ux\n",
		ether->ea[0], ether->ea[1], ether->ea[2],
		ether->ea[3], ether->ea[4], ether->ea[5]);
}

/*
 * input queues are allocated by ../port/netif.c:/^openfile.
 * the size will be the last argument to netifinit() below.
 *
 * output queues should be small, to minimise `bufferbloat',
 * which confuses tcp's feedback loop.  at 1Gb/s, it only takes
 * ~15µs to transmit a full-sized non-jumbo packet.
 */
static void
etherallocqs(Ether *ether, char *name)
{
	ulong bsz;

	if (ether->mbps >= 1000)
		bsz = 512*1024;
	else
		bsz = 256*1024;
	netifinit(ether, name, Ntypes, bsz);
	if(ether->oq == 0)
		ether->oq = qopen(bsz, Qmsg, 0, 0);
	if(ether->oq == 0)
		panic("etherprobe: no output q for %s", name);
}

static Ether*
etherprobe(int cardno, int ctlrno)
{
	Ether *ether;
	char buf[128], name[32];

	ether = newether(ctlrno);
	if(cardno < 0)
		cardno = ethercardno(ether);
	if((uint)cardno >= MaxEther || cards[cardno].type == nil ||
	    cards[cardno].reset(ether) < 0){
		free(ether);
		return nil;
	}

	snprint(name, sizeof(name), "ether%d", ctlrno);
	/*
	 * If ether->irq is <0, it is a hack to indicate no interrupt used by
	 * ethersink.  irq 0 is actually the main timer, but here it indicates
	 * no irq assigned yet, so we'll pick one, perhaps in the driver or
	 * some other way to configure interrupts for itself (e.g., MSI).
	 */
	if(ether->irq > 0 && !(ether->irq & Attachenable))
		enableintr(ether, ether->interrupt, ether, name);
	/* else enable in attach instead to delay interrupts */
	etherconffmt(buf, buf + sizeof buf, ether, cardno);
	print(buf);

	etherallocqs(ether, name);
	ether->alen = Eaddrlen;
	memmove(ether->addr, ether->ea, Eaddrlen);
	memset(ether->bcast, 0xFF, Eaddrlen);
	return ether;
}

static void
etherreset(void)
{
	Ether *ether;
	int cardno, ctlrno;

	fmtinstall('E', eipfmt);
	fmtinstall('I', eipfmt);
	fmtinstall('M', eipfmt);
	fmtinstall('V', eipfmt);
	fmtinstall('i', eipfmt);		/* paranoia */
	fmtinstall(L'Æ', etherfmt);

	for(ctlrno = 0; ctlrno < MaxEther; ctlrno++)
		if((ether = etherprobe(-1, ctlrno)) != nil)
			etherxx[ctlrno] = ether;

	if(getconf("*noetherprobe"))
		return;

	cardno = ctlrno = 0;
	while(cards[cardno].type != nil && ctlrno < MaxEther)
		if(etherxx[ctlrno] != nil)
			ctlrno++;
		else if((ether = etherprobe(cardno, ctlrno)) == nil)
			cardno++;
		else
			etherxx[ctlrno++] = ether;
	if (ctlrno == 0) {
		print("no known ethernet interfaces found\n");
		pcihinv(nil);
		delay(1000);
		for(;;)
			halt();
	}
}

static void
ethershutdown(void)
{
	Ether *ether;
	int i;

	for(i = 0; i < MaxEther; i++){
		ether = etherxx[i];
		if(ether != nil)
			if(ether->shutdown == nil)
				print("#l%d: no shutdown function\n", i);
			else
				(*ether->shutdown)(ether);
	}
}

#define POLY 0xedb88320

/* really slow 32 bit crc for ethers */
ulong
ethercrc(uchar *p, int len)
{
	int i, j;
	ulong crc, b;

	crc = ~0ul;
	for(i = 0; i < len; i++){
		b = *p++;
		for(j = 0; j < 8; j++){
			crc = (crc>>1) ^ (((crc^b) & 1) ? POLY : 0);
			b >>= 1;
		}
	}
	return crc;
}

Dev etherdevtab = {
	'l',
	"ether",

	etherreset,
	devinit,
	ethershutdown,
	etherattach,
	etherwalk,
	etherstat,
	etheropen,
	ethercreate,
	etherclose,
	etherread,
	etherbread,
	etherwrite,
	etherbwrite,
	devremove,
	etherwstat,
};

enum {
	Ethidlen	= 32,
};

/* common to intel *gbe drivers, so far */
int
etherfmt(Fmt* fmt)
{
	char *p;
	int r;
	Ctlr *ctlr;
	Ethident *ethid;

	if((p = malloc(Ethidlen)) == nil)
		return fmtstrcpy(fmt, "(etherfmt)");
	switch(fmt->r){
	case L'Æ':
	case L'æ':				/* compatibility with old */
		ctlr = va_arg(fmt->args, Ctlr *);
		if(ctlr == nil) {
			snprint(p, Ethidlen, "#l?");
			break;
		}
		/* Ethident must be first member of Ctlr */
		ethid = (Ethident *)ctlr;
		if (ethid->edev == nil)
			snprint(p, Ethidlen, "#l?: %s", ethid->prtype);
		else
			snprint(p, Ethidlen, "#l%d: %s",
				ethid->edev->ctlrno, ethid->prtype);
		break;
	default:
		snprint(p, Ethidlen, "(etherfmt)");
		break;
	}
	r = fmtstrcpy(fmt, p);
	free(p);
	return r;
}

void
etherenableirqs(Ether *edev)		/* enable all irqs known to ioconf */
{
	int realirq, irq, nirqs;
	char name[16];
	Ioconf *ioc;

	if(edev->irq == 0 || !(edev->irq & Attachenable))
		return;			/* already done by reset */
	snprint(name, sizeof(name), "ether%d", edev->ctlrno);
	realirq = edev->irq & ~Attachenable;

	ioc = ioconf("ether", edev->ctlrno);
	nirqs = ioc? ioc->xirqs: 0;
	for (irq = realirq + 1; nirqs > 0; nirqs--, irq++) {
		edev->irq = irq;
		enableintr(edev, edev->interrupt, edev, name);
	}

	edev->irq = realirq;
	enableintr(edev, edev->interrupt, edev, name);	/* main irq */
}

/* is low 48 bits of addr non-zero and not all ones? */
int
etherismacset(uvlong addr)
{
	return addr == 0 || addr == VMASK(8*Eaddrlen)? 0: 1;
}

/*
 * returns true if we set the mac in ra to the default, from ether0mac.
 * regadd is the mac read from the device registers.
 */
int
ethersetmac(uchar *ra, int ctlrno, uvlong regadd)
{
	int i;

	if (etherismacset(regadd)) {
		for (i = 0; i < Eaddrlen; i++) {
			ra[i] = regadd;
			regadd >>= 8;
		}
		return 0;
	} else {			/* regs cleared by reset or u-boot */
		memmove(ra, ether0mac, sizeof ra);
		ra[Eaddrlen-1] += ctlrno;	/* big-endian mac */
		return 1;
	}
}
