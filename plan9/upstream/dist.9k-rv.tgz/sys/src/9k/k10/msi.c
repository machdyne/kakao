/*
 * Message-Signalled Interrupts.  Available from PCI 2.2 and required in PCI-E.
 */
#include "u.h"
#include "../port/lib.h"
#include "mem.h"
#include "dat.h"
#include "fns.h"

#include "apic.h"
#include "io.h"

typedef struct Buggymsi Buggymsi;
struct Buggymsi {
	ushort	vid;		/* pci vendor id */
	ushort	did;		/* " device " */
};

static Buggymsi buggymsi[] = {	/* also update 9/pc/mp.c */
			/* 951 msi generates lapic errors & spurious intrs */
	Vsamsung, 0xa802, /* Samsung NVMe SSD SM951/PM951 (m.2 via pcie adapter) */
	Vintel, 0x10a4,	/* intel 82571s, from intel erratum 63 */
	Vintel, 0x105e,
	Vintel, 0x107d,	/* intel 82572s, " */
	Vintel, 0x107e,
	Vintel, 0x107f,
	Vintel, 0x10b9,
//	Vmoschip, 0x9904, /* startech PEX4S553B.02010200 4-port serial card */
};

static char *msiconf;

static void
whynomsi(Vctl *v, Pcidev *pcidev)
{
	if (pcigetmsixcap(pcidev) >= 0)
		print("%s: msi-x offered but not msi! using neither\n", v->name);
	if (pcigetpciecap(pcidev) >= 0)
		print("%s: %T: vid %ux did %ux broken pci-e device NOT offering"
			" msi, but it's required for pci-e!\n",
			v->name, pcidev->tbdf, pcidev->vid, pcidev->did);
	else
		print("%s: %T: device is pci behind a bridge, so no msi.  "
			"phooey!\n", v->name, pcidev->tbdf);
}

static int
isdevmsibuggy(Pcidev *pcidev)
{
	Buggymsi *bm;

	for (bm = buggymsi; bm < buggymsi + nelem(buggymsi); bm++)
		if (pcidev->vid == bm->vid && pcidev->did == bm->did)
			return 1;
	return 0;
}

/*
 * use message-signalled interrupt if available; they are mandatory for pci-e
 * devices, with an exception for pcie-pci bridges.  msi interrupt delivery has
 * less overhead than via an i/o apic (about 1/3rd).
 *
 * msi and msi-x may both be available (e.g., some pci-e devices), but only one
 * can be used on a given device.  msi-x seems much more complicated for little
 * benefit.
 */
static int
trymsi(Vctl *v, Pcidev *pcidev)
{
	Msi msi;
	Msi *msip;

	v->ismsi = 0;
	if (msiconf == nil)
		msiconf = getconf("*msi");
	if (v->triedmsi || pcidev == nil ||
	    msiconf && strcmp(msiconf, "no") == 0)
		return -1;
	v->triedmsi = 1;
	msip = &msi;
	memset(msip, 0, sizeof msi);
	if (pcigetmsi(pcidev, msip) == -1) {	/* no msi?  find out why. */
		whynomsi(v, pcidev);
		return -1;
	}

	if (msiconf && strcmp(msiconf, "print") == 0) {
		print("%s: %T: vid %ux did %ux offering msi\n",
			v->name, pcidev->tbdf, pcidev->vid, pcidev->did);
		delay(20);
	}
	if (isdevmsibuggy(pcidev)) {
		print("%s: %T: vid %ux did %ux known to be buggy; refusing msi\n",
			v->name, pcidev->tbdf, pcidev->vid, pcidev->did);
		return -1;
	}

	v->ismsi = 1;
	msip->ctl &= ~Msimme;		/* single-message msi */
	msip->ctl |= Msienable;
	msip->addr = (uvlong)Lapicphys | v->lapic<<12 | Msirhtocpuid;
	msip->data = Msitrglevel | Msitrglvlassert | Msidlvfixed | v->vno;
	pcisetmsi(pcidev, msip);

	DBG("%s: msi enabled at vector %d lapic %d for %T\n",
		v->name, v->vno, v->lapic, pcidev->tbdf);
	delay(20);
	return v->vno;
}

int
msinordt(Vctl *v, Pcidev *pcidev, ulong *hip, ulong *lop, int vecno)
{
	pickintrcpu(hip, lop, v);	/* assign a cpu */
	v->vno = vecno;
	v->lapic = *hip >> Ioapicnoshft;
	if (pcidev && trymsi(v, pcidev) >= 0)
		pcinointrs(pcidev);	/* msi on: no legacy pci intrs */
	else
		vecno = -1;
	return vecno;
}
