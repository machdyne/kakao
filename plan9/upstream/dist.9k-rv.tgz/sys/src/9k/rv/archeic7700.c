/*
 * eic7700x-specific stuff (u84 for e.g., premier p550): soc init, reset
 *
 * can't configure the u74 l2 prefetcher.  sifive's cache prefetcher Csrs are
 * M-mode only, and ctl and morectl registers accept writes but they
 * have no effect.
 *
 * p550 pci info from u-boot
 *	=> pci
 *	BusDevFun  VendorId   DeviceId   Device Class       Sub-Class
 *	_____________________________________________________________
 *	00.00.00   0x1fe1     0x2030     Bridge device           0x04
 *	=> pci enum
 *	=> pci regions
 *	Buses 00-01
 *	#   Bus start          Phys start         Size                Flags
 *	0   0x000000004f800000 0x000000004f800000 0x0000000000800000  io
 *	1   0x0000000040000000 0x0000000040000000 0x000000000f000000  mem
 *	2   0x0000000080000000 0x0000000080000000 0x0000000400000000  mem sysmem
 *	=> pci display 0.0.0
 *	00000000: 20301fe1 00100007 06040001 00010008
 *	00000010: 40000000 48000000 00010100 0000f000
 *	00000020: 48004810 0001fff1 00000000 00000000
 *	00000030: 00000000 00000040 00000000 000001ff
 *
 * eswin manual says
 *	0x40000000	ecam: remote ep configure & bar0 registers in rc mode
 *	0x54000000	dbi: 4kb std config registers
 *	0x50000000	elbi: top csr non-std registers
 *	0x8000000000	remote rc memory in ep mode or mem map access remote
 *			ep in rc mode
 */

#include "u.h"
#include "../port/lib.h"
#include "mem.h"
#include "dat.h"
#include "fns.h"
#include "io.h"
#include "riscv64.h"
// #include "../port/dbgprint.h"

/* dwc pcie stuff */
enum {
	Smmuregs =	0x50c00000,	/* arm ssmuv3 registers */
	Scuregs =	0x51810000,
};
/* eswin clock enable and reset bits */
enum {
	Clkrst =	0x51828000,	/* sys crg */
	Eth0clk =	Clkrst + 0x158,
	Eth1clk =	Clkrst + 0x15c,

	Ethclkena =	1<<0,
	Rmiiclkena =	1u<<31,
};
enum {
	Pcieaclk =	Clkrst + 0x170,

	Aclken =	1u<<31,
};
enum {
	Pciecfgclk =	Clkrst + 0x174,
	Snocclk =	Clkrst + 0x400,
	Dmarst =	Clkrst + 0x41c,

	Eth0rstdeass =	1<<26,
	Eth1rstdeass =	1<<25,
};
enum {
	Pcieclk =	Clkrst + 0x420,	/* pcie clock deassert bits */
};

/*
 * For DWC v4.80a+ the iATU registers are "unrolled".  Each region has a 0x200
 * block, and outbound/inbound are distinguished by bit 8 of the region offset.
 */
enum { Outbound, Inbound };

static void
setregl(uintptr pa, ulong val)
{
	*(ulong *)KADDR(pa) = val;
	coherence();
	delay(1);			/* let it take effect */
}

static void
uncachedchk(void)
{
	uvlong d1, d2;
	uvlong *p1, *p2;

	cachedwbse(_main, sizeof(uvlong));
	p1 = (uvlong *)_main;
	p2 = uncachedview(p1);
	d1 = *p1;
	d2 = *p2;
	if (d1 == d2) {
		if (soc.newmach)
			iprint("uncached view access okay.\n");
	} else
		iprint("uncached view access failed: *%#p = %#llux; "
			"*%#p = %#llux\n", p1, d1, p2, d2);
}

/*
 * ensure that all the bloody fiddly clock signals are on.
 * assumes mmu is on.
 */
static void
eic7700init(void)
{
	int n;

	DBG("eic7700init...");
	for (n = 0; n < 2; n++)
		*(ulong *)KADDR(Eth0clk + 4*n) |= Ethclkena | Rmiiclkena;
	coherence();
	delay(1);

//	*(ulong *)KADDR(Dmarst) |= Eth0rstdeass | Eth1rstdeass;
	*(ulong *)KADDR(Pcieaclk) |= Aclken;

	/* set all reset deassert bits */
	setregl(Dmarst, ~0);
	setregl(Pcieclk, 0);
	delay(100);
	setregl(Pcieclk, ~0);
	setregl(Snocclk, ~0);
	setregl(Pciecfgclk, ~0);

	dwcpcieinit(KADDR(Smmuregs), Scuregs);

	/* check uncached access sanity */
	if (soc.uncached)
		uncachedchk();
}

void (*socinit)(void) = eic7700init;
