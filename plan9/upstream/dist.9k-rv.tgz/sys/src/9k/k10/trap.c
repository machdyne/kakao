/*
 * traps, faults, system call entry
 */
#include	"u.h"
#include	"../port/lib.h"
#include	"mem.h"
#include	"dat.h"
#include	"fns.h"
#include	"../port/error.h"

#include	"io.h"
#include	<tos.h>
#include	"ureg.h"
#include	"amd64.h"

enum {				/* Ureg->err for page faults: causes */
	Pfp	= 1<<0,		/* page table entry Present bit */
	Pfwr	= 1<<1,		/* write (not read) access */
	Pfuser	= 1<<2,		/* user mode access */
	Pfrsvd	= 1<<3,		/* reserved page table bit set */
	Pfinst	= 1<<4,		/* instruction access */
};

/* syscall stack frame (on amd64 at least); used for notes */
typedef struct NFrame NFrame;
struct NFrame
{
	uintptr	ip;
	Ureg*	arg0;
	char*	arg1;
	char	msg[ERRMAX];
	Ureg*	old;
	Ureg	ureg;
};

Intrsvcret	lapicerror(Ureg*, void*);
Intrsvcret	lapicspurious(Ureg*, void*);

static Intrsvcret debugbpt(Ureg*, void*);
static Intrsvcret faultamd64(Ureg*, void*);
static Intrsvcret doublefault(Ureg*, void*);
static Intrsvcret gpf(Ureg *, void *);
static Intrsvcret unexpected(Ureg*, void*);
static Intrsvcret unwanted(Ureg*, void*);

static void dumpstackwithureg(Ureg*);
static void dumpgpr(Ureg*);

static Lock vctllock;
static Vctl *vctl[IdtMAX+1];

enum
{
	Ntimevec = 20,		/* number of time buckets for each intr */
};
ulong intrtimes[IdtMAX+1][Ntimevec];

int
inop(int)
{
	return 0;
}

int
vecinuse(uint vec)
{
	return vec >= nelem(vctl) || vctl[vec] != 0;
}

Vctl *
newvec(Intrsvcret (*f)(Ureg*, void*), void* a, int tbdf, char *name)
{
	Vctl *v;

	v = smalloc(sizeof(Vctl));
	v->tbdf = tbdf;
	v->f = f;
	v->a = a;
	v->cpu = -1;			/* could be any cpu until overridden */
	v->eoi = v->isr = inop;		/* always safe to call through these */
	strncpy(v->name, name, KNAMELEN);
	v->name[KNAMELEN-1] = 0;
	return v;
}

/* old 9k interface; returns new Vctl */
void*
intrenable(int irq, Intrsvcret (*f)(Ureg*, void*), void* a, int tbdf, char *name)
{
	int vno;
	Vctl *v;
	extern int ioapicintrenable(Vctl*);

	if(f == nil){
		print("intrenable: nil handler for %d, tbdf %#ux for %s\n",
			irq, tbdf, name);
		return nil;
	}

	v = newvec(f, a, tbdf, name);
	v->isintr = 1;
	v->irq = irq;

	ilock(&vctllock);
	vno = ioapicintrenable(v);	/* may set v->irq */
	if(vno == -1){
		iunlock(&vctllock);
		print("intrenable: couldn't enable irq %d, tbdf %#ux for %s\n",
			v->irq, tbdf, v->name);
		free(v);
		return nil;
	}
	if(vctl[vno]){
		iunlock(&vctllock);
		panic("vno %d for %s already allocated by %s",
			vno, v->name, vctl[vno]->name);
	}
	/* we assert that vectors are unshared, though irqs may be shared */
	v->vno = vno;
	vctl[vno] = v;
	iunlock(&vctllock);
	DBG("intrenable %s irq %d vector %d\n", name, v->irq, vno);

	/*
	 * Return the assigned vector so intrdisable can find
	 * the handler; the IRQ is useless in the wonderful world
	 * of the IOAPIC.
	 */
	return v;
}

/*
 * new, portable interface (between 9 and 9k); returns 0 or -1,
 * with vector in ic->vector and irq and vno in vector.
 */
int
enableintr(Intrcommon *ic, Intrsvcret (*f)(Ureg*, void*), void *ctlr, char *name)
{
	Pcidev *pcidev;
	Vctl *v;

	pcidev = ic->pcidev;
	ic->vector = v = intrenable(ic->irq, f, ctlr,
		(pcidev? pcidev->tbdf: BUSUNKNOWN), name);
	if (v)
		ic->intrenabled = 1;
	return v? 0: -1;
}

int
intrdisable(void* vector)
{
	Pcidev *pcidev;
	Vctl *v;
	extern int ioapicintrdisable(uint);

	ilock(&vctllock);
	v = vector;
	if(v == nil || vctl[v->vno] != v)
		panic("intrdisable: v %#p", v);
	if (v->ismsi) {
		pcidev = pcimatchtbdf(v->tbdf); USED(pcidev);
		if (TODO && pcidev) {		/* TODO: test msi, intr off */
			pcimsioff(v, pcidev);
			pcinointrs(pcidev);
		}
	} else
		ioapicintrdisable(v->vno);
	vctl[v->vno] = nil;
	iunlock(&vctllock);

	free(v);
	return 0;
}

/* new, portable interface (between 9 and 9k) */
int
disableintr(Intrcommon *ic, Intrsvcret (*)(Ureg*, void*), void *, char *)
{
	if (ic->vector == nil || ic->intrenabled == 0)
		return 0;
	if (intrdisable(ic->vector) < 0)
		return -1;
	ic->intrenabled = 0;
	ic->vector = nil;
	return 0;
}

static char *
vctlseprint(char *s, char *e, Vctl *v, int vno)
{
	s = seprint(s, e, "%3d %3d %10llud %3s %.*s", vno, v->irq, v->count,
		v->ismsi? "msi": "- ", KNAMELEN, v->name);
	if (v->unclaimed || v->intrunknown)
		s = seprint(s, e, " unclaimed %lud unknown %lud", v->unclaimed,
			v->intrunknown);
	if(v->cpu >= 0)
		s = seprint(s, e, " cpu%d", v->cpu);
	if(BUSTYPE(v->tbdf) == BusPCI && v->lapic >= 0)
		s = seprint(s, e, " lapic %d", v->lapic);
	return seprint(s, e, "\n");
}

static long
irqallocread(Chan*, void *vbuf, long n, vlong offset)
{
	char *buf, *p, *e, str[90];
	int ns, vno;
	long oldn;
	Vctl *v;

	if(n < 0 || offset < 0)
		error(Ebadarg);

	oldn = n;
	buf = vbuf;
	e = str + sizeof str;
	for(vno = 0; vno < nelem(vctl); vno++)
		for(v = vctl[vno]; v; v = v->next){
			/* v is a trap, not yet seen?  adjust to taste */
			if (v->isintr == 0 && v->count == 0)
				continue;
			ns = vctlseprint(str, e, v, vno) - str;
			if(ns <= offset) { /* if do not want this, skip entry */
				offset -= ns;
				continue;
			}
			/* skip offset bytes */
			ns -= offset;
			p = str+offset;
			offset = 0;

			/* write at most min(n,ns) bytes */
			if(ns > n)
				ns = n;
			memmove(buf, p, ns);
			n -= ns;
			buf += ns;

			if(n == 0)
				return oldn;
		}
	return oldn - n;
}

void
trapenable(int vno, Intrsvcret (*f)(Ureg*, void*), void* a, char *name)
{
	Vctl *v;

	if(vno < 0 || vno > IdtMAX)
		panic("trapenable: vno %d", vno);
	v = newvec(f, a, BUSUNKNOWN, name);
	v->isintr = 0;

	ilock(&vctllock);
	v->next = vctl[vno];
	vctl[vno] = v;
	iunlock(&vctllock);
}

void
trapinit(void)
{
	/*
	 * Special traps.
	 * Syscall() is called directly without going through trap().
	 */
	/*
	 * Need to set BPT interrupt gate - here or in vsvminit?
	 */
	trapenable(IdtBP, debugbpt, 0, "#BP");
	trapenable(IdtPF, faultamd64, 0, "#PF");
	trapenable(IdtDF, doublefault, 0, "#DF");
	trapenable(Idt0F, unexpected, 0, "#15");
	trapenable(IdtMC, unexpected, 0, "machine check");
	trapenable(IdtGP, gpf, 0, "GPF");
	trapenable(IdtSPURIOUS, lapicspurious, 0, "lapic spurious");
	trapenable(IdtERROR, lapicerror, 0, "lapic error");
	nmienable();

	addarchfile("irqalloc", 0444, irqallocread, nil);
}

static char* excname[32] = {
	"#DE",					/* Divide-by-Zero Error */
	"#DB",					/* Debug */
	"#NMI",					/* Non-Maskable-Interrupt */
	"#BP",					/* Breakpoint */
	"#OF",					/* Overflow */
	"#BR",					/* Bound-Range */
	"#UD",					/* Invalid-Opcode */
	"#NM",					/* Device-Not-Available */
	"#DF",					/* Double-Fault */
	"#9 (reserved)",
	"#TS",					/* Invalid-TSS */
	"#NP",					/* Segment-Not-Present */
	"#SS",					/* Stack */
	"#GP",					/* General-Protection */
	"#PF",					/* Page-Fault */
	"#15 (reserved)",
	"#MF",					/* x87 FPE-Pending */
	"#AC",					/* Alignment-Check */
	"#MC",					/* Machine-Check */
	"#XF",					/* SIMD Floating-Point */
	"#20 (reserved)",
	"#21 (reserved)",
	"#22 (reserved)",
	"#23 (reserved)",
	"#24 (reserved)",
	"#25 (reserved)",
	"#26 (reserved)",
	"#27 (reserved)",
	"#28 (reserved)",
	"#29 (reserved)",
	"#30 (reserved)",
	"#31 (reserved)",
};

/*
 *  keep histogram of interrupt service times
 */
void
intrtime(Mach*, int vno)
{
	ulong diff;
	ulong x;

	x = perfticks();
	diff = x - m->perf.intrts;
	m->perf.intrts = x;

	m->perf.inintr += diff;
	if(up == nil && m->perf.inidle > diff)
		m->perf.inidle -= diff;

	diff /= m->cpumhz*100;		/* quantum = 100µsec */
	if(diff >= Ntimevec)
		diff = Ntimevec-1;
	intrtimes[vno][diff]++;
}

/* prepare to go to user space by updating profiling counts */
void
kexit(Ureg *ureg)
{
	uvlong t;
	Tos *tos;

	if (up == nil)
		return;

	/* precise time accounting, kernel exit */
	tos = (Tos*)(USTKTOP-sizeof(Tos));
	cycles(&t);
	if (t >= up->kentry)
		tos->kcycles += t - up->kentry;
	tos->pcycles = up->pcycles;
	tos->pid = up->pid;

	/*
	 * system calls set type == ~(uvlong)0.
	 * If this Ureg is not from a system call, call trapreturn explicitly
	 * to make sure we use IRET and not SYSRET.
	 * Otherwise, if a process is interrupted by a trap and ends up
	 * calling a note handler, the noted(NCONT) system call will use
	 * SYSRET to return to the trap context, smashing some of the
	 * registers that were live at the time of the trap.
	 */
	if(ureg->type != ~(uvlong)0)
		trapreturn(ureg);
}

static void
posttrapnote(uint vno, char *name)
{
	char buf[ERRMAX];

	spllo();
	snprint(buf, sizeof buf, "sys: trap: %s",
		vno < nelem(excname)? excname[vno]: name);
	postnote(up, 1, buf, NDebug);
}

/*
 * print and ignore a few early traps, disable after that.
 * apu2 secondary cores (at least with coreboot 20170228, probably firmware
 * 4.0.4) get a vector 39 interrupt (IdtPIC+7, irq 7 [lpt/spurious]) at start
 * when allowing interrupts.
 */
static void
trapunassigned(Ureg *ureg, int vno)
{
	int disabled;
	char *dis;
	static long traps;

	disabled = 0;
	apicisr(vno);
	ioapicintrtbloff(vno);
	if (!active.exiting && !active.rebooting) {
		if (ainc(&traps) > 3*sys->nmach) {
			vctl[vno] = nil;
			disabled++;
		}
		dis = disabled? ", disabled": "";
		if (vno < IdtPIC)		/* processor trap? */
			panic("cpu%d: trap for unassigned vector %d (%#x) "
				"@ %#p%s", m->machno, vno, vno, ureg->ip, dis);
		if (!thisisapu2 || vno != IdtPIC+7 || traps > 2*sys->nmach)
			iprint("cpu%d: intr for unassigned vector %d (%#x) "
			    "@ %#p%s\n", m->machno, vno, vno, ureg->ip, dis);
	}
	apiceoi(vno);
}

static void
badtrap(Ureg *ureg, uint vno, int user)
{
	char *name;
	char buf[32];

	if(vno < nelem(excname))
		name = excname[vno];
	else if (vno < nelem(vctl) && vctl[vno])
		name = vctl[vno]->name;
	else {
		snprint(buf, sizeof buf, "vector #%d", vno);
		name = buf;
	}
	if (user) {
		iprint("pid %d %s: unexpected user trap %s @ %#p\n",
			up->pid, up->text, name, ureg->ip);
		posttrapnote(vno, name);
	} else
		panic("unexpected kernel trap %s @ %#p", name, ureg->ip);
}

static Intrsvcret
unexpected(Ureg* ureg, void*)
{
	iprint("unexpected trap %llud; ignoring\n", ureg->type);
	return Intrforme;
}

static Intrsvcret
unwanted(Ureg* ureg, void*)
{
	badtrap(ureg, ureg->type, userureg(ureg));
	return Intrforme;
}

enum {
	/* msr instructions */
	Msr0 = 0xf,
	Rdmsr1 = 0x32,
	Wrmsr1 = 0x30,
};

static Intrsvcret
gpf(Ureg* ureg, void*)
{
	int user;
	uchar *inst;

	/*
	 * on a fault, pc points to the faulting instruction.
	 * tries to validate pc so a wild jump doesn't cause recursive GPFs.
	 */
	inst = (uchar *)ureg->pc;
	user = userureg(ureg);
	if (!user && inst >= (uchar *)_main && inst < (uchar *)etext &&
	    inst[0] == Msr0 && (inst[1] == Rdmsr1 || inst[1] == Wrmsr1)) {
		iprint("gpf: bad msr #%#llux in rd/wrmsr at %#p\n",
			ureg->cx, ureg->pc);
		if (inst[1] == Rdmsr1)
			ureg->ax = ureg->dx = 0;
		ureg->pc += 2;			/* pretend it succeeded */
		return Intrforme;
	}
	iprint("gpf: cr2 address %#p\n", cr2get());
	badtrap(ureg, ureg->type, user);
	return Intrforme;
}

static void
trapunexpected(Ureg *ureg, uint vno, int user)
{
	dumpregs(ureg);
	if(!user){
		ureg->sp = (uintptr)&ureg->sp;
		dumpstackwithureg(ureg);
	}
	badtrap(ureg, vno, user);
}

static void
trapunknown(Ureg *ureg, int vno, int user)
{
	if(vno == IdtNMI){
		nmienable();
		if(m->machno == 0)
			panic("NMI @ %#p", ureg->ip);
		else {
			iprint("nmi: cpu%d: PC %#p\n", m->machno, ureg->ip);
			lock(&active);
			cpuinactive(m->machno);
			unlock(&active);
			for(;;)
				halt();
		}
	} else	// if (vno >= IdtIOAPIC && vno <= IdtMAX)
		/*
		 * In the range of vectors that we assign.
		 * We shouldn't get these.  Perhaps they are latched
		 * interrupts from the bootstrap, not cleared by disabling
		 * all PCI interrupts, legacy and MSI?  Maybe need to reset
		 * I/O APICs' redirection tables?
		 */
		trapunassigned(ureg, vno);
//	else
//		trapunassigned(ureg, vno);	/* for apu2, at least */
//		// trapunexpected(ureg, vno, user);
	USED(user);
}

static int
callintrsvc(Ureg *ureg, Vctl *vec)
{
	int forme, count;
	Intrsvcret (*isr)(Ureg *, void *);
	Vctl *v;

	count = 0;
	if (vec == nil)
		return count;
	for(v = vec; v != nil; v = v->next) {
		isr = v->f;
		if (isr == nil) {
			iprint("intr: no isr for vector %d\n", v->vno);
			continue;
		}
		forme = (*isr)(ureg, v->a);
		splhi();		/* in case isr dropped PL */
		if (forme) {
			v->count++;	/* vlong, so can't ainc */
			count++;
		}
	}
	if (count > 0 && vec->vno >= IdtPIC && vec->vno != IdtSYSCALL)
		m->lastintr = vec->irq;
	return count;
}

static void
intrmissed(Ureg *ureg, int vno)
{
	int count, pvno;
	Vctl *vec;

	count = 0;
	/* misdirected interrupt?  try the other irqs */
	for (pvno = IdtPIC; count == 0 && pvno < IdtPIC+16; pvno++)
		if (pvno != vno)
			count += callintrsvc(ureg, vctl[pvno]);
	/*
	 * count missed intr for irqalloc.
	 * nuc is suddenly getting lots of these, so don't print.
	 * possibly usb controller is confusing things.
	 */
	vec = vctl[vno];
	if (vec && strncmp(vec->name, "usb", 3) == 0) {
		vec->count++;
		if (vctl[IdtSPURIOUS])
			vctl[IdtSPURIOUS]->count++;
	}
	if (count == 0) {
		/* apu2 gets lots of these at 65 (ether0) */
		if(TODO && !isapu())
			iprint("cpu%d: spurious interrupt for vector %d (%s)\n",
				m->machno, vno, vec->name);
	} else
		iprint("cpu%d: misdirected interrupt for vector %d (%s)\n",
			m->machno, vno, vec->name);
}

/*
 *  All traps come here.  It is slower to have all traps call trap()
 *  rather than directly vectoring the handler.  However, this avoids a
 *  lot of code duplication and possible bugs.  The only exception is
 *  for a system call.
 *  Trap is called with interrupts disabled via interrupt-gates.
 *
 *  to work arounds bugs in MPS and ACPI tables, if there is no work
 *  for a given IRQ, poll them all.
 */
void
trap(Ureg* ureg)
{
	int clockintr, vno, user, count;
	Vctl *vec;

	m->perf.intrts = perfticks();
	user = userureg(ureg);
	if(user){
		up->dbgreg = ureg;
		cycles(&up->kentry);
	}

	clockintr = 0;
	vno = ureg->type;
	if(vec = vctl[vno]){
		vec->isr(vno);
		count = callintrsvc(ureg, vec);
		vec->eoi(vno);	/* done with this intr; ready for next */
		if(vec->isintr) {
			intrtime(m, vno);
			m->intr++;
			if (count == 0)
				intrmissed(ureg, vno);
			if(vec->irq == IdtPIC+IrqCLOCK || vec->irq == IdtTIMER)
				clockintr = 1;
			else if (m->ilockdepth == 0)
				if(up)
					preempted();
		}
	} else if (user)
		posttrapnote(vno, "GOK");
	else
		trapunknown(ureg, vno, user);
	splhi();

	/* delaysched set because we held a lock or because our quantum ended */
	if(up && up->delaysched && clockintr && m->ilockdepth == 0){
		sched();
		splhi();
	}
	if(vec && vec->isintr)
		/*
		 * procs waiting for this interrupt could be on
		 * any cpu, so wake any mwaiting cpus.
		 * in case the cpus all raced into mwait, always wake.
		 */
		idlewake();

	if(user){
		if(up && (up->procctl || up->nnote))
			notify(ureg);
		kexit(ureg);
	}
}

/*
 * Dump general registers.
 * try to fit it on a cga screen (80x25).
 */
static void
dumpgpr(Ureg* ureg)
{
	if(up != nil)
		iprint("cpu%d: registers for %s %d\n",
			m->machno, up->text, up->pid);
	else
		iprint("cpu%d: registers for kernel\n", m->machno);

	iprint("ax\t%#16.16llux\t", ureg->ax);
	iprint("bx\t%#16.16llux\n", ureg->bx);
	iprint("cx\t%#16.16llux\t", ureg->cx);
	iprint("dx\t%#16.16llux\n", ureg->dx);
	iprint("di\t%#16.16llux\t", ureg->di);
	iprint("si\t%#16.16llux\n", ureg->si);
	iprint("bp\t%#16.16llux\t", ureg->bp);
	iprint("r8\t%#16.16llux\n", ureg->r8);
	iprint("r9\t%#16.16llux\t", ureg->r9);
	iprint("r10\t%#16.16llux\n", ureg->r10);
	iprint("r11\t%#16.16llux\t", ureg->r11);
	iprint("r12\t%#16.16llux\n", ureg->r12);
	iprint("r13\t%#16.16llux\t", ureg->r13);
	iprint("r14\t%#16.16llux\n", ureg->r14);
	iprint("r15\t%#16.16llux\n", ureg->r15);
	iprint("ds  %#4.4ux   es  %#4.4ux   fs  %#4.4ux   gs  %#4.4ux\n",
		ureg->ds, ureg->es, ureg->fs, ureg->gs);
	iprint("type\t%#llux\t", ureg->type);
	iprint("error\t%#llux\n", ureg->err);
	iprint("pc\t%#llux\t", ureg->ip);
	iprint("cs\t%#llux\n", ureg->cs);
	iprint("flags\t%#llux\t", ureg->flags);
	iprint("sp\t%#llux\n", ureg->sp);
	iprint("ss\t%#llux\t", ureg->ss);
	iprint("type\t%#llux\n", ureg->type);

	iprint("m\t%#16.16p\nup\t%#16.16p\n", m, up);
}

void
dumpregs(Ureg* ureg)
{
	if(getconf("*nodumpregs")){
		iprint("dumpregs disabled\n");
		return;
	}
	dumpgpr(ureg);

	/*
	 * Processor control registers.
	 * If machine check exception, time stamp counter, page size extensions
	 * or enhanced virtual 8086 mode extensions are supported, there is a
	 * CR4. If there is a CR4 and machine check extensions, read the machine
	 * check address and machine check type registers if RDMSR supported.
	 */
	iprint("cr0\t%#16.16llux\t", cr0get());
	iprint("cr2\t%#16.16llux\n", cr2get());
	iprint("cr3\t%#16.16llux\n", cr3get());

//	archdumpregs();
}

/*
 * Fill in enough of Ureg to get a stack trace, and call a function.
 * Used by debugging interface rdb.
 */
void
callwithureg(void (*fn)(Ureg*))
{
	Ureg ureg;

	ureg.ip = getcallerpc(&fn);
	ureg.sp = (uintptr)&fn;
	fn(&ureg);
}

static void
dumpstackwithureg(Ureg* ureg)
{
	uintptr l, v, i, estack;
	int x;

	if(ureg != nil)
		dumpregs(ureg);
	if(getconf("*nodumpstack")){
		iprint("dumpstack disabled\n");
		return;
	}
	iprint("dumpstack\n");

	x = 0;
	x += iprint("ktrace /kernel/path %#p %#p\n", ureg->ip, ureg->sp);
	i = 0;
	if(up != nil
//	&& (uintptr)&l >= (uintptr)up->kstack
	&& (uintptr)&l <= (uintptr)up->kstack+KSTACK)
		estack = (uintptr)up->kstack+KSTACK;
	else if((uintptr)&l >= m->stack && (uintptr)&l <= m->stack+MACHSTKSZ)
		estack = m->stack+MACHSTKSZ;
	else {
		if(up != nil)
			iprint("&up->kstack %#p &l %#p\n", up->kstack, &l);
		else
			iprint("&m %#p &l %#p\n", m, &l);
		return;
	}
	x += iprint("estackx %#p\n", estack);

	for(l = (uintptr)&l; l < estack; l += sizeof(uintptr)){
		v = *(uintptr*)l;
		if((KTZERO < v && v < (uintptr)etext)
		|| ((uintptr)&l < v && v < estack) || estack-l < 256){
			x += iprint("%#16.16p=%#16.16p ", l, v);
			i++;
		}
		if(i == 2){
			i = 0;
			x += iprint("\n");
		}
	}
	if(i)
		iprint("\n");
}

void
dumpstack(void)
{
	callwithureg(dumpstackwithureg);
}

static Intrsvcret
debugbpt(Ureg* ureg, void*)
{
	char buf[ERRMAX];

	if(up == 0)
		panic("kernel bpt");
	/* restore pc to instruction that caused the trap */
	ureg->ip--;
	snprint(buf, sizeof buf, "sys: breakpoint");
	postnote(up, 1, buf, NDebug);
	return Intrforme;
}

static Intrsvcret
doublefault(Ureg *ureg, void*)
{
	panic("double fault; pc %#llux", ureg->ip);
}

static Intrsvcret
faultamd64(Ureg* ureg, void*)
{
	uintptr addr;
	int read, user, insyscall;

	addr = cr2get();
	user = userureg(ureg);
//	if(!user && mmukmapsync(addr))
//		return Intrforme;

	/*
	 * There must be a user context.
	 * If not, the usual problem is causing a fault during
	 * initialisation before the system is fully up.
	 */
	if(up == nil)
		panic("faultamd64 with up == nil; pc %#p addr %#p", ureg->ip, addr);
	read = !(ureg->err & Pfwr);

	insyscall = up->insyscall;
	up->insyscall = 1;
	if(fault(addr, read) < 0){
		char buf[ERRMAX];

		/*
		 * It is possible to get here with !user if, for example,
		 * a process was in a system call accessing a shared
		 * segment but was preempted by another process which shrunk
		 * or deallocated the shared segment; when the original
		 * process resumes it may fault while in kernel mode.
		 * No need to panic this case, post a note to the process
		 * and unwind the error stack. There must be an error stack
		 * (up->nerrlab != 0) if this is a system call, if not then
		 * the game's a bogey.
		 */
		if(!user && (!insyscall || up->nerrlab == 0)){
			/* vpt fault, maybe? */
			iprint("fault: kseg0 %#p kseg1 %#p kseg2 %#p "
				"pml4base %#p\n",
				KSEG0, KSEG1, KSEG2, VZERO-256*TB);
			dumpregs(ureg);
			panic("fault: not repaired for addr %#p pc %#p",
				addr, ureg->ip);
		}
		snprint(buf, sizeof buf, "sys: trap: fault %s addr=%#p",
			(read? "read": "write"), addr);
		postnote(up, 1, buf, NDebug);
		if(insyscall)
			error(buf);
	}
	up->insyscall = insyscall;
	return Intrforme;
}

/*
 *  return the userpc the last exception happened at
 */
uintptr
userpc(Ureg* ureg)
{
	if(ureg == nil)
		ureg = up->dbgreg;
	return ureg->ip;
}

/* This routine must save the values of registers the user is not permitted
 * to write from devproc and then restore the saved values before returning.
 */
void
setregisters(Ureg* ureg, char* pureg, char* uva, int n)
{
	uvlong cs, flags, ss;
	ushort ds, es, fs, gs;

	ss = ureg->ss;
	flags = ureg->flags;
	cs = ureg->cs;
	gs = ureg->cs;
	fs = ureg->cs;
	es = ureg->cs;
	ds = ureg->cs;
	memmove(pureg, uva, n);
	ureg->ds = ds;
	ureg->es = es;
	ureg->fs = fs;
	ureg->gs = gs;
	ureg->cs = cs;
	ureg->flags = (ureg->flags & 0x00ff) | (flags & 0xff00);
	ureg->ss = ss;
}

/* Give enough context in the ureg to produce a kernel stack for
 * a sleeping process
 */
void
setkernur(Ureg* ureg, Proc* p)
{
	ureg->ip = p->sched.pc;
	ureg->sp = p->sched.sp+BY2SE;
}

uintptr
dbgpc(Proc *p)
{
	Ureg *ureg;

	ureg = p->dbgreg;
	return ureg? ureg->ip: 0;
}

/*
 * machine-specific system call and note code
 */

static void
vrfyuregaddrs(Ureg *nur)
{
	if(!okaddr(nur->ip, sizeof(ulong), 0) ||
	   !okaddr(nur->sp, sizeof(uintptr), 0)){
		qunlock(&up->debug);
		pprint("suicide: trap in noted pc=%#p sp=%#p\n",
			nur->ip, nur->sp);
		pexit("Suicide", 0);
	}
}

/*
 *   Return user to state before notify()
 */
void
noted(Ureg* cur, uintptr arg0)
{
	NFrame *nf;
	Note note;
	Ureg *nur;

	qlock(&up->debug);
	if(arg0 != NRSTR && !up->notified){
		qunlock(&up->debug);
		pprint("suicide: call to noted when not notified\n");
		pexit("Suicide", 0);
	}
	up->notified = 0;
	fpunoted();

	/* construct NFrame over ureg on stack */
	nf = up->ureg;

	/* sanity clause */
	if(!okaddr(PTR2UINT(nf), sizeof(NFrame), 0)){
		qunlock(&up->debug);
		pprint("suicide: bad ureg %#p in noted\n", nf);
		pexit("Suicide", 0);
	}

	/*
	 * Check the segment selectors are all valid.
	 * Only real machine dependency.
	 */
	nur = &nf->ureg;
	if(nur->cs != SSEL(SiUCS, SsRPL3) || nur->ss != SSEL(SiUDS, SsRPL3)
	|| nur->ds != SSEL(SiUDS, SsRPL3) || nur->es != SSEL(SiUDS, SsRPL3)
	|| nur->fs != SSEL(SiUDS, SsRPL3) || nur->gs != SSEL(SiUDS, SsRPL3)){
		qunlock(&up->debug);
		pprint("suicide: bad segment selector in noted\n");
		pexit("Suicide", 0);
	}

	/* don't let user change system flags */
	nur->flags &= (Of|Df|Sf|Zf|Af|Pf|Cf);
	nur->flags |= cur->flags & ~(Of|Df|Sf|Zf|Af|Pf|Cf);
	memmove(cur, nur, sizeof(Ureg));

	switch((int)arg0){
	case NCONT:
	case NRSTR:
		vrfyuregaddrs(cur);
		up->ureg = nf->old;
		qunlock(&up->debug);
		break;
	case NSAVE:
		vrfyuregaddrs(cur);
		qunlock(&up->debug);

		splhi();
		nf->arg1 = nf->msg;
		nf->arg0 = &nf->ureg;
		cur->bp = PTR2UINT(nf->arg0);
		nf->ip = 0;
		cur->sp = PTR2UINT(nf);
		break;
	default:
		memmove(&note, &up->lastnote, sizeof(Note));
		qunlock(&up->debug);
		pprint("suicide: bad arg %#p in noted: %s\n", arg0, note.msg);
		pexit(note.msg, 0);
		break;
	case NDFLT:
		memmove(&note, &up->lastnote, sizeof(Note));
		qunlock(&up->debug);
		if(note.flag == NDebug)
			pprint("suicide: %s\n", note.msg);
		pexit(note.msg, note.flag != NDebug);
		break;
	}
}

/*
 *  Call user, if necessary, with note.
 *  Pass user the Ureg struct and the note on his stack.
 */
int
notify(Ureg* ureg)
{
	int l;
	Mpl s;
	Note note;
	uintptr sp;
	NFrame *nf;

	if(up->procctl)
		procctl(up);
	if(up->nnote == 0)
		return 0;

	fpunotify(ureg);

	s = spllo();
	qlock(&up->debug);

	up->notepending = 0;
	memmove(&note, &up->note[0], sizeof(Note));
	if(strncmp(note.msg, "sys:", 4) == 0){
		l = strlen(note.msg);
		if(l > ERRMAX-sizeof(".. pc=0x0123456789abcdef"))
			l = ERRMAX-sizeof(".. pc=0x0123456789abcdef");
		seprint(note.msg+l, note.msg + ERRMAX, ".. pc=%#p", ureg->ip);
	}

	if(note.flag != NUser && (up->notified || up->notify == nil)){
		qunlock(&up->debug);
		if(note.flag == NDebug)
			pprint("suicide: %s\n", note.msg);
		pexit(note.msg, note.flag != NDebug);
	}

	if(up->notified){
		qunlock(&up->debug);
		splhi();
		return 0;
	}

	if(up->notify == nil){
		qunlock(&up->debug);
		pexit(note.msg, note.flag != NDebug);
	}
	if(!okaddr(PTR2UINT(up->notify), sizeof(ureg->ip), 0)){
		qunlock(&up->debug);
		pprint("suicide: bad function address %#p in notify\n",
			up->notify);
		pexit("Suicide", 0);
	}

	sp = ureg->sp - sizeof(NFrame);
	if(!okaddr(sp, sizeof(NFrame), 1)){
		qunlock(&up->debug);
		pprint("suicide: bad stack address %#p in notify\n", sp);
		pexit("Suicide", 0);
	}

	nf = (NFrame *)sp;
	memmove(&nf->ureg, ureg, sizeof(Ureg));
	nf->old = up->ureg;
	up->ureg = nf;
	memmove(nf->msg, note.msg, ERRMAX);
	nf->arg1 = nf->msg;
	nf->arg0 = &nf->ureg;
	ureg->bp = PTR2UINT(nf->arg0);
	nf->ip = 0;

	ureg->sp = sp;
	ureg->ip = PTR2UINT(up->notify);
	up->notified = 1;
	up->nnote--;
	memmove(&up->lastnote, &note, sizeof(Note));
	memmove(&up->note[0], &up->note[1], up->nnote*sizeof(Note));

	qunlock(&up->debug);
	splx(s);

	return 1;
}

/*
 * called from syscallentry in assembler.
 * just adds the Last argument, location of return value in frame.
 */
void
syscallamd(uint scallnr, Ureg* ureg)
{
	syscall(scallnr, ureg, (Ar0 *)&ureg->ax);
}

void
sysrforkchild(Proc* child, Proc* parent)
{
	Ureg *cureg;

	cureg = (Ureg*)(child->kstack+KSTACK - sizeof(Ureg));
	/*
	 * Subtract 3*BY2SE from the stack to account for
	 *  - the return PC
	 *  - syscallamd's arguments (syscallnr, ureg)
	 * below Ureg at the top of kstack.
	 */
	child->sched.sp = PTR2UINT(cureg) - 3*BY2SE;
	child->sched.pc = PTR2UINT(sysrforkret);

	memmove(cureg, parent->dbgreg, sizeof(Ureg));

	/* Things from bottom of syscall which were never executed */
	child->psstate = 0;
	child->insyscall = 0;

	fpusysrforkchild(child, parent);
}
