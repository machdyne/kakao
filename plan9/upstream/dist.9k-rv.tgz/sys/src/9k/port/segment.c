#include	"u.h"
#include	"../port/lib.h"
#include	"mem.h"
#include	"dat.h"
#include	"fns.h"
#include	"../port/error.h"

/*
 * this replaces 9's newseg(); its final argument is top address, not size.
 *
 * don't smalloc, which could sleep, while holding a Lock,
 * e.g. from attachimage.
 */
Segment *
newsegtop(int type, uintptr base, uintptr top)
{
	Segment *s;
	uintptr mapsize, size;

	if((base|top) & (PGSZ-1))
		panic("newseg: base %#p or top %#p not page-aligned", base, top);

	size = (top-base)/PGSZ;
	if(size > (SEGMAPSIZE*PTEPERTAB))
		error(Enovmem);

	s = malloc(sizeof(Segment));
	if (s== nil)
		error(Enomem);
	s->ref = 1;
	s->type = type;
	s->base = base;
	s->top = top;
	s->size = size;
	s->lg2pgsize = PGSHFT;
	s->ptemapmem = (uintptr)PTEPERTAB << s->lg2pgsize;
	s->sema.prev = &s->sema;
	s->sema.next = &s->sema;

	mapsize = HOWMANY(size, PTEPERTAB);	/* Pte maps needed */
	if(mapsize > nelem(s->ssegmap)){  /* more than in default seg map? */
		mapsize *= 2;		/* assume we'll need twice as much */
		if(mapsize > SEGMAPSIZE)
			mapsize = SEGMAPSIZE;	/* cap the map size */
		s->map = malloc(mapsize*sizeof(Pte*));
		if (s->map == nil)
			error(Enomem);
		s->mapsize = mapsize;
	}
	else{
		s->map = s->ssegmap;
		s->mapsize = nelem(s->ssegmap);
	}

	return s;
}

void
putseg(Segment *s)
{
	Pte **pp, **emap;
	Image *i;

	if(s == 0)
		return;

	i = s->image;
	if(i != 0) {
		lock(i);
		lock(s);
		if(i->s == s && s->ref == 1)
			i->s = 0;
		unlock(i);
	}
	else
		lock(s);

	s->ref--;
	if(s->ref != 0) {
		unlock(s);
		return;
	}
	unlock(s);

	qlock(&s->lk);
	if(i)
		putimage(i);

	emap = &s->map[s->mapsize];
	for(pp = s->map; pp < emap; pp++)
		if(*pp)
			freepte(s, *pp);

	qunlock(&s->lk);
	if(s->map != s->ssegmap)
		free(s->map);
	if(s->profile != 0)
		free(s->profile);
	free(s);
}

void
relocateseg(Segment *s, uintptr offset)
{
	Page **pg, *x;
	Pte *pte, **p, **endpte;

	endpte = &s->map[s->mapsize];
	for(p = s->map; p < endpte; p++) {
		if(*p == 0)
			continue;
		pte = *p;
		for(pg = pte->first; pg <= pte->last; pg++)
			if(x = *pg)
				x->va += offset;
	}
}

Segment*
dupseg(Segment **seg, int segno, int share)
{
	int i, size;
	Pte *pte;
	Segment *n, *s;

	SET(n);
	s = seg[segno];

	qlock(&s->lk);
	if(waserror()){
		qunlock(&s->lk);
		nexterror();
	}
	switch(s->type&SG_TYPE) {
	case SG_TEXT:		/* New segment shares pte set */
	case SG_SHARED:
	case SG_PHYSICAL:
		goto sameseg;

	case SG_BSS:		/* Just copy on write */
		if(share)
			goto sameseg;
		/* fall through */
	case SG_STACK:
		n = NEWSEGMENT(s->type, s->base, s->top, (s->top - s->base)/PGSZ);
		break;

	case SG_DATA:		/* Copy on write plus demand load info */
		if(segno == TSEG){
			poperror();
			qunlock(&s->lk);
			return data2txt(s);
		}

		if(share)
			goto sameseg;
		n = NEWSEGMENT(s->type, s->base, s->top, (s->top - s->base)/PGSZ);

		incref(s->image);
		n->image = s->image;
		n->fstart = s->fstart;
		n->flen = s->flen;
		break;
	}
	size = s->mapsize;
	for(i = 0; i < size; i++)
		if(pte = s->map[i])
			n->map[i] = ptecpy(pte);

	n->flushme = s->flushme;
	if(s->ref > 1)
		procflushseg(s);
	poperror();
	qunlock(&s->lk);
	return n;

sameseg:
	incref(s);
	poperror();
	qunlock(&s->lk);
	return s;
}

void
segpage(Segment *s, Page *p)
{
	Pte **pte;
	uintptr soff;
	Page **pg;

	if(p->va < s->base || p->va >= s->top)
		panic("segpage");

	soff = p->va - s->base;
	pte = &s->map[soff/s->ptemapmem];
	if(*pte == 0)
		*pte = ptealloc();

	pg = &(*pte)->pages[(soff&(s->ptemapmem-1)) >> s->lg2pgsize];
	*pg = p;
	if(pg < (*pte)->first)
		(*pte)->first = pg;
	if(pg > (*pte)->last)
		(*pte)->last = pg;
}

/*
 *  called with s->lk locked
 *
 *  top arg was pages in 9.
 */
void
mfreeseg(Segment *s, uintptr start, uintptr top)
{
	int i, j, size;
	uintptr pages, soff;
	Page *pg, *list;

	pages = (top-start)>>s->lg2pgsize;
	soff = start-s->base;
	j = (soff&(s->ptemapmem-1)) >> s->lg2pgsize;

	size = s->mapsize;
	list = nil;
	for(i = soff/s->ptemapmem; i < size; i++) {
		if(pages <= 0)
			break;
		if(s->map[i] == 0) {
			pages -= PTEPERTAB-j;
			j = 0;
			continue;
		}
		while(j < PTEPERTAB) {
			pg = s->map[i]->pages[j];
			/*
			 * We want to zero s->map[i]->page[j] and putpage(pg),
			 * but we have to make sure other processors flush the
			 * entry from their TLBs before the page is freed.
			 * We construct a list of the pages to be freed, zero
			 * the entries, then (below) call procflushseg, and call
			 * putpage on the whole list.  If swapping were
			 * implemented, paged-out pages can't be in a TLB and
			 * could be disposed of here.
			 */
			if(pg != nil){
				pg->next = list;
				list = pg;
				s->map[i]->pages[j] = nil;
			}
			if(--pages == 0)
				goto out;
			j++;
		}
		j = 0;
	}
out:
	/* flush this seg in all other processes */
	if(s->ref > 1)
		procflushseg(s);

	/* free the pages */
	for(pg = list; pg != nil; pg = list){
		list = list->next;
		putpage(pg);
	}
}

Segment*
isoverlap(Proc* p, uintptr va, uintptr len)
{
	int i;
	Segment *ns;
	uintptr newtop;

	newtop = va+len;
	for(i = 0; i < NSEG; i++) {
		ns = p->seg[i];
		if(ns == 0)
			continue;
		if(newtop > ns->base && va < ns->top)
			return ns;
	}
	return nil;
}

void
segclock(uintptr pc)
{
	Segment *s;

	s = up->seg[TSEG];
	if(s == 0 || s->profile == 0)
		return;

	s->profile[0] += TK2MS(1);
	if(pc >= s->base && pc < s->top) {
		pc -= s->base;
		s->profile[pc>>LRESPROF] += TK2MS(1);
	}
}
